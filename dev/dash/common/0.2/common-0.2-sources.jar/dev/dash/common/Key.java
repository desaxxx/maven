package dev.dash.common;

import com.google.common.base.Preconditions;
import org.jetbrains.annotations.NotNull;

import java.util.regex.Pattern;

public class Key {
    private static final Pattern KEY_PATTERN = Pattern.compile("^[a-z0-9_\\-./]+$");

    protected final String key;
    private Key(@NotNull String key) {
        Preconditions.checkNotNull(key, "key cannot be null");
        Preconditions.checkArgument(KEY_PATTERN.matcher(key).matches(), "key must match pattern " + KEY_PATTERN);
        this.key = key;
    }

    public String getKey() {
        return key;
    }

    @Override
    public String toString() {
        return key;
    }
}
