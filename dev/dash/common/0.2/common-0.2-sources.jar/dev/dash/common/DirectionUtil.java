package dev.dash.common;

import com.google.common.base.Preconditions;
import org.bukkit.block.BlockFace;
import org.bukkit.util.Vector;
import org.jetbrains.annotations.NotNull;

public class DirectionUtil {
    private static final BlockFace[] FACES_ASCENDING_YAW = new BlockFace[] {
            BlockFace.NORTH,
            BlockFace.NORTH_NORTH_EAST,
            BlockFace.NORTH_EAST,
            BlockFace.EAST_NORTH_EAST,
            BlockFace.EAST,
            BlockFace.EAST_SOUTH_EAST,
            BlockFace.SOUTH_EAST,
            BlockFace.SOUTH_SOUTH_EAST,
            BlockFace.SOUTH,
            BlockFace.SOUTH_SOUTH_WEST,
            BlockFace.SOUTH_WEST,
            BlockFace.WEST_SOUTH_WEST,
            BlockFace.WEST,
            BlockFace.WEST_NORTH_WEST,
            BlockFace.NORTH_WEST,
            BlockFace.NORTH_NORTH_WEST
    };

    /**
     * @return the normalized yaw, [-180, 180)
     */
    public static float normalizeYaw(float yaw) {
        if(yaw >= -180 && yaw < 180) {
            return yaw;
        }

        return ((yaw + 180) % 360 + 360) % 360 - 180;
    }

    public static @NotNull BlockFace getBlockFaceFromYaw(float yaw) {
        int i = Math.round((normalizeYaw(yaw) + 180f) / 22.5f); // [0, 360) / 22.5 = [0, 16)
        return FACES_ASCENDING_YAW[i % 16];
    }

    public static @NotNull Vector getDirectionFromYaw(float yaw) {
        double radians = Math.toRadians(yaw); // no need for normalization since sin and cos are periodic

        return new Vector(
                -Math.sin(radians),
                0,
                Math.cos(radians)
        );
    }

    public static float getYawFromDirection(@NotNull Vector direction) {
        Preconditions.checkNotNull(direction, "direction");
        return normalizeYaw((float) Math.toDegrees(
                Math.atan2(-direction.getX(), direction.getZ()) // no need for direction normalization
        ));
    }

    public static @NotNull BlockFace getBlockFaceFromDirection(@NotNull Vector direction) {
        return getBlockFaceFromYaw(getYawFromDirection(direction));
    }
}
