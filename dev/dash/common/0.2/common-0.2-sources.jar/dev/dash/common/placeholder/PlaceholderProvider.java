package dev.dash.common.placeholder;

import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public interface PlaceholderProvider extends Comparable<PlaceholderProvider> {
    String process(Player player, @NotNull String text);

    default int precedence() {
        return 1000;
    }

    @Override
    default int compareTo(@NotNull PlaceholderProvider o) {
        return Integer.compare(precedence(), o.precedence());
    }
}
