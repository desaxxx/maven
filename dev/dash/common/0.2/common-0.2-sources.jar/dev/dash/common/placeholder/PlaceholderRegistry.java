package dev.dash.common.placeholder;

import com.google.common.base.Preconditions;
import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

public class PlaceholderRegistry {
    public static final PlaceholderRegistry DEFAULT = new PlaceholderRegistry();

    static {
        if(Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            DEFAULT.registerPlaceholderProvider(PlaceholderAPI::setPlaceholders);
        }
    }

    private final @NotNull List<PlaceholderProvider> placeholderProviders = new ArrayList<>();

    public PlaceholderRegistry() {
    }
    public PlaceholderRegistry(@NotNull List<PlaceholderProvider> placeholderProviders) {
        this.placeholderProviders.addAll(placeholderProviders);
    }
    public PlaceholderRegistry(@NotNull PlaceholderRegistry other) {
        this.placeholderProviders.addAll(other.placeholderProviders);
    }

    public void registerPlaceholderProvider(@NotNull PlaceholderProvider provider) {
        Preconditions.checkNotNull(provider, "provider cannot be null");
        placeholderProviders.add(provider);
        placeholderProviders.sort(null);
    }

    public void unregisterPlaceholderProvider(@NotNull PlaceholderProvider provider) {
        Preconditions.checkNotNull(provider, "provider cannot be null");
        placeholderProviders.remove(provider);
    }

    public @NotNull List<PlaceholderProvider> getPlaceholderProviders() {
        return List.copyOf(placeholderProviders);
    }

    public @NotNull String parse(@Nullable Player player, @NotNull String text) {
        Preconditions.checkNotNull(text, "text cannot be null");
        String parsedText = text;

        for(PlaceholderProvider provider : placeholderProviders) {
            parsedText = provider.process(player, parsedText);
        }

        return parsedText;
    }

    public @NotNull PlaceholderRegistry copy() {
        return new PlaceholderRegistry(this);
    }
}
