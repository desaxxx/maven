package dev.dash.common;

import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.UnknownNullability;

public abstract class Requirement<Element> {

    protected @UnknownNullability Element element;
    protected Requirement(@UnknownNullability Element element) {
        this.element = element;
    }

    public abstract boolean fulfills(@NotNull Player player);

    public abstract void fine(@NotNull Player player);
}
