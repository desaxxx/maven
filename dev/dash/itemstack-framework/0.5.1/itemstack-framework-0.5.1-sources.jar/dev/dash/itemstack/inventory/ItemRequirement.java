package dev.dash.itemstack.inventory;

import com.google.common.base.Preconditions;
import dev.dash.common.Requirement;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

public class ItemRequirement extends Requirement<ItemStack> {

    public ItemRequirement(@NotNull ItemStack requirement) {
        super(requirement);
        Preconditions.checkNotNull(requirement, "stack cannot be null");
    }

    /**
     * @apiNote  {@link ItemIterableRequirement#fulfills(Player)} if you need to fulfill multiple items
     */
    public boolean fulfills(@NotNull Player player) {
        InventoryUtility inventoryUtility = new InventoryUtility(player.getInventory());

        return inventoryUtility.removeStack(element);
    }

    /**
     * @apiNote {@link ItemIterableRequirement#fine(Player)} if you need to fine multiple items
     */
    public void fine(@NotNull Player player) {
        InventoryUtility inventoryUtility = new InventoryUtility(player.getInventory());

        inventoryUtility.removeStack(element);

        inventoryUtility.applyTo(player.getInventory());
    }


    public @NotNull ItemStack getRequirement() {
        return element;
    }
}
