package dev.dash.itemstack.builder;

import com.google.common.base.Preconditions;
import io.papermc.paper.registry.RegistryAccess;
import io.papermc.paper.registry.RegistryKey;
import org.bukkit.Color;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemRarity;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.jspecify.annotations.NullMarked;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Deserializes {@link ItemStack}s from {@link ConfigurationSection}s (typically YAML config).
 * See {@code FORMAT.md} in the module root for the full key reference.
 *
 * <p>Supported keys: {@code material, amount, name, lore, lore_prepend, lore_append,
 * enchantments, stored_enchantments, flags, flags_unsafe, unbreakable, glint, rarity,
 * max_stack_size, custom_model_data, item_model, damage, color, skull, attributes, pdc}.
 * Unknown keys are ignored. Parsing is fail-fast: the first invalid value throws
 * {@link IllegalArgumentException} with a descriptive message.</p>
 *
 * <p>Name and lore lines go through {@link SimpleItemBuilder}'s text pipeline: placeholder
 * rendering (with an empty registry by default) followed by {@link TextFormat} parsing, so both
 * MiniMessage ({@code <red>Hi}) and legacy codes ({@code &cHi}) work.</p>
 */
@NullMarked
public class ItemDeserializer {

    private ItemDeserializer() {
    }

    /**
     * Deserializes an item stack from the given configuration section. The {@code material} key
     * is required.
     *
     * @param itemSection the configuration section containing the serialized item
     * @return the deserialized item stack
     *
     * @throws NullPointerException if {@code itemSection} is {@code null}
     * @throws IllegalArgumentException if the {@code material} key is missing or invalid, or if
     *         any other value is invalid (see class docs for the key list)
     */
    public static ItemStack deserialize(ConfigurationSection itemSection) {
        Preconditions.checkNotNull(itemSection, "section cannot be null");

        String materialString = itemSection.getString("material");
        if(materialString == null) {
            throw new IllegalArgumentException("Missing required 'material' key in item section '" + itemSection.getCurrentPath() + "'");
        }

        SimpleItemBuilder sib = SimpleItemBuilder.of(parseMaterial(materialString));
        apply(sib, itemSection);
        return sib.build();
    }

    /**
     * Deserializes an item stack using the given item stack as a foundation.
     * <br>
     * Properties specified in the configuration section override the corresponding
     * properties of the foundation. Unspecified properties retain their values from
     * the foundation. The foundation itself is not modified.
     *
     * @param itemSection the configuration section containing the serialized item data
     * @param foundation the item stack providing values for unspecified properties
     * @return a new item stack containing the merged properties
     *
     * @throws NullPointerException if {@code itemSection} or {@code foundation} is
     *         {@code null}
     * @throws IllegalArgumentException if any value in the configuration section is invalid
     */
    public static ItemStack deserialize(ConfigurationSection itemSection, ItemStack foundation) {
        Preconditions.checkNotNull(itemSection, "section cannot be null");
        Preconditions.checkNotNull(foundation, "foundation cannot be null");

        SimpleItemBuilder sib = SimpleItemBuilder.from(foundation);
        apply(sib, itemSection);
        return sib.build();
    }

    private static void apply(SimpleItemBuilder sib, ConfigurationSection section) {
        if(section.isString("material")) {
            String materialString = section.getString("material");
            if(materialString != null) {
                sib.type(parseMaterial(materialString));
            }
        }

        if(section.isInt("amount")) {
            sib.amount(section.getInt("amount"));
        }

        if(section.isString("name")) {
            String name = section.getString("name");
            if(name != null) {
                sib.name(name);
            }
        }

        if(section.isList("lore")) {
            sib.loreLines(section.getStringList("lore"));
        }

        if(section.isList("lore_prepend")) {
            sib.lorePrepend(section.getStringList("lore_prepend"));
        }

        if(section.isList("lore_append")) {
            sib.loreAppend(section.getStringList("lore_append"));
        }

        if(section.isConfigurationSection("enchantments")) {
            ConfigurationSection enchantments = section.getConfigurationSection("enchantments");
            if(enchantments != null) {
                deserializeEnchantments(sib, enchantments, false);
            }
        }

        if(section.isConfigurationSection("stored_enchantments")) {
            ConfigurationSection storedEnchantments = section.getConfigurationSection("stored_enchantments");
            if(storedEnchantments != null) {
                deserializeEnchantments(sib, storedEnchantments, true);
            }
        }

        if(section.isList("flags")) {
            sib.flags(parseItemFlags(section, "flags"));
        }

        if(section.isList("flags_unsafe")) {
            sib.flagsUnsafe(parseItemFlags(section, "flags_unsafe"));
        }

        if(section.isBoolean("unbreakable")) {
            sib.unbreakable(section.getBoolean("unbreakable"));
        }

        if(section.isBoolean("glint")) {
            sib.glint(section.getBoolean("glint"));
        }

        if(section.isString("rarity")) {
            String rarityString = section.getString("rarity");
            if(rarityString != null) {
                try {
                    sib.rarity(ItemRarity.valueOf(rarityString.trim().toUpperCase(Locale.ROOT)));
                } catch(IllegalArgumentException e) {
                    throw new IllegalArgumentException("Invalid item rarity: " + rarityString);
                }
            }
        }

        if(section.isInt("max_stack_size")) {
            sib.maxStackSize(section.getInt("max_stack_size"));
        }

        if(section.isInt("custom_model_data")) {
            sib.customModelData(section.getInt("custom_model_data"));
        }

        if(section.isString("item_model")) {
            String modelString = section.getString("item_model");
            if(modelString != null) {
                sib.itemModel(parseKey(modelString, "item model"));
            }
        }

        if(section.isInt("damage")) {
            sib.damage(section.getInt("damage"));
        }

        if(section.isString("color")) {
            String colorString = section.getString("color");
            if(colorString != null) {
                sib.color(parseColor(colorString));
            }
        }

        if(section.isConfigurationSection("skull")) {
            ConfigurationSection skull = section.getConfigurationSection("skull");
            if(skull != null) {
                deserializeSkull(sib, skull);
            }
        }

        if(section.isList("attributes")) {
            deserializeAttributes(sib, section.getMapList("attributes"));
        }

        if(section.isList("pdc")) {
            deserializePdc(sib, section.getMapList("pdc"));
        }
    }

    private static Material parseMaterial(String materialString) {
        Material material = Material.matchMaterial(materialString.trim());
        if(material == null) {
            throw new IllegalArgumentException("Invalid item material: " + materialString);
        }
        return material;
    }

    private static void deserializeEnchantments(SimpleItemBuilder sib, ConfigurationSection enchantmentSection, boolean stored) {
        for(String key : enchantmentSection.getKeys(false)) {
            Object value = enchantmentSection.get(key);
            if(!(value instanceof Number number)) {
                throw new IllegalArgumentException("Enchantment level must be a number: " + key + ": " + value);
            }

            Enchantment enchantment = parseEnchantment(key);
            if(stored) {
                sib.storedEnchant(enchantment, number.intValue());
            } else {
                sib.enchant(enchantment, number.intValue());
            }
        }
    }

    private static Enchantment parseEnchantment(String keyString) {
        NamespacedKey key = parseKey(keyString, "enchantment");
        Enchantment enchantment = RegistryAccess.registryAccess().getRegistry(RegistryKey.ENCHANTMENT).get(key);
        if(enchantment == null) {
            throw new IllegalArgumentException("Unknown enchantment: " + key);
        }
        return enchantment;
    }

    private static NamespacedKey parseKey(String keyString, String what) {
        NamespacedKey key = NamespacedKey.fromString(keyString.trim().toLowerCase(Locale.ROOT));
        if(key == null) {
            throw new IllegalArgumentException("Invalid " + what + " key: " + keyString);
        }
        return key;
    }

    private static List<ItemFlag> parseItemFlags(ConfigurationSection section, String key) {
        List<ItemFlag> flags = new ArrayList<>();
        List<?> list = section.getList(key);
        if(list == null) {
            return flags; // guarded by isList at the call site
        }
        for(Object entry : list) {
            String flagString = String.valueOf(entry).trim().toUpperCase(Locale.ROOT);
            try {
                flags.add(ItemFlag.valueOf(flagString));
            } catch(IllegalArgumentException e) {
                throw new IllegalArgumentException("Invalid item flag: " + entry);
            }
        }
        return flags;
    }

    private static Color parseColor(String colorString) {
        String s = colorString.trim();
        String hex = s.startsWith("#") ? s.substring(1) : s;
        if(hex.matches("[0-9a-fA-F]{6}")) {
            return Color.fromRGB(Integer.parseInt(hex, 16));
        }

        try {
            return DyeColor.valueOf(s.toUpperCase(Locale.ROOT)).getColor();
        } catch(IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid color (use #RRGGBB or a dye color name): " + colorString);
        }
    }

    private static void deserializeSkull(SimpleItemBuilder sib, ConfigurationSection skullSection) {
        String owner = skullSection.getString("owner");
        String uuidString = skullSection.getString("uuid");

        if(uuidString != null && owner != null) {
            sib.skullOwner(parseUuid(uuidString), owner);
        } else if(uuidString != null) {
            sib.skullOwner(parseUuid(uuidString));
        } else if(owner != null) {
            sib.skullOwner(owner);
        }

        String texture = skullSection.getString("texture");
        if(texture != null) {
            sib.skullTexture(texture);
        }
    }

    private static UUID parseUuid(String uuidString) {
        try {
            return UUID.fromString(uuidString.trim());
        } catch(IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid uuid: " + uuidString);
        }
    }

    private static void deserializeAttributes(SimpleItemBuilder sib, List<Map<?, ?>> entries) {
        int index = 0;
        for(Map<?, ?> entry : entries) {
            Object attributeObject = entry.get("attribute");
            if(!(attributeObject instanceof String attributeString)) {
                throw new IllegalArgumentException("attributes entry #" + index + " is missing the 'attribute' key");
            }

            Attribute attribute = parseAttribute(attributeString);
            double amount = entry.get("amount") instanceof Number number ? number.doubleValue() : 1.0;
            AttributeModifier.Operation operation = entry.get("operation") instanceof String operationString
                    ? parseOperation(operationString)
                    : AttributeModifier.Operation.ADD_NUMBER;
            EquipmentSlotGroup slotGroup = entry.get("slot_group") instanceof String slotGroupString
                    ? parseSlotGroup(slotGroupString)
                    : EquipmentSlotGroup.ANY;

            AttributeModifier modifier;
            if(entry.get("key") instanceof String keyString) {
                modifier = new AttributeModifier(parseKey(keyString, "attribute modifier"), amount, operation, slotGroup);
            } else {
                // deterministic key derived from the attribute and the entry order; not serialized
                modifier = new AttributeModifier(
                        new NamespacedKey("dash", attribute.getKey().value().replace('-', '_') + "_" + index),
                        amount, operation, slotGroup);
            }

            sib.attribute(attribute, modifier);
            index++;
        }
    }

    private static Attribute parseAttribute(String attributeString) {
        String s = attributeString.trim().toLowerCase(Locale.ROOT);
        if(s.startsWith("minecraft:")) {
            s = s.substring("minecraft:".length());
        }
        if(s.startsWith("generic.")) {
            s = s.substring("generic.".length());
        }

        NamespacedKey key = NamespacedKey.fromString(s);
        if(key == null) {
            throw new IllegalArgumentException("Invalid attribute key: " + attributeString);
        }

        Attribute attribute = RegistryAccess.registryAccess().getRegistry(RegistryKey.ATTRIBUTE).get(key);
        if(attribute == null) {
            throw new IllegalArgumentException("Unknown attribute: " + attributeString);
        }
        return attribute;
    }

    private static AttributeModifier.Operation parseOperation(String operationString) {
        try {
            return AttributeModifier.Operation.valueOf(operationString.trim().toUpperCase(Locale.ROOT));
        } catch(IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid attribute operation: " + operationString);
        }
    }

    private static EquipmentSlotGroup parseSlotGroup(String slotGroupString) {
        EquipmentSlotGroup group = EquipmentSlotGroup.getByName(slotGroupString.trim());
        if (group == null) {
            throw new IllegalArgumentException("Invalid equipment slot group: " + slotGroupString);
        }
        return group;
    }

    private static void deserializePdc(SimpleItemBuilder sib, List<Map<?, ?>> entries) {
        int index = 0;
        for(Map<?, ?> entry : entries) {
            Object keyObject = entry.get("key");
            if(!(keyObject instanceof String keyString)) {
                throw new IllegalArgumentException("pdc entry #" + index + " is missing the 'key' key");
            }

            String tag = entry.get("type") instanceof String typeString ? typeString.trim().toUpperCase(Locale.ROOT) : "STRING";
            PersistentDataType<?, ?> type = parsePdcType(tag);
            if(!entry.containsKey("value") || entry.get("value") == null) {
                throw new IllegalArgumentException("pdc entry #" + index + " (" + keyString + ") is missing the 'value' key");
            }
            Object value = convertPdcValue(tag, entry.get("value"), keyString);

            NamespacedKey key = parseKey(keyString, "persistent data");
            //noinspection unchecked,rawtypes
            PersistentDataType<Object, Object> rawType = (PersistentDataType) type;
            sib.pdc(pdc -> pdc.set(key, rawType, value));
            index++;
        }
    }

    private static PersistentDataType<?, ?> parsePdcType(String tag) {
        return switch(tag) {
            case "BYTE" -> PersistentDataType.BYTE;
            case "SHORT" -> PersistentDataType.SHORT;
            case "INT", "INTEGER" -> PersistentDataType.INTEGER;
            case "LONG" -> PersistentDataType.LONG;
            case "FLOAT" -> PersistentDataType.FLOAT;
            case "DOUBLE" -> PersistentDataType.DOUBLE;
            case "BOOLEAN" -> PersistentDataType.BOOLEAN;
            case "STRING" -> PersistentDataType.STRING;
            case "BYTE_ARRAY" -> PersistentDataType.BYTE_ARRAY;
            case "INT_ARRAY", "INTEGER_ARRAY" -> PersistentDataType.INTEGER_ARRAY;
            case "LONG_ARRAY" -> PersistentDataType.LONG_ARRAY;
            default -> throw new IllegalArgumentException(
                    "Invalid pdc type: " + tag + " (use BYTE, SHORT, INT, LONG, FLOAT, DOUBLE, BOOLEAN, STRING, BYTE_ARRAY, INT_ARRAY or LONG_ARRAY)");
        };
    }

    private static Object convertPdcValue(String tag, Object value, String keyString) {
        try {
            return switch(tag) {
                case "BYTE" -> asNumber(value, tag).byteValue();
                case "SHORT" -> asNumber(value, tag).shortValue();
                case "INT", "INTEGER" -> asNumber(value, tag).intValue();
                case "LONG" -> asNumber(value, tag).longValue();
                case "FLOAT" -> asNumber(value, tag).floatValue();
                case "DOUBLE" -> asNumber(value, tag).doubleValue();
                case "BOOLEAN" -> value;
                case "STRING" -> value.toString();
                case "BYTE_ARRAY" -> toArray(value, Number::byteValue, byte[]::new);
                case "INT_ARRAY", "INTEGER_ARRAY" -> toArray(value, Number::intValue, int[]::new);
                case "LONG_ARRAY" -> toArray(value, Number::longValue, long[]::new);
                default -> throw new IllegalArgumentException("Invalid pdc type: " + tag);
            };
        } catch(IllegalArgumentException e) {
            throw e;
        } catch(RuntimeException e) {
            throw new IllegalArgumentException("Invalid pdc value for " + tag + " key '" + keyString + "': " + value);
        }
    }

    private static Number asNumber(Object value, String tag) {
        if(!(value instanceof Number number)) {
            throw new IllegalArgumentException("Expected a number for pdc type " + tag + ", got: " + value);
        }
        return number;
    }

    private static <A> A toArray(Object value, java.util.function.Function<Number, ?> converter, java.util.function.IntFunction<A> arrayFactory) {
        if(!(value instanceof List<?> list)) {
            throw new IllegalArgumentException("Expected a list for array pdc type, got: " + value);
        }
        Object array = arrayFactory.apply(list.size());
        for(int i = 0; i < list.size(); i++) {
            Object element = list.get(i);
            if(!(element instanceof Number number)) {
                throw new IllegalArgumentException("Expected numbers in array pdc value, got: " + element);
            }
            java.lang.reflect.Array.set(array, i, converter.apply(number));
        }
        @SuppressWarnings("unchecked")
        A result = (A) array;
        return result;
    }
}
