package dev.dash.itemstack.comparison.meta;

import dev.dash.itemstack.comparison.ItemProperty;
import dev.dash.itemstack.comparison.UncommonMetaComparator;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.inventory.meta.Repairable;

import java.util.Objects;

public class UncommonMetaComparators {

    public static final UncommonMetaComparator<Repairable> REPAIRABLE;
    public static final UncommonMetaComparator<Damageable> DAMAGEABLE;
    public static final UncommonMetaComparator<PotionMeta> POTION;


    static {
        REPAIRABLE = (property, first, second) -> {
            Repairable rep1 = first instanceof Repairable repairable ? repairable : null;
            Repairable rep2 = second instanceof Repairable repairable ? repairable : null;
            if (rep1 == null || rep2 == null) {
                return rep1 == rep2;
            }

            if (property == ItemProperty.REPAIR_COST) {
                return rep1.hasRepairCost()
                        ? rep2.hasRepairCost() && rep1.getRepairCost() == rep2.getRepairCost()
                        : !rep2.hasRepairCost();
            } else {
                throw new IllegalArgumentException(property + " is not a repairable property");
            }
        };

        DAMAGEABLE = (property, first, second) -> {
            Damageable dmg1 = first instanceof Damageable damageable ? damageable : null;
            Damageable dmg2 = second instanceof Damageable damageable ? damageable : null;
            if (dmg1 == null || dmg2 == null) {
                return dmg1 == dmg2;
            }

            return switch (property) {
                case DAMAGE -> dmg1.getDamage() == dmg2.getDamage();
                case MAX_DAMAGE -> dmg1.hasMaxDamage()
                        ? dmg2.hasMaxDamage() && dmg1.getMaxDamage() == dmg2.getMaxDamage()
                        : !dmg2.hasMaxDamage();
                default ->
                        throw new IllegalArgumentException(property + " is not a damageable property");
            };
        };

        POTION = (property, first, second) -> {
            PotionMeta potion1 = first instanceof PotionMeta potion ? potion : null;
            PotionMeta potion2 = second instanceof PotionMeta potion ? potion : null;
            if (potion1 == null || potion2 == null) {
                return potion1 == potion2;
            }

            return switch (property) {
                case POTION_TYPE -> Objects.equals(potion1.getBasePotionType(), potion2.getBasePotionType());
                case CUSTOM_EFFECTS -> potion1.hasCustomEffects()
                        ? potion2.hasCustomEffects() && potion1.getCustomEffects().equals(potion2.getCustomEffects())
                        : !potion2.hasCustomEffects();
                case POTION_COLOR -> Objects.equals(potion1.getColor(), potion2.getColor());
                case CUSTOM_POTION_NAME -> Objects.equals(potion1.getCustomPotionName(), potion2.getCustomPotionName());
                default ->
                    throw new IllegalArgumentException(property + " is not a potion property");
            };
        };
    }
}
