package dev.dash.itemstack.comparison;

import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableMap;
import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

// https://github.com/PaperMC/Paper/blob/11502e7a8f8d0145347e09615be26ffebf682e7f/paper-server/src/main/java/org/bukkit/craftbukkit/inventory/CraftMetaItem.java#L1988
//
// Note: ItemFlags are not compared
public enum ItemProperty {
    TYPE(Category.STACK),
    AMOUNT(Category.STACK),
    DISPLAY_NAME(Category.COMMON_META),
    ITEM_NAME(Category.COMMON_META),
    ENCHANTS(Category.COMMON_META),
    LORE(Category.COMMON_META),
    CUSTOM_MODEL_DATA(Category.COMMON_META),
    ENCHANTABLE(Category.COMMON_META),
    // block data
    // repair cost
    ATTRIBUTE_MODIFIERS(Category.COMMON_META),
    // unhandled tags
    // removed tags
    // custom tag
    PERSISTENT_DATA(Category.COMMON_META),
    // tooltip display
    HIDE_TOOLTIP(Category.COMMON_META),
    TOOLTIP_STYLE(Category.COMMON_META),
    ITEM_MODEL(Category.COMMON_META),
    UNBREAKABLE(Category.COMMON_META),
    ENCHANTMENT_GLINT_OVERRIDE(Category.COMMON_META),
    GLIDER(Category.COMMON_META),
    DAMAGE_RESISTANT(Category.COMMON_META),
    MAX_STACK_SIZE(Category.COMMON_META),
    RARITY(Category.COMMON_META),
    USE_REMAINDER(Category.COMMON_META),
    USE_COOLDOWN(Category.COMMON_META),
    FOOD(Category.COMMON_META),
    TOOL(Category.COMMON_META),
    EQUIPPABLE(Category.COMMON_META),
    JUKEBOX_PLAYABLE(Category.COMMON_META),
    // damage
    // max damage
    // canPlaceOnPredicates
    // canBreakPredicates
    // version
    REPAIR_COST(Category.REPAIRABLE),
    DAMAGE(Category.DAMAGEABLE),
    MAX_DAMAGE(Category.DAMAGEABLE),
    POTION_TYPE(Category.POTION_META),
    CUSTOM_EFFECTS(Category.POTION_META),
    POTION_COLOR(Category.POTION_META),
    CUSTOM_POTION_NAME(Category.POTION_META),
    ;

    private final @NotNull Category category;
    ItemProperty(@NotNull Category category) {
        Preconditions.checkNotNull(category, "category cannot be null");
        this.category = category;
    }

    public static final Map<Category, Set<ItemProperty>> CATEGORY_PROPERTIES;

    static {
        Map<Category, Set<ItemProperty>> map = new HashMap<>();

        for(ItemProperty property : ItemProperty.values()) {
            map.computeIfAbsent(property.getCategory(), k -> new HashSet<>()).add(property);
        }

        CATEGORY_PROPERTIES = ImmutableMap.copyOf(map);
    }

    public @NotNull Category getCategory() {
        return category;
    }


    public enum Category {
        STACK,
        COMMON_META,
        REPAIRABLE,
        DAMAGEABLE,
        POTION_META,
        ;
    }
}
