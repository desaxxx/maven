package dev.dash.itemstack.comparison;

import com.google.common.base.Preconditions;
import com.google.common.collect.Multimap;
import dev.dash.itemstack.comparison.meta.UncommonMetaComparators;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;

public class ItemComparator {
    public static final ItemComparator BUKKIT_EXACT = new ItemComparator(Set.of()) {
        @Override
        public boolean matches(@NotNull ItemStack first, @NotNull ItemStack second) {
            Preconditions.checkNotNull(first, "first");
            Preconditions.checkNotNull(second, "second");
            return first.equals(second);
        }
    };
    public static final ItemComparator BUKKIT_SIMILAR = new ItemComparator(Set.of()) {
        @Override
        public boolean matches(@NotNull ItemStack first, @NotNull ItemStack second) {
            Preconditions.checkNotNull(first, "first");
            Preconditions.checkNotNull(second, "second");
            return first.isSimilar(second);
        }
    };
    // TODO: These comparators are incomplete.
    public static final ItemComparator EXACT = new Builder().build();
    public static final ItemComparator SIMILAR = new Builder().exclude(ItemProperty.AMOUNT).build();

    private final @NotNull Set<ItemProperty> includedProperties;
    private ItemComparator(@NotNull Set<ItemProperty> includedProperties) {
        Preconditions.checkNotNull(includedProperties, "includedProperties cannot be null");
        this.includedProperties = EnumSet.noneOf(ItemProperty.class);
        this.includedProperties.addAll(includedProperties);
    }

    public static Builder builder() {
        return new Builder();
    }

    // https://github.com/PaperMC/Paper/blob/11502e7a8f8d0145347e09615be26ffebf682e7f/paper-server/src/main/java/org/bukkit/craftbukkit/inventory/CraftMetaItem.java#L1906
    private static boolean compareModifiers(Multimap<Attribute, AttributeModifier> first, Multimap<Attribute, AttributeModifier> second) {
        if (first == null || second == null) {
            return false;
        }
        if (first.isEmpty() && second.isEmpty()) return true;
        for (Map.Entry<Attribute, AttributeModifier> entry : first.entries()) {
            if (!second.containsEntry(entry.getKey(), entry.getValue())) {
                return false;
            }
        }
        for (Map.Entry<Attribute, AttributeModifier> entry : second.entries()) {
            if (!first.containsEntry(entry.getKey(), entry.getValue())) {
                return false;
            }
        }
        return true;
    }

    public boolean matches(@NotNull ItemStack first, @NotNull ItemStack second) {
        Preconditions.checkNotNull(first, "first cannot be null");
        Preconditions.checkNotNull(second, "second cannot be null");

        for(ItemProperty property : includedProperties) {
            if(!matches(property, first, second)) {
                return false;
            }
        }

        return true;
    }

    private boolean matches(@NotNull ItemProperty property,
                           @NotNull ItemStack first,
                           @NotNull ItemStack second) {
        return switch (property.getCategory()) {
            case STACK -> matchesStack(property, first, second);
            case COMMON_META -> matchesCommon(property, first.getItemMeta(), second.getItemMeta());
            case REPAIRABLE -> UncommonMetaComparators.REPAIRABLE.matches(property, first.getItemMeta(), second.getItemMeta());
            case DAMAGEABLE -> UncommonMetaComparators.DAMAGEABLE.matches(property, first.getItemMeta(), second.getItemMeta());
            case POTION_META -> UncommonMetaComparators.POTION.matches(property, first.getItemMeta(), second.getItemMeta());
        };
    }

    private boolean matchesStack(@NotNull ItemProperty property,
                                 @NotNull ItemStack first,
                                 @NotNull ItemStack second) {
        return switch (property) {
            case TYPE -> first.getType() == second.getType();
            case AMOUNT -> first.getAmount() == second.getAmount();
            default ->
                    throw new IllegalArgumentException(property + " is not a stack property");
        };
    }

    private boolean matchesCommon(@NotNull ItemProperty property,
                                  @Nullable ItemMeta first,
                                  @Nullable ItemMeta second) {
        if(first == null || second == null) {
            return first == second;
        }

        return switch (property) {
            case DISPLAY_NAME -> first.hasDisplayName()
                    ? second.hasDisplayName() && first.displayName().equals(second.displayName())
                    : !second.hasDisplayName();
            case ITEM_NAME -> first.hasItemName()
                    ? second.hasItemName() && first.itemName().equals(second.itemName())
                    : !second.hasItemName();
            case ENCHANTS -> first.hasEnchants()
                    ? second.hasEnchants() && first.getEnchants().equals(second.getEnchants())
                    : !second.hasEnchants();
            case LORE -> Objects.equals(first.lore(), second.lore());
            case CUSTOM_MODEL_DATA -> Objects.equals(first.getCustomModelDataComponent(), second.getCustomModelDataComponent());
            case ENCHANTABLE -> first.hasEnchantable()
                    ? second.hasEnchantable() && first.getEnchantable() == second.getEnchantable()
                    : !second.hasEnchantable();
            case ATTRIBUTE_MODIFIERS -> first.hasAttributeModifiers()
                    ? second.hasAttributeModifiers() && compareModifiers(first.getAttributeModifiers(), second.getAttributeModifiers())
                    : !second.hasAttributeModifiers();
            case PERSISTENT_DATA -> first.getPersistentDataContainer().equals(second.getPersistentDataContainer());
            case HIDE_TOOLTIP -> first.isHideTooltip() == second.isHideTooltip();
            case TOOLTIP_STYLE -> first.hasTooltipStyle()
                    ? second.hasTooltipStyle() && first.getTooltipStyle().equals(second.getTooltipStyle())
                    : !second.hasTooltipStyle();
            case ITEM_MODEL -> first.hasItemModel()
                    ? second.hasItemModel() && first.getItemModel().equals(second.getItemModel())
                    : !second.hasItemModel();
            case UNBREAKABLE -> first.isUnbreakable() == second.isUnbreakable();
            case ENCHANTMENT_GLINT_OVERRIDE -> first.hasEnchantmentGlintOverride()
                    ? second.hasEnchantmentGlintOverride() && first.getEnchantmentGlintOverride().equals(second.getEnchantmentGlintOverride())
                    : !second.hasEnchantmentGlintOverride();
            case GLIDER -> first.isGlider() == second.isGlider();
            case DAMAGE_RESISTANT -> first.hasDamageResistant()
                    ? second.hasDamageResistant() && first.getDamageResistant().equals(second.getDamageResistant())
                    : !second.hasDamageResistant();
            case MAX_STACK_SIZE -> first.hasMaxStackSize()
                    ? second.hasMaxStackSize() && first.getMaxStackSize() == second.getMaxStackSize()
                    : !second.hasMaxStackSize();
            case RARITY -> first.hasRarity()
                    ? second.hasRarity() && first.getRarity().equals(second.getRarity())
                    : !second.hasRarity();
            case USE_REMAINDER -> first.hasUseRemainder()
                    ? second.hasUseRemainder() && first.getUseRemainder().equals(second.getUseRemainder())
                    : !second.hasUseRemainder();
            case USE_COOLDOWN -> first.hasUseCooldown()
                    ? second.hasUseCooldown() && first.getUseCooldown().equals(second.getUseCooldown())
                    : !second.hasUseCooldown();
            case FOOD -> first.hasFood()
                    ? second.hasFood() && first.getFood().equals(second.getFood())
                    : !second.hasFood();
            case TOOL -> first.hasTool()
                    ? second.hasTool() && first.getTool().equals(second.getTool())
                    : !second.hasTool();
            case EQUIPPABLE -> first.hasEquippable()
                    ? second.hasEquippable() && first.getEquippable().equals(second.getEquippable())
                    : !second.hasEquippable();
            case JUKEBOX_PLAYABLE -> first.hasJukeboxPlayable()
                    ? second.hasJukeboxPlayable() && first.getJukeboxPlayable().equals(second.getJukeboxPlayable())
                    : !second.hasJukeboxPlayable();
            default ->
                    throw new IllegalArgumentException(property + " is not an common meta property");
        };
    }


    public @NotNull Set<ItemProperty> getIncludedProperties() {
        return Collections.unmodifiableSet(includedProperties);
    }

    public static class Builder {

        private final @NotNull Set<ItemProperty> includedProperties = EnumSet.allOf(ItemProperty.class);
        private Builder() {
        }

        public ItemComparator build() {
            return new ItemComparator(includedProperties);
        }

        public Builder include(@NotNull ItemProperty property) {
            includedProperties.add(property);
            return this;
        }

        public Builder includeAll() {
            includedProperties.addAll(EnumSet.allOf(ItemProperty.class));
            return this;
        }

        public Builder includeAll(@NotNull ItemProperty.Category category) {
            ItemProperty.CATEGORY_PROPERTIES.get(category).forEach(this::include);
            return this;
        }

        public Builder exclude(@NotNull ItemProperty property) {
            includedProperties.remove(property);
            return this;
        }

        public Builder excludeAll() {
            includedProperties.clear();
            return this;
        }

        public Builder excludeAll(@NotNull ItemProperty.Category category) {
            includedProperties.removeIf(property -> property.getCategory() == category);
            return this;
        }
    }
}
