package dev.dash.itemstack.builder;

import com.google.common.base.Preconditions;
import net.kyori.adventure.text.Component;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NullMarked;

import java.util.List;

/**
 * Read-only view of an {@link ItemStack}, handed to the {@code editName}/ {@code editLore}
 * functions. The viewed stack is a clone; mutating it has no effect on the builder.
 */
@NullMarked
public class ItemViewer {

    private final ItemStack clonedStack;
    private final ItemMeta meta;
    public ItemViewer(ItemStack stack) {
        Preconditions.checkNotNull(stack, "stack cannot be null");
        this.clonedStack = stack.clone();
        this.meta = stack.getItemMeta();
        Preconditions.checkNotNull(meta, "This stack has no meta");
    }

    public ItemStack getStack() {
        return clonedStack;
    }

    public ItemMeta getMeta() {
        return meta;
    }

    /** @return the current display name, or {@code null} if none is set */
    public @Nullable Component name() {
        return meta.displayName();
    }

    /** @return the current lore, or {@code null} if none is set */
    public @Nullable List<Component> lore() {
        return meta.lore();
    }
}
