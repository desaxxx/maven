package dev.dash.itemstack.builder;

import com.google.common.base.Preconditions;
import dev.dash.common.placeholder.PlaceholderRegistry;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NullMarked;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.UnaryOperator;

/**
 * The default {@link AbstractItemBuilder} implementation with plain-text support: every String
 * name/lore input is run through the {@link #textRenderer placeholder renderer} and then parsed
 * by {@link TextFormat} (MiniMessage or legacy codes).
 *
 * <p>Inside {@code name(String)} and the deprecated String {@code editName(...)}, the
 * placeholders {@code %name%} and {@code %effective_name%} are substituted with the item's
 * current display name before parsing, which makes it easy to build prefixed icon names from
 * config.</p>
 *
 * <p>The default {@link PlaceholderRegistry} is empty. To resolve PlaceholderAPI placeholders,
 * call {@code textRenderer(PlaceholderRegistry.DEFAULT)}.</p>
 */
@SuppressWarnings({"unused"})
@NullMarked
public class SimpleItemBuilder extends AbstractItemBuilder<SimpleItemBuilder> {

    protected static final LegacyComponentSerializer LEGACY_COMPONENT_SERIALIZER = LegacyComponentSerializer.legacySection();

    private PlaceholderRegistry textRenderer = new PlaceholderRegistry();

    private SimpleItemBuilder(ItemStack base, boolean aliased) {
        super(base, aliased);
    }

    /**
     * Creates a builder that edits the given stack in place: every method mutates the stack and
     * {@link #build()} returns the same instance.
     */
    public static SimpleItemBuilder of(ItemStack base) {
        return new SimpleItemBuilder(base, true);
    }

    /** Creates a builder that owns a fresh stack of the given material. */
    public static SimpleItemBuilder of(Material type) {
        return new SimpleItemBuilder(new ItemStack(type), false);
    }

    /** Creates a builder that owns a fresh stack of the given material and amount. */
    public static SimpleItemBuilder of(Material type, int amount) {
        return new SimpleItemBuilder(new ItemStack(type, amount), false);
    }

    /**
     * Creates a builder that edits the given stack in place (self-documenting alias of
     * {@link #of(ItemStack)}).
     */
    public static SimpleItemBuilder edit(ItemStack base) {
        return of(base);
    }

    /**
     * Creates a builder that owns a clone of the given stack: the original is never modified.
     */
    public static SimpleItemBuilder from(ItemStack base) {
        Preconditions.checkNotNull(base, "base cannot be null");
        return new SimpleItemBuilder(base.clone(), false);
    }

    @Override
    protected SimpleItemBuilder self() {
        return this;
    }

    /**
     * Replaces the placeholder registry used to render all String inputs. Note that
     * {@link PlaceholderRegistry#DEFAULT} is the instance wired to PlaceholderAPI (when the
     * plugin is present); the default per-builder registry is empty.
     */
    public SimpleItemBuilder textRenderer(PlaceholderRegistry textRenderer) {
        Preconditions.checkNotNull(textRenderer, "textRenderer cannot be null");
        this.textRenderer = textRenderer;
        return this;
    }

    /**
     * Runs the given text through the placeholder renderer. Does not parse MiniMessage or legacy
     * codes; use {@link TextFormat#parse(String)} for that.
     */
    public String renderText(String text) {
        Preconditions.checkNotNull(text, "text cannot be null");
        return textRenderer.parse(null, text);
    }

    // ================
    // TEXT (String -> Component)
    // ================

    /**
     * Sets the display name from plain text: rendered through the placeholder registry, then
     * parsed by {@link TextFormat} (MiniMessage or legacy codes). {@code null} clears it.
     */
    public SimpleItemBuilder name(@Nullable String name) {
        editMeta(meta -> {
            if(name == null) {
                setDisplayName(meta, null);
                return;
            }
            setDisplayName(meta, TextFormat.parse(substituteName(renderText(name), meta)));
        });
        return this;
    }

    /**
     * Edits the current display name as a component. The operator receives the current name
     * (or {@code null} if none is set) and its result is set as the new name, verbatim
     * (no placeholder rendering, no {@code %name%} substitution).
     */
    public SimpleItemBuilder editName(UnaryOperator<@Nullable Component> function) {
        Preconditions.checkNotNull(function, "function cannot be null");
        editMeta(meta -> setDisplayName(meta, function.apply(meta.displayName())));
        return this;
    }

    /**
     * Edits the current display name using legacy strings. Prefer {@link #editName(UnaryOperator)}.
     * The function receives the legacy display name (or {@code null}) and its result goes through
     * {@code %name%} substitution and {@link TextFormat} parsing, like {@link #name(String)}.
     */
    @Deprecated(since = "0.4")
    public SimpleItemBuilder editName(BiFunction<ItemViewer, @Nullable String, @Nullable String> function) {
        Preconditions.checkNotNull(function, "function cannot be null");
        editMeta(meta -> {
            @Nullable String name = function.apply(new ItemViewer(stack), meta.getDisplayName());
            if(name == null) {
                setDisplayName(meta, null);
                return;
            }
            setDisplayName(meta, TextFormat.parse(substituteName(renderText(name), meta)));
        });
        return this;
    }

    /**
     * Sets the lore from plain-text lines, rendered and parsed like {@link #name(String)}.
     * Replaces the whole lore; {@code null} clears it.
     */
    public SimpleItemBuilder loreLines(@Nullable List<String> lore) {
        editMeta(meta -> setLore(meta, lore == null ? null : renderLines(lore)));
        return this;
    }

    /** Sets the lore from plain-text lines (see {@link #loreLines(List)}). */
    public SimpleItemBuilder lore(String @Nullable... lore) {
        return loreLines(lore == null ? null : List.of(lore));
    }

    /**
     * Edits the current lore as components. The operator receives the current lore (or
     * {@code null} if none is set) and its result is set verbatim.
     */
    public SimpleItemBuilder editLore(UnaryOperator<@Nullable List<Component>> function) {
        Preconditions.checkNotNull(function, "function cannot be null");
        editMeta(meta -> setLore(meta, function.apply(meta.lore())));
        return this;
    }

    /**
     * Edits the current lore using legacy strings. Prefer {@link #editLore(UnaryOperator)}.
     */
    @Deprecated(since = "0.4")
    public SimpleItemBuilder editLore(BiFunction<ItemViewer, @Nullable List<String>, @Nullable List<String>> function) {
        Preconditions.checkNotNull(function, "function cannot be null");
        editMeta(meta -> {
            @Nullable List<String> oldLore = meta.getLore(); // mutable if non-null
            @Nullable List<String> newLore = function.apply(new ItemViewer(stack), oldLore);

            setLore(meta, newLore == null ? null : renderLines(newLore));
        });
        return this;
    }

    /** Appends plain-text lines to the current lore. */
    public SimpleItemBuilder loreAppend(@Nullable List<String> lore) {
        editMeta(meta -> {
            if(lore == null) {
                return;
            }
            List<Component> current = meta.lore();
            List<Component> merged = new ArrayList<>(current != null ? current : List.of());
            merged.addAll(renderLines(lore));
            setLore(meta, merged);
        });
        return this;
    }

    public SimpleItemBuilder loreAppend(String @Nullable... lore) {
        return loreAppend(lore == null ? null : List.of(lore));
    }

    /** Prepends plain-text lines to the current lore. */
    public SimpleItemBuilder lorePrepend(@Nullable List<String> lore) {
        editMeta(meta -> {
            if(lore == null) {
                return;
            }
            List<Component> merged = new ArrayList<>(renderLines(lore));
            List<Component> current = meta.lore();
            if(current != null) {
                merged.addAll(current);
            }
            setLore(meta, merged);
        });
        return this;
    }

    public SimpleItemBuilder lorePrepend(String @Nullable... lore) {
        return lorePrepend(lore == null ? null : List.of(lore));
    }

    /** Appends component lines to the current lore. */
    public SimpleItemBuilder appendLore(@Nullable List<Component> lore) {
        editMeta(meta -> {
            if(lore == null) {
                return;
            }
            List<Component> current = meta.lore();
            List<Component> merged = new ArrayList<>(current != null ? current : List.of());
            merged.addAll(lore);
            setLore(meta, merged);
        });
        return this;
    }

    /** Prepends component lines to the current lore. */
    public SimpleItemBuilder prependLore(@Nullable List<Component> lore) {
        editMeta(meta -> {
            if(lore == null) {
                return;
            }
            List<Component> merged = new ArrayList<>(lore);
            List<Component> current = meta.lore();
            if(current != null) {
                merged.addAll(current);
            }
            setLore(meta, merged);
        });
        return this;
    }

    // ================
    // HELPERS
    // ================

    private List<Component> renderLines(List<? extends @Nullable String> lines) {
        List<Component> components = new ArrayList<>(lines.size());
        for(@Nullable String line : lines) {
            Component lineComp = TextFormat.parse(line == null ? "" : renderText(line));
            if (lineComp != null) {
                components.add(lineComp);
            }
        }
        return components;
    }

    private String substituteName(String name, ItemMeta meta) {
        String modified = name;
        if(modified.contains("%name%")) {
            modified = modified.replace("%name%", meta.hasDisplayName() ? legacyOf(meta.displayName()) : "");
        }
        if(modified.contains("%effective_name%")) {
            modified = modified.replace("%effective_name%", legacyOf(stack.effectiveName()));
        }
        return modified;
    }

    private static String legacyOf(@Nullable Component component) {
        return component == null ? "" : LEGACY_COMPONENT_SERIALIZER.serialize(component);
    }
}
