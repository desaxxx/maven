package dev.dash.itemstack.builder;

import com.destroystokyo.paper.profile.PlayerProfile;
import com.google.common.collect.Multimap;
import net.kyori.adventure.text.Component;
import org.bukkit.Color;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NullMarked;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Serializes {@link ItemStack}s into {@link ConfigurationSection}s, using exactly the key set
 * accepted by {@link ItemDeserializer} — {@code serialize} and {@code deserialize} round-trip.
 * Only non-default properties are written. Unknown/unsupported persistent data types (e.g. nested
 * containers) are skipped.
 *
 * <p>Name and lore are written as MiniMessage strings (see {@link TextFormat}).</p>
 */
@NullMarked
public class ItemSerializer {

    private static final List<PersistentDataType<?, ?>> PDC_TYPE_PROBES = List.of(
            PersistentDataType.STRING,
            PersistentDataType.INTEGER,
            PersistentDataType.LONG,
            PersistentDataType.FLOAT,
            PersistentDataType.DOUBLE,
            PersistentDataType.BYTE,
            PersistentDataType.SHORT,
            PersistentDataType.BOOLEAN,
            PersistentDataType.BYTE_ARRAY,
            PersistentDataType.INTEGER_ARRAY,
            PersistentDataType.LONG_ARRAY);

    private ItemSerializer() {
    }

    /**
     * Serializes the given stack into a fresh in-memory {@link YamlConfiguration}.
     *
     * @param stack the stack, may be null
     * @return a configuration section containing the serialized properties, or {@code null} if
     *         the stack was null
     */
    public static @Nullable ConfigurationSection serialize(@Nullable ItemStack stack) {
        if(stack == null) {
            return null;
        }
        YamlConfiguration configuration = new YamlConfiguration();
        serialize(stack, configuration);
        return configuration;
    }

    /**
     * Serializes the given stack into the given section. Existing keys managed by this method
     * are overwritten; other keys in the section are left untouched.
     *
     * @param stack the stack, may be null (writes nothing)
     * @param section the target section
     */
    public static void serialize(@Nullable ItemStack stack, ConfigurationSection section) {
        if(stack == null) {
            return;
        }

        section.set("material", stack.getType().name());
        if(stack.getAmount() != 1) {
            section.set("amount", stack.getAmount());
        }

        ItemMeta meta = stack.getItemMeta();
        if(meta == null) {
            return;
        }

        Component name = meta.displayName();
        if(name != null) {
            section.set("name", TextFormat.serialize(TextFormat.stripDefaultItalic(name)));
        }

        List<Component> lore = meta.lore();
        if(lore != null && !lore.isEmpty()) {
            List<String> loreLines = new ArrayList<>(lore.size());
            for(var line : lore) {
                loreLines.add(TextFormat.serialize(TextFormat.stripDefaultItalic(line)));
            }
            section.set("lore", loreLines);
        }

        if(!meta.getEnchants().isEmpty()) {
            section.createSection("enchantments", enchantmentMap(meta.getEnchants()));
        }

        if(meta instanceof EnchantmentStorageMeta storageMeta && !storageMeta.getStoredEnchants().isEmpty()) {
            section.createSection("stored_enchantments", enchantmentMap(storageMeta.getStoredEnchants()));
        }

        if(!meta.getItemFlags().isEmpty()) {
            section.set("flags", meta.getItemFlags().stream().map(Enum::name).toList());
        }

        if(meta.isUnbreakable()) {
            section.set("unbreakable", true);
        }

        if(meta.hasEnchantmentGlintOverride()) {
            section.set("glint", meta.getEnchantmentGlintOverride());
        }

        if(meta.hasRarity()) {
            section.set("rarity", meta.getRarity().name());
        }

        if(meta.hasMaxStackSize()) {
            section.set("max_stack_size", meta.getMaxStackSize());
        }

        if(meta.hasCustomModelData()) {
            section.set("custom_model_data", meta.getCustomModelData());
        }

        if(meta.hasItemModel()) {
            NamespacedKey itemModel = meta.getItemModel();
            if(itemModel != null) {
                section.set("item_model", itemModel.toString());
            }
        }

        if(meta instanceof Damageable damageable && damageable.hasDamage()) {
            section.set("damage", damageable.getDamage());
        }

        if(meta instanceof LeatherArmorMeta armorMeta) {
            section.set("color", toHex(armorMeta.getColor()));
        }

        if(meta instanceof SkullMeta skullMeta) {
            PlayerProfile profile = skullMeta.getPlayerProfile();
            if(profile != null) {
                serializeSkull(profile, section);
            }
        }

        Multimap<Attribute, AttributeModifier> modifiers = meta.getAttributeModifiers();
        if(modifiers != null) {
            serializeAttributes(modifiers, section);
        }

        serializePdc(meta.getPersistentDataContainer(), section);
    }

    private static Map<String, Integer> enchantmentMap(Map<Enchantment, Integer> enchantments) {
        Map<String, Integer> map = new LinkedHashMap<>();
        for(Map.Entry<Enchantment, Integer> entry : enchantments.entrySet()) {
            map.put(enchantmentKey(entry.getKey()), entry.getValue());
        }
        return map;
    }

    private static String enchantmentKey(Enchantment enchantment) {
        var key = enchantment.getKey();
        return "minecraft".equals(key.getNamespace()) ? key.getKey() : key.toString();
    }

    private static String toHex(Color color) {
        return String.format("#%06X", color.asRGB() & 0xFFFFFF);
    }

    private static void serializeSkull(PlayerProfile profile, ConfigurationSection section) {
        Map<String, Object> skull = new LinkedHashMap<>();
        if(profile.getName() != null) {
            skull.put("owner", profile.getName());
        }
        if(profile.getId() != null) {
            skull.put("uuid", profile.getId().toString());
        }
        for(var property : profile.getProperties()) {
            if("textures".equals(property.getName())) {
                skull.put("texture", property.getValue());
                break;
            }
        }
        if(!skull.isEmpty()) {
            section.createSection("skull", skull);
        }
    }

    private static void serializeAttributes(Multimap<Attribute, AttributeModifier> modifiers, ConfigurationSection section) {
        List<Map<String, Object>> entries = new ArrayList<>();
        for(var attributeEntry : modifiers.entries()) {
            AttributeModifier modifier = attributeEntry.getValue();
            // skip the internal flagsUnsafe hack modifier; flags_unsafe state cannot be reconstructed anyway
            if(AbstractItemBuilder.UNSAFE_ITEMFLAG_KEY.equals(modifier.getKey())) {
                continue;
            }
            Map<String, Object> map = new LinkedHashMap<>();
            map.put("attribute", attributeEntry.getKey().getKey().toString());
            map.put("amount", modifier.getAmount());
            map.put("operation", modifier.getOperation().name());
            map.put("slot_group", modifier.getSlotGroup().toString());
            var key = modifier.getKey();
            if(!"dash".equals(key.getNamespace())) {
                map.put("key", key.toString());
            }
            entries.add(map);
        }
        if(!entries.isEmpty()) {
            section.set("attributes", entries);
        }
    }

    private static void serializePdc(PersistentDataContainer pdc, ConfigurationSection section) {
        List<Map<String, Object>> entries = new ArrayList<>();
        for(var key : pdc.getKeys()) {
            String tag = null;
            Object value = null;
            for(PersistentDataType<?, ?> type : PDC_TYPE_PROBES) {
                try {
                    Object probe = pdc.get(key, type);
                    if(probe != null) {
                        tag = tagName(type);
                        value = probe;
                        break;
                    }
                } catch(ClassCastException | IllegalArgumentException ignored) {
                    // probe the next type
                }
            }
            if(tag == null) {
                continue; // unsupported type (e.g. nested container)
            }
            Map<String, Object> map = new LinkedHashMap<>();
            map.put("key", key.toString());
            map.put("type", tag);
            map.put("value", toYamlValue(value));
            entries.add(map);
        }
        if(!entries.isEmpty()) {
            section.set("pdc", entries);
        }
    }

    private static String tagName(PersistentDataType<?, ?> type) {
        if(type == PersistentDataType.STRING) return "STRING";
        if(type == PersistentDataType.INTEGER) return "INT";
        if(type == PersistentDataType.LONG) return "LONG";
        if(type == PersistentDataType.FLOAT) return "FLOAT";
        if(type == PersistentDataType.DOUBLE) return "DOUBLE";
        if(type == PersistentDataType.BYTE) return "BYTE";
        if(type == PersistentDataType.SHORT) return "SHORT";
        if(type == PersistentDataType.BOOLEAN) return "BOOLEAN";
        if(type == PersistentDataType.BYTE_ARRAY) return "BYTE_ARRAY";
        if(type == PersistentDataType.INTEGER_ARRAY) return "INT_ARRAY";
        if(type == PersistentDataType.LONG_ARRAY) return "LONG_ARRAY";
        throw new IllegalStateException("Unhandled pdc type");
    }

    private static Object toYamlValue(Object value) {
        if(value instanceof byte[] bytes) {
            List<Byte> list = new ArrayList<>(bytes.length);
            for(byte b : bytes) list.add(b);
            return list;
        }
        if(value instanceof int[] ints) {
            List<Integer> list = new ArrayList<>(ints.length);
            for(int i : ints) list.add(i);
            return list;
        }
        if(value instanceof long[] longs) {
            List<Long> list = new ArrayList<>(longs.length);
            for(long l : longs) list.add(l);
            return list;
        }
        return value;
    }
}
