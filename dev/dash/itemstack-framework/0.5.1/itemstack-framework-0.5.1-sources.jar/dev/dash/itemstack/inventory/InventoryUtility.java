package dev.dash.itemstack.inventory;

import com.google.common.base.Preconditions;
import dev.dash.itemstack.comparison.ItemComparator;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class InventoryUtility {

    private final @NotNull Map<Integer, ItemStack> contents;
    private final int size;
    private final @NotNull ItemComparator comparator;
    public InventoryUtility(@NotNull Inventory inventory) {
        this(inventory, ItemComparator.BUKKIT_SIMILAR);
    }
    public InventoryUtility(@NotNull Inventory inventory, @NotNull ItemComparator comparator) {
        Preconditions.checkNotNull(inventory, "inventory cannot be null");
        Preconditions.checkNotNull(comparator, "comparator cannot be null");
        this.contents = new HashMap<>();
        // 0-8      -> hotbar
        // 9-35     -> base inventory
        // 36-39    -> armor slots
        // 40       -> offhand
        this.size = inventory instanceof PlayerInventory ? 41 : inventory.getSize();
        this.comparator = comparator;

        for (int i = 0; i < size; i++) {
            ItemStack stack = inventory.getItem(i);
            // AIR and null items are not registered.
            if (!isEmpty(stack)) {
                this.contents.put(i, stack.clone());
            }
        }
    }
    private InventoryUtility(@NotNull InventoryUtility other) {
        Preconditions.checkNotNull(other);
        this.size = other.size;
        this.contents = new HashMap<>();
        this.comparator = other.comparator;

        for (Map.Entry<Integer, ItemStack> entry : other.contents.entrySet()) {
            this.contents.put(entry.getKey(), entry.getValue().clone());
        }

    }

    private boolean isEmpty(@Nullable ItemStack item) {
        return item == null || isEmpty(item.getType());
    }

    private boolean isEmpty(@Nullable Material material) {
        return material == null || material == Material.AIR;
    }

    private boolean matches(@NotNull ItemStack first, @NotNull ItemStack second) {
        return comparator.matches(first, second);
    }



    /**
     * Checks if there's space for a single ItemStack
     * <b>Doesn't make changes to {@link #contents}</b>
     */
    public boolean hasSpace(@Nullable ItemStack item) {
        if (isEmpty(item)) {
            return true;
        }

        int remaining = item.getAmount();
        int maxStackSize = item.getMaxStackSize();

        // Check existing stacks that can be merged
        for (ItemStack storedItem : contents.values()) {
            if (matches(item, storedItem)) {
                int available = maxStackSize - storedItem.getAmount();
                remaining -= available;
                if (remaining <= 0) {
                    return true;
                }
            }
        }

        // Check empty slots
        int emptySlots = size - contents.size();
        int slotsNeeded = (int) Math.ceil((double) remaining / maxStackSize);

        return emptySlots >= slotsNeeded;
    }

    /**
     * Checks if there's space for multiple ItemStacks
     * <b>Doesn't make changes to {@link #contents}</b>
     */
    public boolean hasSpace(@NotNull Collection<ItemStack> items) {
        Preconditions.checkNotNull(items, "items cannot be null");
        if (items.isEmpty()) {
            return true;
        }

        // Create a simulated inventory to test
        InventoryUtility simulation = new InventoryUtility(this);

        for (ItemStack item : items) {
            if (isEmpty(item)) {
                continue;
            }

            if (!simulation.hasSpace(item)) {
                return false;
            }

            // Simulate adding the item
            simulation.simulateAdd(item);
        }

        return true;
    }

    /**
     * Removes a single ItemStack from the utility
     */
    public boolean removeStack(ItemStack item) {
        if (isEmpty(item)) {
            return true;
        }

        int toRemove = item.getAmount();

        for (Map.Entry<Integer, ItemStack> entry : new HashSet<>(contents.entrySet())) {
            ItemStack slotItem = entry.getValue();
            if (matches(item, slotItem)) {
                int slotAmount = slotItem.getAmount();
                if (slotAmount >= toRemove) {
                    if (slotAmount == toRemove) {
                        contents.remove(entry.getKey());
                    } else {
                        slotItem.setAmount(slotAmount - toRemove);
                    }
                    return true;
                } else {
                    contents.remove(entry.getKey());
                    toRemove -= slotAmount;
                }
            }
        }

        return toRemove == 0;
    }

    /**
     * Removes multiple ItemStacks from the utility
     */
    public boolean removeStack(Collection<ItemStack> items) {
        if (items == null || items.isEmpty()) {
            return true;
        }

        // First check if we have all items
        InventoryUtility check = new InventoryUtility(this);
        for (ItemStack item : items) {
            if (isEmpty(item)) {
                continue;
            }
            if (!check.removeStack(item)) {
                return false;
            }
        }

        // If we have all items, actually remove them
        for (ItemStack item : items) {
            if (isEmpty(item)) {
                continue;
            }
            removeStack(item);
        }

        return true;
    }

    /**
     * Adds a single ItemStack to the utility
     */
    public boolean addStack(ItemStack item) {
        if (isEmpty(item)) {
            return true;
        }

        if (!hasSpace(item)) {
            return false;
        }

        int remaining = item.getAmount();
        int maxStackSize = item.getMaxStackSize();

        // Try to merge with existing stacks
        for (ItemStack storedItem : contents.values()) {
            if (matches(item, storedItem)) {
                int available = maxStackSize - storedItem.getAmount();
                int toAdd = Math.min(remaining, available);
                storedItem.setAmount(storedItem.getAmount() + toAdd);
                remaining -= toAdd;
                if (remaining <= 0) {
                    return true;
                }
            }
        }

        // Add to empty slots
        for (int i = 0; i < size; i++) {
            if (!contents.containsKey(i) && remaining > 0) {
                int toAdd = Math.min(remaining, maxStackSize);
                ItemStack newStack = item.clone();
                newStack.setAmount(toAdd);
                contents.put(i, newStack);
                remaining -= toAdd;
            }
        }

        return remaining == 0;
    }

    /**
     * Adds multiple ItemStacks to the utility
     */
    public boolean addStack(Collection<ItemStack> items) {
        if (items == null || items.isEmpty()) {
            return true;
        }

        // First check if we have space for all items
        if (!hasSpace(items)) {
            return false;
        }

        // Add all items
        for (ItemStack item : items) {
            if (isEmpty(item)) {
                continue;
            }
            if (!addStack(item)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Applies the current state back to the original inventory
     */
    public void applyTo(Inventory inventory) {
        for(int i = 0; i < size; i++) {
            // catch any exception to minimize loss
            try {
                inventory.setItem(i, null);
            } catch (Exception ignored) {
            }
        }
        for (Map.Entry<Integer, ItemStack> entry : contents.entrySet()) {
            // catch any exception to minimize loss
            try {
                inventory.setItem(entry.getKey(), entry.getValue().clone());
            } catch (Exception ignored) {
            }
        }
    }


    // Helper methods

    private void simulateAdd(ItemStack item) {
        if(isEmpty(item)) {
            return;
        }

        int remaining = item.getAmount();
        int maxStackSize = item.getMaxStackSize();

        // Try to merge with existing stacks
        for (ItemStack storedItem : contents.values()) {
            if (matches(item, storedItem)) {
                int available = maxStackSize - storedItem.getAmount();
                int toAdd = Math.min(remaining, available);
                storedItem.setAmount(storedItem.getAmount() + toAdd);
                remaining -= toAdd;
                if (remaining <= 0) {
                    return;
                }
            }
        }

        // Add to empty slots
        int slot = 0;
        while (remaining > 0 && slot < size) {
            if (!contents.containsKey(slot)) {
                int toAdd = Math.min(remaining, maxStackSize);
                ItemStack newStack = item.clone();
                newStack.setAmount(toAdd);
                contents.put(slot, newStack);
                remaining -= toAdd;
            }
            slot++;
        }
    }
}