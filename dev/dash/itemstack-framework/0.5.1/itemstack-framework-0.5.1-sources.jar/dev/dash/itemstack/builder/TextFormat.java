package dev.dash.itemstack.builder;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NullMarked;

import java.util.regex.Pattern;

/**
 * Parses plain text into {@link Component}s, choosing between
 * <a href="https://docs.advntr.dev/minimessage/format.html">MiniMessage</a> and legacy
 * formatting codes automatically.
 *
 * <p>Detection rule: if the string contains a legacy section sign ({@code §}) or at least one
 * ampersand color/format code ({@code &0} - {@code &f}, {@code &k} - {@code &o}, {@code &r},
 * {@code &x} and hex variants such as {@code &#FF0000}), it is parsed with the legacy serializer;
 * otherwise it is parsed as MiniMessage. This makes {@code "<red>Name"} and {@code "&cName"} both
 * render as red text, while plain text without tags stays literal.</p>
 */
@NullMarked
public final class TextFormat {

    private static final MiniMessage MINI_MESSAGE = MiniMessage.miniMessage();
    private static final LegacyComponentSerializer SECTION_SERIALIZER = LegacyComponentSerializer.legacySection();
    private static final Pattern LEGACY_CODE = Pattern.compile("§[0-9a-fk-orxA-FK-ORX]|&(?:[0-9a-fk-orxA-FK-ORX]|#[0-9a-fA-F]{6})");

    private TextFormat() {
    }

    /**
     * Parses the given text as MiniMessage or legacy codes, according to the detection rule
     * of this class.
     *
     * @param text the raw text, may be null
     * @return the parsed component, or {@code null} if the input was null
     */
    public static @Nullable Component parse(@Nullable String text) {
        if(text == null) {
            return null;
        }

        if(looksLegacy(text)) {
            return SECTION_SERIALIZER.deserialize(text.replace('&', '§'));
        }

        return MINI_MESSAGE.deserialize(text);
    }

    /**
     * Parses the given text strictly as MiniMessage, ignoring legacy codes.
     *
     * @param text the raw text, may be null
     * @return the parsed component, or {@code null} if the input was null
     */
    public static @Nullable Component parseMiniMessage(@Nullable String text) {
        return text == null ? null : MINI_MESSAGE.deserialize(text);
    }

    /**
     * Serializes a component back to a MiniMessage string, suitable for the {@code name} and
     * {@code lore} keys of the YAML format.
     *
     * @param component the component, may be null
     * @return the MiniMessage string, or {@code null} if the input was null
     */
    public static @Nullable String serialize(@Nullable Component component) {
        return component == null ? null : MINI_MESSAGE.serialize(component);
    }

    /**
     * Turns off the italic style the client applies by default to custom item names and lore.
     * Italic is only set to {@code false} when the component does not decide it itself, so
     * explicit {@code <italic>} / {@code &o} still works.
     *
     * @param component the component, may be null
     * @return the component with italic disabled by default, or {@code null} if the input was null
     */
    public static @Nullable Component withoutItalic(@Nullable Component component) {
        return component == null ? null : component.decorationIfAbsent(TextDecoration.ITALIC, TextDecoration.State.FALSE);
    }

    /**
     * Reverses {@link #withoutItalic(Component)} on the root component, so that serialized item
     * text does not carry a {@code <!italic>} prefix on every line.
     */
    static Component stripDefaultItalic(Component component) {
        return component.decoration(TextDecoration.ITALIC) == TextDecoration.State.FALSE
                ? component.decoration(TextDecoration.ITALIC, TextDecoration.State.NOT_SET)
                : component;
    }

    private static boolean looksLegacy(String text) {
        return text.indexOf('§') >= 0 || LEGACY_CODE.matcher(text).find();
    }
}
