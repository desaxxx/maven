package dev.dash.itemstack.builder;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.jspecify.annotations.NullMarked;

/**
 * @deprecated use {@link SimpleItemBuilder}'s static factories directly
 *             ({@link SimpleItemBuilder#of(Material)}, {@link SimpleItemBuilder#from(ItemStack)},
 *             {@link SimpleItemBuilder#edit(ItemStack)}).
 */
@Deprecated(since = "0.4")
@SuppressWarnings({"unused", "deprecation"})
@NullMarked
public class ItemFactory {

    public static SimpleItemBuilder simple(Material material) {
        return SimpleItemBuilder.of(material);
    }
    public static SimpleItemBuilder simple(ItemStack itemStack) {
        return SimpleItemBuilder.from(itemStack);
    }
    public static SimpleItemBuilder edit(ItemStack itemStack) {
        return SimpleItemBuilder.edit(itemStack);
    }
}
