package dev.dash.itemstack.inventory;

import com.google.common.base.Preconditions;
import dev.dash.common.Requirement;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class ItemIterableRequirement extends Requirement<Iterable<ItemRequirement>> {

    public ItemIterableRequirement(@NotNull Iterable<ItemRequirement> requirements) {
        super(requirements);
        Preconditions.checkNotNull(requirements, "requirements cannot be null");
    }

    public static @NotNull ItemIterableRequirement of(@NotNull Iterable<ItemStack> stacks) {
        List<ItemRequirement> requirements = new ArrayList<>();

        for(ItemStack stack : stacks) {
            requirements.add(new ItemRequirement(stack));
        }

        return new ItemIterableRequirement(requirements);
    }

    public boolean fulfills(@NotNull Player player) {
        InventoryUtility inventoryUtility = new InventoryUtility(player.getInventory());

        for(ItemRequirement itemRequirement : element) {
            if(!inventoryUtility.removeStack(itemRequirement.getRequirement())) {
                return false;
            }
        }

        return true;
    }

    /** @return unfulfilled item requirements. Empty list if fulfilled. */
    public @NotNull List<ItemRequirement> fulfillsReturnFail(@NotNull Player player) {
        InventoryUtility inventoryUtility = new InventoryUtility(player.getInventory());

        List<ItemRequirement> unfulfilled = new ArrayList<>();
        for(ItemRequirement itemRequirement : element) {
            if(!inventoryUtility.removeStack(itemRequirement.getRequirement())) {
                unfulfilled.add(itemRequirement);
            }
        }

        return unfulfilled;
    }

    public void fine(@NotNull Player player) {
        InventoryUtility inventoryUtility = new InventoryUtility(player.getInventory());

        for(ItemRequirement itemRequirement : element) {
            inventoryUtility.removeStack(itemRequirement.getRequirement());
        }

        inventoryUtility.applyTo(player.getInventory());
    }
}
