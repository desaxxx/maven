package dev.dash.itemstack.builder;

import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableMultimap;
import com.destroystokyo.paper.profile.PlayerProfile;
import com.destroystokyo.paper.profile.ProfileProperty;
import dev.dash.common.VersionUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemRarity;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NullMarked;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.function.Consumer;

/**
 * Base class for all item builders. Holds and mutates a single {@link ItemStack} and exposes a
 * fluent, self-typed API ({@code Self extends AbstractItemBuilder<Self>}) so that subclasses
 * inherit covariant return types without override boilerplate.
 *
 * <p>Instances created through the ordinary factories own their stack: {@link #build()} returns a
 * clone, so a builder can keep being edited after building without affecting previously built
 * items. Instances created through {@code edit(...)} style factories alias the caller's stack:
 * every method mutates it in place and {@link #build()} returns that same instance.</p>
 *
 * @param <Self> the concrete builder type, used for fluent chaining
 */
@NullMarked
public abstract class AbstractItemBuilder<Self extends AbstractItemBuilder<Self>> {

    /**
     * Key of the zero-value attribute modifier used to make {@link ItemFlag#HIDE_ATTRIBUTES}
     * actually hide attributes on items that have none (required since 1.20.5).
     */
    protected static final NamespacedKey UNSAFE_ITEMFLAG_KEY =
            Objects.requireNonNull(NamespacedKey.fromString("dash:unsafe_itemflag"), "hardcoded key must be valid");

    protected final ItemStack stack;
    private final boolean aliased;

    protected AbstractItemBuilder(ItemStack base) {
        this(base, false);
    }

    protected AbstractItemBuilder(ItemStack base, boolean aliased) {
        Preconditions.checkNotNull(base, "base cannot be null");
        this.stack = base;
        this.aliased = aliased;
    }

    /** @return this builder typed as its concrete class */
    protected abstract Self self();

    /**
     * @return the built item. For owned builders this is a clone of the internal stack; for
     *         aliased (edit) builders it is the aliased stack itself.
     */
    public ItemStack build() {
        return aliased ? stack : stack.clone();
    }

    /**
     * @return the internal stack, without cloning. Mutating it directly affects this builder.
     */
    protected ItemStack rawStack() {
        return stack;
    }

    protected @Nullable ItemMeta getMeta() {
        return stack.getItemMeta();
    }

    /**
     * Sets the display name with the client's default italic turned off (see
     * {@link TextFormat#withoutItalic(Component)}). {@code null} clears it.
     */
    protected static void setDisplayName(ItemMeta meta, @Nullable Component name) {
        meta.displayName(TextFormat.withoutItalic(name));
    }

    /**
     * Sets the lore with the client's default italic turned off on every line (see
     * {@link TextFormat#withoutItalic(Component)}). {@code null} clears it.
     */
    protected static void setLore(ItemMeta meta, @Nullable List<Component> lore) {
        if(lore == null) {
            meta.lore(null);
            return;
        }
        List<Component> lines = new ArrayList<>(lore.size());
        for(Component line : lore) {
            lines.add(TextFormat.withoutItalic(line));
        }
        meta.lore(lines);
    }

    /**
     * Applies the given consumer to the stack's meta and writes it back.
     *
     * @throws IllegalStateException if the stack has no meta (e.g. {@link Material#AIR});
     *         the previous silent no-op behavior hid all further edits
     */
    protected void editMeta(Consumer<? super ItemMeta> consumer) {
        Preconditions.checkNotNull(consumer, "consumer cannot be null");
        ItemMeta meta = getMeta();
        if(meta == null) {
            throw new IllegalStateException("ItemStack has no ItemMeta (material: " + stack.getType() + "), meta cannot be edited");
        }
        consumer.accept(meta);
        stack.setItemMeta(meta);
    }

    @Deprecated // Because of Paper
    public Self type(Material type) {
        stack.setType(type);
        return self();
    }

    public Self amount(int amount) {
        stack.setAmount(amount);
        return self();
    }

    /**
     * Sets the display name. {@code null} clears it.
     */
    public Self name(@Nullable Component name) {
        editMeta(meta -> setDisplayName(meta, name));
        return self();
    }

    /**
     * Sets the lore. {@code null} clears it.
     */
    public Self lore(@Nullable List<Component> lore) {
        editMeta(meta -> setLore(meta, lore));
        return self();
    }

    public Self enchant(Enchantment enchantment, int level) {
        editMeta(meta -> meta.addEnchant(enchantment, level, true));
        return self();
    }

    /** Removes a single enchantment, if present. */
    public Self disenchant(Enchantment enchantment) {
        editMeta(meta -> meta.removeEnchant(enchantment));
        return self();
    }

    /** Removes all enchantments. */
    public Self disenchantAll() {
        editMeta(ItemMeta::removeEnchantments);
        return self();
    }

    /**
     * Adds a stored enchantment (enchanted book). Requires {@link EnchantmentStorageMeta}.
     *
     * @throws IllegalStateException if the item cannot store enchantments
     */
    public Self storedEnchant(Enchantment enchantment, int level) {
        editMeta(meta -> {
            if(!(meta instanceof EnchantmentStorageMeta storageMeta)) {
                throw new IllegalStateException("ItemStack does not have EnchantmentStorageMeta (material: " + stack.getType() + ")");
            }
            storageMeta.addStoredEnchant(enchantment, level, true);
        });
        return self();
    }

    public Self flags(ItemFlag... flags) {
        editMeta(meta -> meta.addItemFlags(flags));
        return self();
    }

    public Self flags(Collection<ItemFlag> flags) {
        return flags(flags.toArray(new ItemFlag[0]));
    }

    /** Removes the given item flags, if present. */
    public Self removeFlags(ItemFlag... flags) {
        editMeta(meta -> meta.removeItemFlags(flags));
        return self();
    }

    public Self removeFlags(Collection<ItemFlag> flags) {
        return removeFlags(flags.toArray(new ItemFlag[0]));
    }

    /**
     * Adds item flags and applies the zero-value attribute modifier hack so that
     * {@link ItemFlag#HIDE_ATTRIBUTES} works on items without attribute modifiers (needed since
     * 1.20.5). The hack is only added once per item.
     */
    public Self flagsUnsafe(ItemFlag... flags) {
        editMeta(meta -> {
            if(VersionUtil.getBukkitVersion().isAtLeast(1, 20, 6)) {
                boolean alreadyApplied = false;
                Collection<AttributeModifier> existingModifiers = meta.getAttributeModifiers(Attribute.ARMOR); // may be null
                if(existingModifiers != null) {
                    for(AttributeModifier modifier : existingModifiers) {
                        if(UNSAFE_ITEMFLAG_KEY.equals(modifier.getKey())) {
                            alreadyApplied = true;
                            break;
                        }
                    }
                }
                if(!alreadyApplied) {
                    meta.addAttributeModifier(Attribute.ARMOR,
                            new AttributeModifier(UNSAFE_ITEMFLAG_KEY, 0, AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.ANY));
                }
            }
            meta.addItemFlags(flags);
        });
        return self();
    }

    public Self flagsUnsafe(Collection<ItemFlag> flags) {
        return flagsUnsafe(flags.toArray(new ItemFlag[0]));
    }

    public Self unbreakable(boolean unbreakable) {
        editMeta(meta -> meta.setUnbreakable(unbreakable));
        return self();
    }

    /**
     * Overrides the enchantment glint. {@code null} removes the override (default vanilla
     * behavior).
     */
    public Self glint(@Nullable Boolean glint) {
        editMeta(meta -> meta.setEnchantmentGlintOverride(glint));
        return self();
    }

    public Self rarity(ItemRarity rarity) {
        Preconditions.checkNotNull(rarity, "rarity cannot be null");
        editMeta(meta -> meta.setRarity(rarity));
        return self();
    }

    /**
     * Overrides the max stack size. {@code null} removes the override.
     */
    public Self maxStackSize(@Nullable Integer maxStackSize) {
        editMeta(meta -> meta.setMaxStackSize(maxStackSize));
        return self();
    }

    /**
     * Sets the custom model data. {@code null} clears it.
     */
    public Self customModelData(@Nullable Integer customModelData) {
        editMeta(meta -> meta.setCustomModelData(customModelData));
        return self();
    }

    /**
     * Sets the item model (1.21.2+). {@code null} clears it.
     */
    public Self itemModel(@Nullable NamespacedKey itemModel) {
        editMeta(meta -> meta.setItemModel(itemModel));
        return self();
    }

    /**
     * Sets whether the tooltip should be hidden.
     */
    public Self hideTooltip(boolean hideTooltip) {
        editMeta(meta -> meta.setHideTooltip(hideTooltip));
        return self();
    }

    /**
     * Sets the damage value. Requires {@link Damageable}.
     *
     * @throws IllegalStateException if the item has no damage meta
     */
    public Self damage(int damage) {
        editMeta(meta -> {
            if(!(meta instanceof Damageable damageable)) {
                throw new IllegalStateException("ItemStack does not have Damageable meta (material: " + stack.getType() + ")");
            }
            damageable.setDamage(damage);
        });
        return self();
    }

    /**
     * Sets the color. Requires {@link LeatherArmorMeta} (leather and dyeable armor).
     *
     * @throws IllegalStateException if the item has no leather armor meta
     */
    public Self color(@Nullable Color color) {
        editMeta(meta -> {
            if(!(meta instanceof LeatherArmorMeta armorMeta)) {
                throw new IllegalStateException("ItemStack does not have LeatherArmorMeta (material: " + stack.getType() + ")");
            }
            armorMeta.setColor(color);
        });
        return self();
    }

    public Self attribute(Attribute attribute, AttributeModifier modifier) {
        Preconditions.checkNotNull(attribute, "attribute cannot be null");
        Preconditions.checkNotNull(modifier, "modifier cannot be null");
        editMeta(meta -> meta.addAttributeModifier(attribute, modifier));
        return self();
    }

    /** Removes all attribute modifiers. */
    public Self clearAttributes() {
        editMeta(meta -> meta.setAttributeModifiers(ImmutableMultimap.of()));
        return self();
    }

    /**
     * Edits the persistent data container directly.
     */
    public Self pdc(Consumer<PersistentDataContainer> pdcConsumer) {
        Preconditions.checkNotNull(pdcConsumer, "pdcConsumer cannot be null");
        editMeta(meta -> pdcConsumer.accept(meta.getPersistentDataContainer()));
        return self();
    }

    /** Sets the skull owner by player name (resolved lazily by the server). */
    public Self skullOwner(String ownerName) {
        Preconditions.checkNotNull(ownerName, "ownerName cannot be null");
        return skullProfile(Bukkit.createProfile(ownerName));
    }

    /** Sets the skull owner by unique id. */
    public Self skullOwner(UUID ownerId) {
        Preconditions.checkNotNull(ownerId, "ownerId cannot be null");
        return skullProfile(Bukkit.createProfile(ownerId));
    }

    /** Sets the skull owner by unique id and player name. */
    public Self skullOwner(UUID ownerId, String ownerName) {
        Preconditions.checkNotNull(ownerId, "ownerId cannot be null");
        Preconditions.checkNotNull(ownerName, "ownerName cannot be null");
        return skullProfile(Bukkit.createProfile(ownerId, ownerName));
    }

    /**
     * Sets the skull texture. Accepts either a base64 texture value (as used by
     * <a href="https://minecraft-heads.com">minecraft-heads</a>) or a
     * {@code https://textures.minecraft.net/texture/...} url, which is wrapped into the
     * standard base64 format.
     *
     * @throws IllegalStateException if the item has no skull meta
     */
    public Self skullTexture(String texture) {
        Preconditions.checkNotNull(texture, "texture cannot be null");
        String value = texture.startsWith("http") ? wrapTextureUrl(texture) : texture;
        editMeta(meta -> {
            if(!(meta instanceof SkullMeta skullMeta)) {
                throw new IllegalStateException("ItemStack does not have SkullMeta (material: " + stack.getType() + ")");
            }
            PlayerProfile currentProfile = skullMeta.getPlayerProfile();
            PlayerProfile profile = currentProfile != null ? currentProfile : Bukkit.createProfile(UUID.randomUUID());
            profile.setProperty(new ProfileProperty("textures", value));
            skullMeta.setPlayerProfile(profile);
        });
        return self();
    }

    /** Sets the full {@link PlayerProfile} of a skull. */
    public Self skullProfile(PlayerProfile profile) {
        Preconditions.checkNotNull(profile, "profile cannot be null");
        editMeta(meta -> {
            if(!(meta instanceof SkullMeta skullMeta)) {
                throw new IllegalStateException("ItemStack does not have SkullMeta (material: " + stack.getType() + ")");
            }
            skullMeta.setPlayerProfile(profile);
        });
        return self();
    }

    private static String wrapTextureUrl(String url) {
        String json = "{\"textures\":{\"SKIN\":{\"url\":\"" + url.replace("\"", "") + "\"}}}";
        return Base64.getEncoder().encodeToString(json.getBytes(StandardCharsets.UTF_8));
    }
}
