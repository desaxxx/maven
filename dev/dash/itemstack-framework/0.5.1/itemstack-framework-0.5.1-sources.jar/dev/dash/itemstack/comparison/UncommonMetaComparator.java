package dev.dash.itemstack.comparison;

import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;

@FunctionalInterface
public interface UncommonMetaComparator<Meta extends ItemMeta> {

    boolean matches(@NotNull ItemProperty property, @NotNull ItemMeta first, @NotNull ItemMeta second);
}
