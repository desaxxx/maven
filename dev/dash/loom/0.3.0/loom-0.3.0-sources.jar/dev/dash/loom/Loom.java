package dev.dash.loom;

import dev.dash.common.placeholder.PlaceholderRegistry;
import dev.dash.itemstack.builder.SimpleItemBuilder;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.sound.Sound;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.jspecify.annotations.Nullable;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.logging.Level;

/**
 * Entry point of Loom.
 *
 * <p>When Loom is shaded into a plugin, calling {@link #install(Plugin)} is optional: the
 * providing plugin is detected on first use. Call it explicitly when the detection is not
 * possible (tests, unusual class loaders) or when you want the listener registered eagerly.</p>
 *
 * <p>Loom runs on Paper and Folia. It schedules through
 * <a href="https://github.com/TechnicallyCoded/FoliaLib">FoliaLib</a>, which the plugin using
 * Loom must add (and relocate) itself. Everything a menu does runs on its player's thread: the
 * main thread on Paper, the thread of the player's region on Folia. "The player's thread" in
 * these docs means exactly that.</p>
 */
public final class Loom {

    private static volatile @Nullable Plugin plugin;
    private static volatile @Nullable LoomScheduler scheduler;
    private static @Nullable LoomListener listener;
    private static @Nullable PromptListener promptListener;

    /** Depth of click / close dispatches on this thread. Opening inside them is deferred. */
    private static final ThreadLocal<int[]> dispatching = ThreadLocal.withInitial(() -> new int[1]);

    /** True while {@link #uninstall()} closes the open menus. */
    static volatile boolean shuttingDown;

    /** Players being kicked or quitting; removed when they join again. */
    private static final Set<UUID> leaving = ConcurrentHashMap.newKeySet();

    private static @Nullable PlaceholderRegistry placeholders;
    private static volatile int historyLimit = 20;
    private static volatile boolean debug;
    private static volatile @Nullable Sound defaultSound;
    private static volatile Sound denySound = Sound.sound(Key.key("entity.villager.no"), Sound.Source.MASTER, 1f, 1f);
    private static volatile double slowRenderMillis = 10;

    private Loom() {
    }

    /**
     * Registers Loom's listener for the given plugin. Calling it again with the same plugin
     * does nothing.
     *
     * @throws IllegalStateException if Loom is already installed by another plugin, or FoliaLib
     * is missing from the plugin
     */
    public static synchronized void install(Plugin plugin) {
        Plugin installed = Loom.plugin;
        if(installed != null) {
            if(installed == plugin) {
                return;
            }
            throw new IllegalStateException("Loom is already installed by " + installed.getName());
        }
        try {
            scheduler = new LoomScheduler(plugin);
        } catch(NoClassDefFoundError e) {
            throw new IllegalStateException("Loom needs FoliaLib: add com.tcoded:FoliaLib to " + plugin.getName()
                    + " and shade it into the plugin jar", e);
        }
        Loom.plugin = plugin;
        listener = new LoomListener(plugin);
        promptListener = new PromptListener();
        Bukkit.getPluginManager().registerEvents(listener, plugin);
        Bukkit.getPluginManager().registerEvents(promptListener, plugin);
    }

    /**
     * Closes every open Loom menu and unregisters the listener. Called automatically when the
     * owning plugin is disabled.
     *
     * <p>Menus can only be closed from their player's thread. On Paper that is always the case
     * here; on Folia, menus of players this thread cannot reach are left open (their input
     * items stay in the menu) and a warning says how many.</p>
     */
    public static synchronized void uninstall() {
        LoomScheduler current = scheduler;
        if(plugin == null || current == null) {
            return;
        }
        shuttingDown = true;
        try {
            int unreachable = 0;
            for(Player player : Bukkit.getOnlinePlayers()) {
                if(!current.owns(player)) {
                    if(View.shown(player) != null || Prompt.hasSession(player) || parked.containsKey(player.getUniqueId())) {
                        unreachable++;
                    }
                    continue;
                }
                Prompt.abandon(player);
                if(View.of(player) != null) {
                    player.closeInventory();
                }
                releaseParked(player); // e.g. a menu waiting behind a prompt that was just closed
            }
            if(unreachable > 0) {
                warn("Loom could not close the menus of " + unreachable + " player(s) while uninstalling: "
                        + "they are not owned by this thread");
            }
        } finally {
            shuttingDown = false;
            if(listener != null) {
                HandlerList.unregisterAll(listener);
            }
            if(promptListener != null) {
                HandlerList.unregisterAll(promptListener);
            }
            current.shutdown();
            plugin = null;
            scheduler = null;
            listener = null;
            promptListener = null;
            dispatching.remove();
            leaving.clear();
            parked.clear();
            Prompt.forgetAll();
            View.forgetAll();
        }
    }

    /** Creates a reusable menu from a render function. */
    public static Menu menu(Consumer<Ui> renderer) {
        return Menu.of(renderer);
    }

    /**
     * Builds and opens a one-off menu.
     *
     * @return completes with whether the menu was shown; see {@link Menu#open(Player)}
     */
    public static CompletableFuture<Boolean> open(Player player, Consumer<Ui> renderer) {
        return Menu.of(renderer).open(player);
    }

    /**
     * Placeholder resolver used by {@link Ui#text}, {@link Ui#item} and {@link Ui#title(String)}.
     * Default: {@link PlaceholderRegistry#DEFAULT}, which uses PlaceholderAPI when it is
     * installed (add it to {@code softdepend} so it loads first).
     */
    public static PlaceholderRegistry placeholders() {
        PlaceholderRegistry current = placeholders;
        return current != null ? current : PlaceholderRegistry.DEFAULT;
    }

    /** Replaces the placeholder resolver, e.g. with one that has your own providers. */
    public static void placeholders(PlaceholderRegistry registry) {
        placeholders = Objects.requireNonNull(registry, "registry");
    }

    /** How many menus {@link Click#back()} can go back through. */
    public static int historyLimit() {
        return historyLimit;
    }

    /**
     * Sets how many menus {@link Click#back()} can go back through; older ones are forgotten
     * so long navigation chains do not keep every menu in memory. Default: 20.
     */
    public static void historyLimit(int limit) {
        if(limit < 1) {
            throw new IllegalArgumentException("history limit must be at least 1");
        }
        historyLimit = limit;
    }

    /** Creates a signal that can be shared by any number of menus and players. */
    public static <T extends @Nullable Object> Signal<T> signal(T initial) {
        return Signal.of(initial);
    }

    /** Like {@link #signal(Object)}, with a name for {@link #debug(boolean) debug} logs. */
    public static <T extends @Nullable Object> Signal<T> signal(String name, T initial) {
        return Signal.of(name, initial);
    }

    // ---------------------------------------------------------------- sounds

    /** Sound of buttons in menus that set none themselves, or null for silence (the default). */
    public static @Nullable Sound defaultSound() {
        return defaultSound;
    }

    /**
     * Sets the sound of buttons (with a handler) in every menu that has no sound of its own, e.g.
     * {@code Sound.sound(Key.key("ui.button.click"), Sound.Source.MASTER, 1f, 1f)}. Null turns it
     * off. Default: null.
     */
    public static void defaultSound(@Nullable Sound sound) {
        defaultSound = sound;
    }

    /** Sound of {@link Click#deny()} in menus that set none. Default: the villager "no" sound. */
    public static Sound denySound() {
        return denySound;
    }

    public static void denySound(Sound sound) {
        denySound = Objects.requireNonNull(sound, "sound");
    }

    // ---------------------------------------------------------------- debugging

    /** True if every menu logs its renders and ignored clicks. */
    public static boolean debug() {
        return debug;
    }

    /**
     * Logs every render (time, what triggered it, how many slots changed) and every ignored
     * click (cooldown, double click, busy, blocked by the safety rules) of every menu. Use
     * {@link Menu#debug(boolean)} for a single menu. Default: off.
     */
    public static void debug(boolean enabled) {
        debug = enabled;
    }

    /** Renders slower than this are reported once per menu, even with debug off. */
    public static double slowRenderThreshold() {
        return slowRenderMillis;
    }

    /**
     * Sets the time, in milliseconds, above which a render is reported as slow: once per menu,
     * also when debug is off. A menu's very first render is not measured, as it includes class
     * loading and JIT warm-up. 0 turns the warning off. Default: 10.
     */
    public static void slowRenderThreshold(double millis) {
        if(millis < 0) {
            throw new IllegalArgumentException("threshold must be >= 0");
        }
        slowRenderMillis = millis;
    }

    /** A snapshot of what Loom holds right now, e.g. to look for leaks. Safe from any thread. */
    public static Stats stats() {
        int open = 0;
        for(Player player : Bukkit.getOnlinePlayers()) {
            if(isViewing(player)) {
                open++;
            }
        }
        int parkedViews = 0;
        for(Set<View> views : parked.values()) {
            parkedViews += views.size();
        }
        return new Stats(open, parkedViews, Prompt.sessions());
    }

    /**
     * @param openMenus players looking at a Loom menu
     * @param parkedMenus menus navigated away from that still hold input items
     * @param prompts open {@link Prompt}s
     */
    public record Stats(int openMenus, int parkedMenus, int prompts) {
    }

    /**
     * Measures how long the menu the player is looking at takes to redraw: it is redrawn
     * {@code renders} times in a row after a warm-up, and each redraw is timed (render function
     * plus comparing the result with the inventory; nothing changes, so no slot is sent). Use it
     * to compare menus or to estimate their cost: a menu redrawn by {@code n} viewers per tick
     * adds about {@code n × average} to each tick. Only on the player's thread.
     *
     * @throws IllegalStateException if the player is not looking at a Loom menu, or this is not
     * the player's thread
     */
    public static RenderStats measure(Player player, int renders) {
        Objects.requireNonNull(player, "player");
        if(renders < 1) {
            throw new IllegalArgumentException("renders must be >= 1");
        }
        if(!owns(player)) {
            throw new IllegalStateException("Loom.measure must be called on the player's thread "
                    + "(the main thread on Paper, the player's region thread on Folia)");
        }
        View view = View.of(player);
        if(view == null) {
            throw new IllegalStateException(player.getName() + " is not looking at a Loom menu");
        }
        long[] times = view.measure(Math.max(20, renders / 5), renders);
        java.util.Arrays.sort(times);
        long total = 0;
        for(long time : times) {
            total += time;
        }
        return new RenderStats(view.menu().displayName(), renders, millis(total / (double) renders),
                millis(times[(renders - 1) / 2]), millis(times[(int) Math.ceil(renders * 0.95) - 1]),
                millis(times[renders - 1]));
    }

    private static double millis(double nanos) {
        return nanos / 1_000_000.0;
    }

    /** Result of {@link #measure}. Times are in milliseconds. */
    public record RenderStats(String menu, int renders, double average, double median, double p95, double max) {

        @Override
        public String toString() {
            return String.format(java.util.Locale.ROOT, "%s: avg %.3f ms, median %.3f ms, p95 %.3f ms, max %.3f ms (%d renders)",
                    menu, average, median, p95, max, renders);
        }
    }

    /**
     * Quick icon. Name and lore accept MiniMessage ({@code <red>}) or legacy ({@code &c}) text.
     */
    public static ItemStack item(Material material, String name, String... lore) {
        return SimpleItemBuilder.of(material).name(name).lore(lore).build();
    }

    /** Quick icon with an empty-looking name, handy for fillers. */
    public static ItemStack filler(Material material) {
        return SimpleItemBuilder.of(material).hideTooltip(true).build();
    }

    /**
     * True if the player is looking at a Loom menu right now. Safe from any thread; from another
     * thread than the player's, the answer can be a tick behind.
     */
    public static boolean isViewing(Player player) {
        return owns(player) ? View.of(player) != null : View.shown(player) != null;
    }

    /** The menu the player is looking at, from the player's thread exactly, otherwise as last shown. */
    private static @Nullable View viewOf(Player player) {
        return owns(player) ? View.of(player) : View.shown(player);
    }

    // ---------------------------------------------------------------- managing open menus

    /**
     * Players looking at the menu right now. Players who only have it in their history (they
     * opened a {@link Confirm} or a submenu from it) are not included. Matched by identity, so
     * keep the {@code Menu} in a field; one-off {@link #open(Player, Consumer)} menus cannot be
     * found. Safe from any thread; players whose thread is not this one are reported as of
     * their last render, which can be a tick behind.
     */
    public static List<Player> viewers(Menu menu) {
        Objects.requireNonNull(menu, "menu");
        List<Player> viewers = new ArrayList<>();
        for(Player player : Bukkit.getOnlinePlayers()) {
            View view = viewOf(player);
            if(view != null && view.menu() == menu) {
                viewers.add(player);
            }
        }
        return viewers;
    }

    /**
     * Redraws the menu for everyone looking at it, e.g. after a config reload changed data that
     * is not held in a signal. Safe from any thread.
     */
    public static void refreshAll(Menu menu) {
        Objects.requireNonNull(menu, "menu");
        for(View view : View.allShown()) {
            if(view.menu() == menu) {
                view.invalidate("Loom.refreshAll"); // redraws on the viewer's thread
            }
        }
    }

    /**
     * Closes the menu for everyone, e.g. when a shop is disabled. Also closes what was opened
     * from it (a {@link Confirm}, a {@link Prompt}, a submenu), so nobody can get back into it,
     * and views of it that wait in someone's history are never shown again. Input items are
     * handed back. Close handlers get {@link CloseReason#PLUGIN}. Safe from any thread.
     *
     * <p>Each player is handled on their own thread. On Paper that is the main thread, right
     * away when called from it outside a click or close handler.</p>
     *
     * @return completes, once every player was handled, with the number of players whose menu
     * or prompt was closed; 0 if nobody was in the menu. It completes on the thread of the last
     * player handled (the main thread on Paper). Ignore it if you do not care.
     */
    public static CompletableFuture<Integer> closeAll(Menu menu) {
        Objects.requireNonNull(menu, "menu");
        menu.retireViews();
        Set<Player> targets = new HashSet<>();
        for(View view : View.allShown()) {
            targets.add(view.player());
        }
        targets.addAll(Prompt.sessionPlayers());
        CompletableFuture<Integer> closed = new CompletableFuture<>();
        if(targets.isEmpty()) {
            closed.complete(0);
            return closed;
        }
        AtomicInteger count = new AtomicInteger();
        AtomicInteger remaining = new AtomicInteger(targets.size());
        Runnable handled = () -> {
            if(remaining.decrementAndGet() == 0) {
                closed.complete(count.get());
            }
        };
        for(Player player : targets) {
            sync(player, () -> {
                try {
                    View view = View.of(player);
                    if(view != null) {
                        if(view.leadsTo(menu)) {
                            player.closeInventory();
                            count.incrementAndGet();
                        }
                    } else if(Prompt.abandonIfLeadsTo(player, menu)) {
                        later(player, () -> releaseParkedIfAway(player));
                        count.incrementAndGet();
                    }
                } finally {
                    handled.run();
                }
            }, handled);
        }
        return closed;
    }

    // ---------------------------------------------------------------- parked input items

    /**
     * Views navigated away from that still hold input items, per player. A player's set is only
     * changed on that player's thread.
     */
    private static final Map<UUID, Set<View>> parked = new ConcurrentHashMap<>();

    static void park(Player player, View view) {
        parked.computeIfAbsent(player.getUniqueId(), id -> ConcurrentHashMap.newKeySet()).add(view);
    }

    static void unpark(Player player, View view) {
        Set<View> views = parked.get(player.getUniqueId());
        if(views != null) {
            views.remove(view);
            if(views.isEmpty()) {
                parked.remove(player.getUniqueId());
            }
        }
    }

    /** Gives back every parked input item of the player. */
    static void releaseParked(Player player) {
        Set<View> views = parked.remove(player.getUniqueId());
        if(views != null) {
            for(View view : List.copyOf(views)) {
                view.releaseParked();
            }
        }
    }

    /** Gives back parked items if the player is no longer in a Loom menu or prompt. */
    static void releaseParkedIfAway(Player player) {
        if(parked.containsKey(player.getUniqueId()) && View.of(player) == null && !Prompt.isOpen(player)) {
            releaseParked(player);
        }
    }

    static boolean isLeaving(Player player) {
        return leaving.contains(player.getUniqueId());
    }

    static void leaving(UUID player, boolean leaving) {
        if(leaving) {
            Loom.leaving.add(player);
        } else {
            Loom.leaving.remove(player);
        }
    }

    static Plugin plugin() {
        Plugin current = plugin;
        if(current != null) {
            return current;
        }
        Plugin detected;
        try {
            detected = JavaPlugin.getProvidingPlugin(Loom.class);
        } catch(IllegalArgumentException | IllegalStateException e) {
            throw new IllegalStateException("Loom could not detect its plugin, call Loom.install(plugin) in onEnable", e);
        }
        install(detected); // its own errors (FoliaLib missing, another plugin) are clear as they are
        return Objects.requireNonNull(plugin, "plugin");
    }

    // ---------------------------------------------------------------- threads

    static LoomScheduler scheduler() {
        plugin();
        LoomScheduler current = scheduler;
        if(current == null) {
            throw new IllegalStateException("Loom is not installed");
        }
        return current;
    }

    /** True if this thread may touch the player: the main thread on Paper, the player's region thread on Folia. */
    static boolean owns(Player player) {
        LoomScheduler current = scheduler;
        return current != null ? current.owns(player) : Bukkit.isPrimaryThread();
    }

    /** Ticks, for cooldowns and timing. Only differences between two values are meaningful. */
    static long currentTick() {
        LoomScheduler current = scheduler;
        return current != null ? current.currentTick() : Bukkit.getCurrentTick();
    }

    static void beginDispatch() {
        dispatching.get()[0]++;
    }

    static void endDispatch() {
        dispatching.get()[0]--;
    }

    /**
     * Runs the task on the player's thread: now if this is that thread and no click or close
     * handler is running, otherwise on the next tick.
     */
    static void sync(Player player, Runnable task) {
        sync(player, task, null);
    }

    /** Like {@link #sync(Player, Runnable)}; {@code retired} runs instead if the player is gone first. */
    static void sync(Player player, Runnable task, @Nullable Runnable retired) {
        if(owns(player) && dispatching.get()[0] == 0) {
            task.run();
        } else {
            later(player, task, retired);
        }
    }

    /** Runs the supplier off the server threads. */
    static <T extends @Nullable Object> CompletableFuture<T> supplyAsync(java.util.function.Supplier<T> supplier) {
        return CompletableFuture.supplyAsync(supplier, scheduler().async());
    }

    /** Runs the task on the player's thread on the next tick. Dropped if the player is gone first (Folia). */
    static void later(Player player, Runnable task) {
        later(player, task, null);
    }

    /**
     * Runs the task on the player's thread on the next tick. If the player is gone before it can
     * run (only possible on Folia), {@code retired} runs instead, on any thread.
     */
    static void later(Player player, Runnable task, @Nullable Runnable retired) {
        scheduler().run(player, task, retired);
    }

    static void log(String message, Throwable error) {
        plugin().getLogger().log(Level.SEVERE, message, error);
    }

    static void debugLog(String message) {
        plugin().getLogger().info("[Loom debug] " + message);
    }

    static void warn(String message) {
        plugin().getLogger().warning(message);
    }
}
