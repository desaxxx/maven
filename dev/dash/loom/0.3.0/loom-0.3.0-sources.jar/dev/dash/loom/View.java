package dev.dash.loom;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import com.tcoded.folialib.wrapper.task.WrappedTask;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.jspecify.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;

/**
 * One menu shown to one player. Owns the state, the inventory and the render loop.
 * Everything except {@link #invalidate(Object)} runs on the player's thread: the main thread on
 * Paper, the player's region thread on Folia.
 */
final class View {

    /** The view whose render function runs on this thread. */
    private static final ThreadLocal<@Nullable View> RENDERING = new ThreadLocal<>();

    /** The view each player was last shown, readable from any thread. Removed when it closes. */
    private static final Map<UUID, View> SHOWN = new ConcurrentHashMap<>();

    private final Menu menu;
    private final int generation;
    private final Player player;
    private @Nullable View previous;

    private final List<Signal<?>> states = new ArrayList<>();
    private final Map<String, Object> keyedStates = new HashMap<>();
    private final Set<Signal<?>> watching = new HashSet<>();
    private int stateCalls = -1;
    private boolean warnedStateOrder;

    /** Input slots by slot number, kept across renders; the frame says which ones are active. */
    private final Map<Integer, InputSlot> inputs = new TreeMap<>();
    private Map<Integer, Predicate<ItemStack>> activeInputs = Map.of();

    private @Nullable Inventory inventory;
    private @Nullable Button[] buttons = new Button[0];
    private Component title = Component.empty();
    private int rows;
    private @Nullable Consumer<Close> onClose;
    private @Nullable ClickHandler onInventoryClick;
    private int refreshPeriod;
    private @Nullable WrappedTask refreshTask;

    private long openedTick = -1;
    private long lastClickTick = Long.MIN_VALUE / 2;

    private volatile boolean closed = true;
    private boolean batching;
    private boolean dirty;
    private boolean navigating;
    private boolean discarding;
    private final AtomicBoolean redrawScheduled = new AtomicBoolean();
    private final AtomicBoolean inputSyncScheduled = new AtomicBoolean();

    /** Running {@link ClickTask}s; while any runs, clicks are ignored and inputs locked. */
    private int busyCount;
    private final Signal<Boolean> busy = Signal.of("busy", false);

    // debugging: what asked for the next redraw (only collected in debug mode), and warnings
    private static final int RENDER_LOOP_LIMIT = 40; // renders per second
    private final Set<String> causes = new LinkedHashSet<>();
    private boolean warnedLoop;
    private long renderWindowStart = Long.MIN_VALUE / 2;
    private int rendersInWindow;

    View(Menu menu, Player player, @Nullable View previous) {
        this.menu = menu;
        this.generation = menu.generation();
        this.player = player;
        this.previous = previous;
        trimHistory();
    }

    static @Nullable View rendering() {
        return RENDERING.get();
    }

    /** The view the player was last shown, if it is still open. Safe from any thread. */
    static @Nullable View shown(Player player) {
        return SHOWN.get(player.getUniqueId());
    }

    /** Every open view. Safe from any thread. */
    static Collection<View> allShown() {
        return SHOWN.values();
    }

    /** Forgets every open view, when Loom is uninstalled. */
    static void forgetAll() {
        SHOWN.clear();
    }

    /** The Loom view the player is looking at, if any. */
    static @Nullable View of(Player player) {
        Inventory top = player.getOpenInventory().getTopInventory();
        InventoryHolder holder = top == null ? null : top.getHolder();
        return holder instanceof LoomHolder loom && loom.isCurrent() ? loom.view() : null;
    }

    /** True if the player has no container open, only their own inventory. */
    static boolean isIdle(Player player) {
        // the view's own type reads CREATIVE for creative players; the top inventory does not
        Inventory top = player.getOpenInventory().getTopInventory();
        return top == null || top.getType() == InventoryType.CRAFTING;
    }

    Player player() {
        return player;
    }

    @Nullable View previous() {
        return previous;
    }

    @Nullable Inventory inventory() {
        return inventory;
    }

    Menu menu() {
        return menu;
    }

    /** True if this view or one it can go back to shows the menu. */
    boolean leadsTo(Menu target) {
        for(View node = this; node != null; node = node.previous) {
            if(node.menu == target) {
                return true;
            }
        }
        return false;
    }

    long age() {
        return openedTick < 0 ? 0 : Loom.currentTick() - openedTick;
    }

    /** Keeps at most {@link Loom#historyLimit()} menus to go back to. */
    private void trimHistory() {
        View node = this;
        int kept = 0;
        while(node.previous != null) {
            if(kept == Loom.historyLimit()) {
                // forgotten menus can never be shown again: give back what they still hold
                for(View dropped = node.previous; dropped != null; dropped = dropped.previous) {
                    dropped.releaseParked();
                }
                node.previous = null;
                return;
            }
            kept++;
            node = node.previous;
        }
    }

    // ---------------------------------------------------------------- state

    @SuppressWarnings("unchecked")
    <T extends @Nullable Object> Signal<T> state(int index, T initial) {
        if(index < states.size()) {
            Signal<T> signal = (Signal<T>) states.get(index);
            Object current = signal.peek();
            if(current != null && initial != null && current.getClass() != initial.getClass()) {
                warnStateOrder("state #" + index + " holds a " + current.getClass().getSimpleName()
                        + " but this call starts with a " + initial.getClass().getSimpleName());
            }
            return signal;
        }
        Signal<T> signal = Signal.of("state#" + index, initial);
        states.add(signal);
        return signal;
    }

    @SuppressWarnings("unchecked")
    <T extends @Nullable Object> Signal<T> state(String key, T initial) {
        return (Signal<T>) keyedStates.computeIfAbsent(key, k -> Signal.of("state:" + key, initial));
    }

    Search.Cache searchCache(String id) {
        return (Search.Cache) keyedStates.computeIfAbsent("loom:search-cache:" + id, k -> new Search.Cache());
    }

    @SuppressWarnings("unchecked")
    <T extends @Nullable Object> Async<T> async(String key, Supplier<Async<T>> create) {
        return (Async<T>) keyedStates.computeIfAbsent("loom:async:" + key, k -> create.get());
    }

    void beginBusy() {
        busyCount++;
        busy.set(true);
    }

    void endBusy() {
        if(busyCount > 0 && --busyCount == 0) {
            busy.set(false);
        }
    }

    /** Runs the task and redraws once afterwards if it changed anything, instead of a tick later. */
    void batch(Runnable task) {
        if(batching || closed) {
            task.run();
            return;
        }
        batching = true;
        try {
            task.run();
        } finally {
            batching = false;
        }
        if(dirty) {
            dirty = false;
            redraw();
        }
    }

    boolean isBusy() {
        return busyCount > 0;
    }

    Signal<Boolean> busySignal() {
        return busy;
    }

    /** Sends every pager and scroller back to the start, e.g. for a new search query. */
    @SuppressWarnings("unchecked")
    void resetPositions() {
        for(Map.Entry<String, Object> entry : keyedStates.entrySet()) {
            if(entry.getKey().startsWith(Ui.POSITION_PREFIX) && entry.getValue() instanceof Signal<?> signal) {
                ((Signal<Integer>) signal).set(0);
            }
        }
    }

    void watch(Signal<?> signal) {
        watching.add(signal);
    }

    /** Called after each render with the number of {@code ui.state(initial)} calls. */
    void stateCalls(int calls) {
        if(stateCalls >= 0 && calls != stateCalls) {
            warnStateOrder("ui.state(...) was called " + calls + " times, " + stateCalls + " times on the previous render");
        }
        stateCalls = calls;
    }

    private void warnStateOrder(String problem) {
        if(warnedStateOrder) {
            return;
        }
        warnedStateOrder = true;
        Loom.plugin().getLogger().warning("Loom menu state mix-up for " + player.getName() + ": " + problem
                + ". ui.state(initial) is matched by call order; call it unconditionally, or use ui.state(key, initial).");
    }

    // ---------------------------------------------------------------- input slots

    static final class InputSlot {
        final Signal<@Nullable ItemStack> value;
        /** What Loom last put into the inventory slot; anything else there was put by the player. */
        @Nullable ItemStack written;

        InputSlot(int slot) {
            value = Signal.of("input:" + slot, null);
        }
    }

    Signal<@Nullable ItemStack> input(int slot) {
        return inputs.computeIfAbsent(slot, InputSlot::new).value;
    }

    boolean isInput(int slot) {
        return activeInputs.containsKey(slot);
    }

    boolean accepts(int slot, @Nullable ItemStack item) {
        if(isBusy()) {
            return false; // locked while a click task runs
        }
        Predicate<ItemStack> accepts = activeInputs.get(slot);
        return accepts != null && (empty(item) || accepts.test(item));
    }

    Set<Integer> activeInputSlots() {
        return activeInputs.keySet();
    }

    /** Reconciles input slots after a player interaction, on the next tick. */
    void scheduleInputSync() {
        if(inputSyncScheduled.compareAndSet(false, true)) {
            Loom.later(player, () -> {
                inputSyncScheduled.set(false);
                if(closed) {
                    return;
                }
                batching = true; // redraw right away instead of one more tick later
                try {
                    syncInputs();
                } finally {
                    batching = false;
                }
                if(dirty) {
                    dirty = false;
                    redraw();
                }
            }, () -> inputSyncScheduled.set(false));
        }
    }

    /**
     * Two-way sync between input slots and their signals. If the inventory differs from what
     * Loom wrote, the player changed it and the signal follows; otherwise, if the signal
     * changed, the developer did and the inventory follows. The player always wins, so an item
     * placed between two ticks is never overwritten.
     */
    private void syncInputs() {
        Inventory current = inventory;
        if(current == null) {
            return;
        }
        for(Map.Entry<Integer, InputSlot> entry : inputs.entrySet()) {
            int slot = entry.getKey();
            InputSlot input = entry.getValue();
            if(slot >= current.getSize() || !activeInputs.containsKey(slot)) {
                continue;
            }
            ItemStack actual = normalize(current.getItem(slot));
            if(!Objects.equals(actual, input.written)) {
                input.written = copy(actual);
                input.value.set(copy(actual));
            } else {
                ItemStack wanted = normalize(input.value.peek());
                if(!Objects.equals(wanted, input.written)) {
                    current.setItem(slot, copy(wanted));
                    input.written = copy(wanted);
                }
            }
        }
    }

    /**
     * Items in input slots stay with a view that was navigated away from, so Confirm, Prompt or
     * any menu opened from it can come back to them. They are handed back once the player
     * leaves Loom altogether (see {@link Loom#releaseParkedIfAway}) or when the view is
     * forgotten by the history limit.
     */
    private boolean parked;

    private void park() {
        syncInputs();
        if(inventory != null) {
            for(int slot : inputs.keySet()) {
                if(slot < inventory.getSize()) {
                    inventory.setItem(slot, null); // the items now live only in the signals
                }
            }
        }
        inputs.values().forEach(input -> input.written = null);
        boolean holdsItems = inputs.values().stream().anyMatch(input -> normalize(input.value.peek()) != null);
        if(holdsItems) {
            parked = true;
            Loom.park(player, this);
        }
    }

    /** Gives back the items of a parked view. */
    void releaseParked() {
        if(!parked) {
            return;
        }
        parked = false;
        Loom.unpark(player, this);
        List<ItemStack> items = new ArrayList<>();
        for(InputSlot input : inputs.values()) {
            ItemStack item = normalize(input.value.peek());
            if(item != null) {
                items.add(item);
            }
            input.value.set(null);
        }
        give(items);
    }

    /** Hands items left in input slots back to the player. Called whenever the view goes away. */
    private void returnInputs() {
        syncInputs();
        List<ItemStack> items = new ArrayList<>();
        for(Map.Entry<Integer, InputSlot> entry : inputs.entrySet()) {
            ItemStack item = normalize(entry.getValue().value.peek());
            if(item != null) {
                items.add(item);
            }
            if(inventory != null && entry.getKey() < inventory.getSize()) {
                inventory.setItem(entry.getKey(), null);
            }
            entry.getValue().written = null;
        }
        inputs.values().forEach(input -> input.value.set(null));
        give(items);
    }

    /** Moves a shift-clicked stack from the player's inventory into accepting input slots. */
    void shiftIntoInputs(Inventory source, int sourceSlot, ItemStack clicked) {
        Loom.later(player, () -> {
            Inventory current = inventory;
            ItemStack item = source.getItem(sourceSlot);
            if(closed || current == null || item == null || !item.equals(clicked)) {
                return;
            }
            syncInputs();
            int left = item.getAmount();
            for(int slot : activeInputs.keySet()) {
                if(left == 0) {
                    break;
                }
                if(slot >= current.getSize() || !accepts(slot, item)) {
                    continue;
                }
                ItemStack there = normalize(current.getItem(slot));
                int max = item.getMaxStackSize();
                if(there == null) {
                    int moved = Math.min(left, max);
                    current.setItem(slot, item.asQuantity(moved));
                    left -= moved;
                } else if(there.isSimilar(item) && there.getAmount() < max) {
                    int moved = Math.min(left, max - there.getAmount());
                    there.setAmount(there.getAmount() + moved);
                    current.setItem(slot, there);
                    left -= moved;
                }
            }
            source.setItem(sourceSlot, left == 0 ? null : item.asQuantity(left));
            syncInputs();
        });
    }

    private void give(List<ItemStack> items) {
        if(items.isEmpty()) {
            return;
        }
        Map<Integer, ItemStack> leftover = player.getInventory().addItem(items.toArray(ItemStack[]::new));
        for(ItemStack item : leftover.values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), item);
        }
    }

    private static boolean empty(@Nullable ItemStack item) {
        return item == null || item.isEmpty();
    }

    private static @Nullable ItemStack normalize(@Nullable ItemStack item) {
        return empty(item) ? null : item;
    }

    private static @Nullable ItemStack copy(@Nullable ItemStack item) {
        return item == null ? null : item.clone();
    }

    // ---------------------------------------------------------------- render loop

    /**
     * Opens (or reopens) this view, rendering it from its current state.
     *
     * @return whether the menu is now shown to the player
     */
    boolean show() {
        if(!player.isOnline()) {
            return false;
        }
        if(generation != menu.generation()) {
            releaseParked(); // closed with Loom.closeAll: it must not come back, e.g. after a Confirm
            return false;
        }
        if(parked) {
            parked = false; // the reopened inventory gets the items back
            Loom.unpark(player, this);
        }
        closed = false;
        inventory = null;
        if(openedTick < 0) {
            openedTick = Loom.currentTick();
        }
        cause("open");
        redraw();
        return of(player) == this;
    }

    /** Marks the view as outdated. Safe from any thread; redraws are merged. */
    void invalidate() {
        invalidate("refresh");
    }

    /**
     * Marks the view as outdated because of the cause (a {@link Signal} or a description, for
     * debug logs). Safe from any thread; redraws are merged.
     */
    void invalidate(Object cause) {
        if(closed) {
            return;
        }
        cause(cause);
        if(Loom.owns(player)) {
            if(RENDERING.get() == this) {
                throw new IllegalStateException("a signal watched by this menu was changed while rendering it");
            }
            if(batching) {
                dirty = true;
                return;
            }
        }
        if(redrawScheduled.compareAndSet(false, true)) {
            Loom.later(player, () -> {
                redrawScheduled.set(false);
                redraw();
            }, () -> redrawScheduled.set(false));
        }
    }

    /** Remembers why the next redraw happens, for debug logs. Safe from any thread. */
    private void cause(Object cause) {
        if(!menu.isDebug()) {
            return;
        }
        String text = cause instanceof Signal<?> signal
                ? "signal " + (signal.name() != null ? signal.name() : "#" + Integer.toHexString(System.identityHashCode(signal)))
                : String.valueOf(cause);
        synchronized(causes) {
            causes.add(text);
        }
    }

    /** Logs in debug mode. */
    void debug(String message) {
        if(menu.isDebug()) {
            Loom.debugLog(menu.displayName() + " for " + player.getName() + ": " + message);
        }
    }

    private void redraw() {
        if(closed) {
            return;
        }
        Ui.Frame frame;
        long started = System.nanoTime();
        try {
            frame = render();
        } catch(RuntimeException e) {
            Loom.log("Loom menu failed to render for " + player.getName(), e);
            boolean visible = of(player) == this;
            returnInputs();
            detach();
            if(visible) {
                player.closeInventory();
            }
            Loom.later(player, () -> Loom.releaseParkedIfAway(player));
            return;
        }
        double millis = (System.nanoTime() - started) / 1_000_000.0;
        int changed = apply(frame);
        afterRender(millis, changed);
    }

    /** Debug log, slow render and render loop warnings. */
    private void afterRender(double millis, int changed) {
        String why;
        synchronized(causes) {
            why = causes.isEmpty() ? "?" : String.join(", ", causes);
            causes.clear();
        }
        if(menu.isDebug()) {
            String result = changed < 0 ? "inventory opened" : changed + " slot" + (changed == 1 ? "" : "s") + " updated";
            debug(String.format(Locale.ROOT, "rendered in %.2f ms after %s; %s", millis, why, result));
        }
        double threshold = Loom.slowRenderThreshold();
        if(menu.reportSlowRender(millis, threshold)) {
            Loom.warn(String.format(Locale.ROOT, "Loom menu %s took %.1f ms to render for %s (threshold %.1f ms). "
                    + "Keep the render function fast: load slow data with ui.load and do work in click handlers.",
                    menu.displayName(), millis, player.getName(), threshold));
        }
        long now = Loom.currentTick();
        if(now - renderWindowStart >= 20) {
            renderWindowStart = now;
            rendersInWindow = 0;
        }
        if(++rendersInWindow > RENDER_LOOP_LIMIT && !warnedLoop) {
            warnedLoop = true;
            Loom.warn("Loom menu " + menu.displayName() + " was rendered more than " + RENDER_LOOP_LIMIT
                    + " times within a second for " + player.getName()
                    + ". A watched signal is probably changing all the time"
                    + (menu.isDebug() ? " (last cause: " + why + ")." : "; turn on debug to see which."));
        }
    }

    /**
     * Redraws the view {@code warmup + renders} times in a row and times the last {@code renders}
     * (render function plus comparing the result with the inventory). Debug logs and warnings
     * are skipped.
     *
     * @return the time of each measured redraw, in nanoseconds
     */
    long[] measure(int warmup, int renders) {
        long[] times = new long[renders];
        for(int i = 0; i < warmup + renders; i++) {
            if(closed) {
                throw new IllegalStateException("the menu closed while it was being measured");
            }
            long started = System.nanoTime();
            apply(render());
            long elapsed = System.nanoTime() - started;
            if(i >= warmup) {
                times[i - warmup] = elapsed;
            }
        }
        synchronized(causes) {
            causes.clear();
        }
        return times;
    }

    private Ui.Frame render() {
        for(Signal<?> signal : watching) {
            signal.unwatch(this);
        }
        watching.clear();

        Ui ui = new Ui(this);
        View outer = RENDERING.get();
        RENDERING.set(this);
        try {
            menu.renderer().accept(ui);
        } finally {
            if(outer == null) {
                RENDERING.remove();
            } else {
                RENDERING.set(outer);
            }
        }
        Ui.Frame frame = ui.finish();
        stateCalls(frame.stateCalls());
        return frame;
    }

    /** @return the number of slots changed, or -1 if the inventory was (re)opened */
    private int apply(Ui.Frame frame) {
        // pull what the player did to input slots before anything is redrawn
        syncInputs();

        @Nullable Button[] next = frame.buttons();
        onClose = frame.onClose();
        onInventoryClick = frame.onInventoryClick();
        dropInactiveInputs(frame.inputs());
        activeInputs = frame.inputs();

        boolean reopen = inventory == null || frame.rows() != rows;
        if(!reopen && !frame.title().equals(title)) {
            reopen = !retitle(frame.title());
        }

        if(reopen) {
            Inventory old = inventory;
            rows = frame.rows();
            title = frame.title();
            buttons = next;
            LoomHolder holder = new LoomHolder(this);
            Inventory created = Bukkit.createInventory(holder, rows * 9, title);
            holder.inventory(created);
            for(int slot = 0; slot < next.length; slot++) {
                created.setItem(slot, icon(next[slot]));
            }
            for(int slot : activeInputs.keySet()) {
                InputSlot input = inputs.get(slot);
                ItemStack item = input == null ? null : normalize(input.value.peek());
                created.setItem(slot, copy(item));
                if(input != null) {
                    input.written = copy(item);
                }
                if(old != null && slot < old.getSize()) {
                    old.setItem(slot, null); // the items now live in the new inventory
                }
            }
            inventory = created;
            player.openInventory(created);
            if(player.getOpenInventory().getTopInventory() != created) {
                returnInputs(); // another plugin cancelled the open
                detach();
                debug("the inventory open was cancelled by another plugin");
                return -1;
            }
            SHOWN.put(player.getUniqueId(), this);
            schedule(frame.refresh());
            return -1;
        } else {
            Inventory current = Objects.requireNonNull(inventory);
            int changed = 0;
            for(int slot = 0; slot < next.length; slot++) {
                if(activeInputs.containsKey(slot)) {
                    continue;
                }
                ItemStack icon = icon(next[slot]);
                if(!Objects.equals(icon, icon(buttons[slot]))) {
                    current.setItem(slot, icon);
                    changed++;
                }
            }
            buttons = next;
            syncInputs(); // push values the developer set
            schedule(frame.refresh());
            return changed;
        }
    }

    /** Input slots that this render no longer declares give their items back. */
    private void dropInactiveInputs(Map<Integer, Predicate<ItemStack>> stillActive) {
        List<ItemStack> items = new ArrayList<>();
        inputs.entrySet().removeIf(entry -> {
            if(stillActive.containsKey(entry.getKey())) {
                return false;
            }
            ItemStack item = normalize(entry.getValue().value.peek());
            if(item != null) {
                items.add(item);
            }
            if(inventory != null && entry.getKey() < inventory.getSize() && activeInputs.containsKey(entry.getKey())) {
                inventory.setItem(entry.getKey(), null);
            }
            return true;
        });
        give(items);
    }

    @SuppressWarnings("deprecation") // Paper has no Component setter for the open view title
    private boolean retitle(Component title) {
        try {
            player.getOpenInventory().setTitle(LegacyComponentSerializer.legacySection().serialize(title));
            this.title = title;
            return true;
        } catch(UnsupportedOperationException | IllegalArgumentException e) {
            return false;
        }
    }

    private void schedule(int period) {
        if(period == refreshPeriod) {
            return;
        }
        cancelRefresh();
        refreshPeriod = period;
        if(period > 0) {
            refreshTask = Loom.scheduler().timer(player, () -> {
                cause("every " + period + " ticks");
                redraw();
            }, period);
        }
    }

    private void cancelRefresh() {
        if(refreshTask != null) {
            refreshTask.cancel();
            refreshTask = null;
        }
        refreshPeriod = 0;
    }

    private static @Nullable ItemStack icon(@Nullable Button button) {
        return button == null ? null : button.icon();
    }

    // ---------------------------------------------------------------- events

    void handleClick(InventoryClickEvent event, int slot) {
        if(slot >= buttons.length) {
            return;
        }
        Button button = buttons[slot];
        if(button != null && button.handler() != null) {
            dispatch(button.handler(), event, slot, button);
        }
    }

    void handleInventoryClick(InventoryClickEvent event) {
        if(onInventoryClick != null) {
            dispatch(onInventoryClick, event, event.getSlot(), null);
        }
    }

    private void dispatch(ClickHandler handler, InventoryClickEvent event, int slot, @Nullable Button button) {
        if(closed) {
            return;
        }
        if(event.getClick() == ClickType.DOUBLE_CLICK) {
            debug("ignored a double click on slot " + slot);
            return;
        }
        if(isBusy()) {
            debug("ignored a click on slot " + slot + ": busy with a click task");
            return;
        }
        long now = Loom.currentTick();
        if(now - lastClickTick < menu.cooldown()) {
            debug("ignored a click on slot " + slot + ": cooldown, " + (menu.cooldown() - (now - lastClickTick)) + " ticks left");
            return;
        }
        lastClickTick = now;

        batching = true;
        Loom.beginDispatch();
        try {
            // the handler must see what is really in the input slots, e.g. not pay for an item
            // the player took back out a moment ago
            syncInputs();
            Click click = new Click(this, event, slot, button);
            handler.onClick(click);
            click.finish();
        } catch(RuntimeException e) {
            Loom.log("Loom click handler failed for " + player.getName() + " at slot " + slot, e);
        } finally {
            Loom.endDispatch();
            batching = false;
        }
        if(dirty) {
            dirty = false;
            redraw();
        }
    }

    void handleClose(InventoryCloseEvent event) {
        CloseReason reason;
        if(Loom.shuttingDown) {
            reason = CloseReason.SHUTDOWN;
        } else if(navigating) {
            reason = CloseReason.NAVIGATE;
        } else if(Loom.isLeaving(player)) {
            // a kick closes the menu with reason UNKNOWN before the player is gone
            reason = CloseReason.DISCONNECT;
        } else {
            reason = switch(event.getReason()) {
                case PLAYER -> CloseReason.PLAYER;
                case DISCONNECT -> CloseReason.DISCONNECT;
                case OPEN_NEW -> CloseReason.NAVIGATE;
                default -> CloseReason.PLUGIN;
            };
        }
        Consumer<Close> callback = onClose;
        if(reason == CloseReason.NAVIGATE && !discarding) {
            park(); // input items wait in case the player comes back
        } else {
            returnInputs();
        }
        detach();
        if(callback != null) {
            Loom.beginDispatch();
            try {
                callback.accept(new Close(player, menu, reason, event));
            } catch(RuntimeException e) {
                Loom.log("Loom close handler failed for " + player.getName(), e);
            } finally {
                Loom.endDispatch();
            }
        }
        if(reason == CloseReason.DISCONNECT || reason == CloseReason.SHUTDOWN) {
            Loom.releaseParked(player); // now, while the player and the plugin are still there
        } else {
            // after anything the callback scheduled, e.g. Confirm returning to a parked menu
            Loom.later(player, () -> Loom.releaseParkedIfAway(player));
        }
    }

    boolean navigateTo(Menu next) {
        if(of(player) != this) {
            return false;
        }
        navigating = true;
        try {
            return new View(next, player, this).show();
        } finally {
            navigating = false;
        }
    }

    /** Runs something that replaces this view, so it closes with {@link CloseReason#NAVIGATE}. */
    void replaceWith(Runnable open) {
        navigating = true;
        try {
            open.run();
        } finally {
            navigating = false;
        }
    }

    void back() {
        if(of(player) != this) {
            return;
        }
        if(previous == null) {
            player.closeInventory();
            return;
        }
        View target = previous;
        discarding = true; // nothing will come back to this view: return its items, do not park them
        try {
            replaceWith(target::show);
        } finally {
            discarding = false;
        }
    }

    /** Stops everything this view does. State is kept, so {@link #show()} can bring it back. */
    private void detach() {
        closed = true;
        SHOWN.remove(player.getUniqueId(), this);
        inventory = null;
        dirty = false;
        cancelRefresh();
        for(Signal<?> signal : watching) {
            signal.unwatch(this);
        }
        watching.clear();
    }
}
