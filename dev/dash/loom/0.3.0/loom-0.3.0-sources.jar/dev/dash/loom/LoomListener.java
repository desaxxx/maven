package dev.dash.loom;

import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.server.PluginDisableEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.plugin.Plugin;
import org.jspecify.annotations.Nullable;

import java.util.EnumSet;
import java.util.Set;

/**
 * Protects Loom inventories and routes events to their views.
 *
 * <p>Security model, all allow-lists:</p>
 * <ul>
 *     <li>Menu slots are read-only, except input slots ({@link Ui#input}), which allow
 *     {@link #INPUT_TAKE_ACTIONS} and, for items the slot accepts, {@link #INPUT_PUT_ACTIONS}.</li>
 *     <li>In the player's own inventory only {@link #SAFE_BOTTOM_ACTIONS} are allowed. Shift-click
 *     into the menu is always cancelled; Loom moves the stack into accepting inputs itself.</li>
 *     <li>Anything else (collect-to-cursor, clone, unknown future actions) is cancelled.</li>
 * </ul>
 *
 * <p>The decision is applied at {@code LOWEST} and enforced again at {@code HIGHEST}, so other
 * plugins cannot un-cancel it.</p>
 */
final class LoomListener implements Listener {

    /** Taking an item out of an input slot. */
    private static final Set<InventoryAction> INPUT_TAKE_ACTIONS = EnumSet.of(
            InventoryAction.PICKUP_ALL,
            InventoryAction.PICKUP_SOME,
            InventoryAction.PICKUP_HALF,
            InventoryAction.PICKUP_ONE,
            InventoryAction.DROP_ALL_SLOT,
            InventoryAction.DROP_ONE_SLOT,
            InventoryAction.MOVE_TO_OTHER_INVENTORY
    );

    /** Putting the cursor item into an input slot; only for items the slot accepts. */
    private static final Set<InventoryAction> INPUT_PUT_ACTIONS = EnumSet.of(
            InventoryAction.PLACE_ALL,
            InventoryAction.PLACE_SOME,
            InventoryAction.PLACE_ONE,
            InventoryAction.SWAP_WITH_CURSOR
    );

    /** Actions that only move items inside the player's inventory or drop them. */
    private static final Set<InventoryAction> SAFE_BOTTOM_ACTIONS = EnumSet.of(
            InventoryAction.NOTHING,
            InventoryAction.PICKUP_ALL,
            InventoryAction.PICKUP_SOME,
            InventoryAction.PICKUP_HALF,
            InventoryAction.PICKUP_ONE,
            InventoryAction.PLACE_ALL,
            InventoryAction.PLACE_SOME,
            InventoryAction.PLACE_ONE,
            InventoryAction.SWAP_WITH_CURSOR,
            InventoryAction.DROP_ALL_CURSOR,
            InventoryAction.DROP_ONE_CURSOR,
            InventoryAction.DROP_ALL_SLOT,
            InventoryAction.DROP_ONE_SLOT,
            InventoryAction.HOTBAR_SWAP,
            InventoryAction.CLONE_STACK,
            // bundles: only between the cursor, a bundle and a slot of the player's own inventory
            InventoryAction.PICKUP_FROM_BUNDLE,
            InventoryAction.PICKUP_ALL_INTO_BUNDLE,
            InventoryAction.PICKUP_SOME_INTO_BUNDLE,
            InventoryAction.PLACE_FROM_BUNDLE,
            InventoryAction.PLACE_ALL_INTO_BUNDLE,
            InventoryAction.PLACE_SOME_INTO_BUNDLE
    );

    private final Plugin plugin;

    LoomListener(Plugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    void onClick(InventoryClickEvent event) {
        LoomHolder holder = holder(event.getView());
        if(holder == null) {
            return;
        }
        boolean cancel = mustCancel(holder, event);
        if(cancel) {
            event.setCancelled(true);
        }
        if(!holder.isCurrent()) {
            return;
        }
        View view = holder.view();
        int slot = event.getRawSlot();
        int topSize = event.getView().getTopInventory().getSize();
        if(cancel && (slot >= topSize || view.isInput(slot))) {
            // plain menu slots are always cancelled; only report what a player could expect to work
            view.debug("blocked " + event.getAction() + " (" + event.getClick() + ") on "
                    + (slot >= topSize ? "player inventory slot " + event.getSlot() : "input slot " + slot)
                    + (view.menu().lockPlayerInventory() && slot >= topSize ? ": player inventory is locked"
                    : view.isBusy() && slot < topSize ? ": busy with a click task" : ": not allowed by the safety rules"));
        }
        if(slot >= 0 && slot < topSize) {
            if(view.isInput(slot)) {
                if(!cancel) {
                    view.scheduleInputSync();
                }
                return;
            }
            view.handleClick(event, slot);
        } else if(slot >= topSize) {
            if(event.getAction() == InventoryAction.MOVE_TO_OTHER_INVENTORY
                    && !view.menu().lockPlayerInventory()
                    && !view.isBusy()
                    && !view.activeInputSlots().isEmpty()
                    && event.getClickedInventory() != null) {
                ItemStack clicked = event.getCurrentItem();
                if(clicked != null && !clicked.isEmpty()) {
                    view.shiftIntoInputs(event.getClickedInventory(), event.getSlot(), clicked.clone());
                }
            }
            view.handleInventoryClick(event);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    void enforceClick(InventoryClickEvent event) {
        LoomHolder holder = holder(event.getView());
        if(holder != null && mustCancel(holder, event)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    void onDrag(InventoryDragEvent event) {
        LoomHolder holder = holder(event.getView());
        if(holder == null) {
            return;
        }
        if(dragAllowed(holder, event)) {
            int topSize = event.getView().getTopInventory().getSize();
            if(event.getRawSlots().stream().anyMatch(slot -> slot < topSize)) {
                holder.view().scheduleInputSync();
            }
        } else {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    void enforceDrag(InventoryDragEvent event) {
        LoomHolder holder = holder(event.getView());
        if(holder != null && !dragAllowed(holder, event)) {
            event.setCancelled(true);
        }
    }

    /** A drag may only cover accepting input slots and, unless locked, the player's inventory. */
    private static boolean dragAllowed(LoomHolder holder, InventoryDragEvent event) {
        int topSize = event.getView().getTopInventory().getSize();
        boolean current = holder.isCurrent();
        for(int slot : event.getRawSlots()) {
            if(slot < topSize) {
                if(!current || !holder.view().accepts(slot, event.getOldCursor()) || !holder.view().isInput(slot)) {
                    return false;
                }
            } else if(holder.view().menu().lockPlayerInventory()) {
                return false;
            }
        }
        return true;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    void onClose(InventoryCloseEvent event) {
        LoomHolder holder = holder(event.getView());
        if(holder != null && holder.isCurrent()) {
            holder.view().handleClose(event);
        }
    }

    // Kicks close the menu with reason UNKNOWN, so the leave is remembered beforehand to report
    // it as DISCONNECT and to skip returning to a menu for a player who is gone.

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    void onKick(PlayerKickEvent event) {
        Loom.leaving(event.getPlayer().getUniqueId(), true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    void onQuit(PlayerQuitEvent event) {
        Loom.leaving(event.getPlayer().getUniqueId(), true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    void onJoin(PlayerJoinEvent event) {
        Loom.leaving(event.getPlayer().getUniqueId(), false);
    }

    @EventHandler
    void onDisable(PluginDisableEvent event) {
        if(event.getPlugin() == plugin) {
            Loom.uninstall();
        }
    }

    private static boolean mustCancel(LoomHolder holder, InventoryClickEvent event) {
        int slot = event.getRawSlot();
        if(slot >= 0 && slot < event.getView().getTopInventory().getSize()) {
            return !holder.isCurrent() || !holder.view().isInput(slot) || !inputAllows(holder.view(), slot, event);
        }
        return holder.view().menu().lockPlayerInventory() || !SAFE_BOTTOM_ACTIONS.contains(event.getAction());
    }

    private static boolean inputAllows(View view, int slot, InventoryClickEvent event) {
        if(view.isBusy()) {
            return false; // a click task may be about to use what is in there
        }
        InventoryAction action = event.getAction();
        if(INPUT_TAKE_ACTIONS.contains(action)) {
            return true;
        }
        if(INPUT_PUT_ACTIONS.contains(action)) {
            return view.accepts(slot, event.getCursor());
        }
        if(action == InventoryAction.HOTBAR_SWAP) {
            return view.accepts(slot, hotbarItem(event));
        }
        return false;
    }

    /** The item a number key or offhand swap would move into the clicked slot. */
    private static @Nullable ItemStack hotbarItem(InventoryClickEvent event) {
        int button = event.getHotbarButton();
        PlayerInventory inventory = event.getWhoClicked().getInventory();
        return button >= 0 ? inventory.getItem(button) : inventory.getItemInOffHand();
    }

    private static @Nullable LoomHolder holder(InventoryView view) {
        Inventory top = view.getTopInventory();
        return top != null && top.getHolder() instanceof LoomHolder holder ? holder : null;
    }
}
