package dev.dash.loom;

import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;

/**
 * Routes anvil events to {@link Prompt} sessions. Nothing in a prompt can be moved: every click
 * and drag is cancelled, and clicking the result slot submits the text.
 */
final class PromptListener implements Listener {

    static final int RESULT_SLOT = 2;

    @EventHandler(priority = EventPriority.LOWEST)
    void onClick(InventoryClickEvent event) {
        Prompt.Session session = Prompt.session(event.getView());
        if(session == null) {
            return;
        }
        event.setCancelled(true);
        if(event.getRawSlot() == RESULT_SLOT) {
            session.submit();
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    void enforceClick(InventoryClickEvent event) {
        if(Prompt.session(event.getView()) != null) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    void onDrag(InventoryDragEvent event) {
        if(Prompt.session(event.getView()) != null) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    void onType(PrepareAnvilEvent event) {
        Prompt.Session session = Prompt.session(event.getView());
        if(session != null) {
            session.typed(event.getView(), event::setResult);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    void onClose(InventoryCloseEvent event) {
        Prompt.Session session = Prompt.session(event.getView());
        if(session != null) {
            session.closed(event);
        }
    }
}
