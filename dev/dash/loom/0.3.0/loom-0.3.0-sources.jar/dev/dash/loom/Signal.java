package dev.dash.loom;

import org.jspecify.annotations.Nullable;

import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.function.UnaryOperator;

/**
 * A value that menus can watch. Any menu that calls {@link #get()} while rendering is redrawn
 * when the value changes; there is nothing to register or unregister.
 *
 * <p>Signals may be changed from any thread. Each watching menu is redrawn on its player's
 * thread (the main thread on Paper, the player's region thread on Folia), and several changes in
 * the same tick (or the same click) result in a single redraw.</p>
 *
 * <p>Changes are atomic ({@link #update}, {@link #getAndUpdate}); a mutable value inside the
 * signal is not protected. On Folia, a signal shared by players in different regions is read
 * and changed from several threads at once, so prefer immutable values with {@link #update}
 * over {@link #mutate}, and check-and-change with {@link #getAndUpdate}.</p>
 *
 * <ul>
 *     <li>{@link Ui#state(Object)}: private to one viewer, lives as long as the view.</li>
 *     <li>{@link Loom#signal(Object)}: shared by everyone, e.g. a global stock counter.</li>
 * </ul>
 */
public final class Signal<T extends @Nullable Object> {

    private volatile T value;
    /** Makes changes atomic; a private object, so callers locking on the signal cannot interfere. */
    private final Object lock = new Object();
    private final @Nullable String name;
    private final Set<View> watchers = ConcurrentHashMap.newKeySet();

    private Signal(@Nullable String name, T value) {
        this.name = name;
        this.value = value;
    }

    public static <T extends @Nullable Object> Signal<T> of(T initial) {
        return new Signal<>(null, initial);
    }

    /** A signal with a name, shown in {@link Loom#debug(boolean) debug} logs. */
    public static <T extends @Nullable Object> Signal<T> of(String name, T initial) {
        return new Signal<>(Objects.requireNonNull(name, "name"), initial);
    }

    /** Returns the value. Inside a render, the menu starts watching this signal. */
    public T get() {
        View rendering = View.rendering(); // only set on the thread running a render
        if(rendering != null) {
            watchers.add(rendering);
            rendering.watch(this);
        }
        return value;
    }

    /** Returns the value without watching it. */
    public T peek() {
        return value;
    }

    /** Sets the value; watchers are redrawn only if it is not {@link Objects#equals equal}. */
    public void set(T value) {
        synchronized(lock) {
            if(Objects.equals(this.value, value)) {
                return;
            }
            this.value = value;
        }
        changed();
    }

    /**
     * Replaces the value with the function's result, atomically: no change from another thread
     * can slip in between reading and writing. The function may run while other threads wait,
     * so keep it short.
     */
    public void update(UnaryOperator<T> function) {
        getAndUpdate(function);
    }

    /**
     * Like {@link #update}, and returns the value from before. Use it to check and change in one
     * step, e.g. take one from a shared stock only if there is one left:
     *
     * <pre>{@code
     * if(STOCK.getAndUpdate(n -> n > 0 ? n - 1 : 0) == 0) {
     *     c.deny("<red>Out of stock");
     * }
     * }</pre>
     *
     * <p>A separate {@code peek()} followed by {@code update(...)} is not enough on Folia, where
     * players in different regions can click at the same moment.</p>
     */
    public T getAndUpdate(UnaryOperator<T> function) {
        T before;
        synchronized(lock) {
            before = value;
            T after = function.apply(before);
            if(Objects.equals(before, after)) {
                return before;
            }
            value = after;
        }
        changed();
        return before;
    }

    /**
     * Changes a mutable value in place (a list, a map...) and always redraws the watchers.
     * Mutations of the same signal do not overlap, but reads ({@link #get()}, {@link #peek()})
     * are not blocked: for a signal shared across threads (Folia regions, async tasks), prefer
     * immutable values with {@link #update}.
     */
    public void mutate(Consumer<T> mutation) {
        synchronized(lock) {
            mutation.accept(value);
        }
        changed();
    }

    /** Redraws every watcher without changing the value. */
    public void changed() {
        for(View view : watchers) {
            view.invalidate(this);
        }
    }

    /** Number of menus currently watching this signal. */
    public int watchers() {
        return watchers.size();
    }

    void unwatch(View view) {
        watchers.remove(view);
    }

    /** The name given at creation, or null. */
    public @Nullable String name() {
        return name;
    }

    @Override
    public String toString() {
        return name != null ? "Signal[" + name + "=" + value + "]" : "Signal[" + value + "]";
    }
}
