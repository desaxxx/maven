package dev.dash.loom;

import net.kyori.adventure.key.Key;
import net.kyori.adventure.sound.Sound;
import org.bukkit.event.inventory.ClickType;
import org.jspecify.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;

/**
 * Click sounds of a button or a menu: rules checked in the order they were added, then a
 * fallback. Immutable.
 */
final class SoundRules {

    /** Means "no sound, do not look further". Compared by identity. */
    static final Sound SILENT = Sound.sound(Key.key("loom", "silent"), Sound.Source.MASTER, 0f, 1f);

    static final SoundRules NONE = new SoundRules(List.of(), null);

    private record Rule(Predicate<Click> when, Sound sound) {
    }

    private final List<Rule> rules;
    private final @Nullable Sound fallback;

    private SoundRules(List<Rule> rules, @Nullable Sound fallback) {
        this.rules = rules;
        this.fallback = fallback;
    }

    SoundRules fallback(Sound sound) {
        return new SoundRules(rules, Objects.requireNonNull(sound, "sound"));
    }

    SoundRules when(ClickType type, Sound sound) {
        Objects.requireNonNull(type, "type");
        return when(click -> click.type() == type, sound);
    }

    SoundRules when(Predicate<Click> when, Sound sound) {
        Objects.requireNonNull(when, "when");
        Objects.requireNonNull(sound, "sound");
        List<Rule> next = new ArrayList<>(rules);
        next.add(new Rule(when, sound));
        return new SoundRules(List.copyOf(next), fallback);
    }

    /** The sound for the click, {@link #SILENT}, or null if these rules do not decide. */
    @Nullable Sound resolve(Click click) {
        for(Rule rule : rules) {
            if(rule.when().test(click)) {
                return rule.sound();
            }
        }
        return fallback;
    }
}
