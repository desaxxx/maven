package dev.dash.loom;

/**
 * Page control returned by {@link Ui#paginate}. The current page is view state, so changing it
 * redraws the menu and it survives {@link Click#back()}.
 */
public final class Pager {

    private final Signal<Integer> page;
    private final int pages;
    private final int current;

    Pager(Signal<Integer> page, int pages, int current) {
        this.page = page;
        this.pages = pages;
        this.current = current;
    }

    /** Zero-based index of the shown page. */
    public int page() {
        return current;
    }

    /** Total page count, at least 1. */
    public int pages() {
        return pages;
    }

    public boolean hasNext() {
        return current + 1 < pages;
    }

    public boolean hasPrevious() {
        return current > 0;
    }

    public void next() {
        go(current + 1);
    }

    public void previous() {
        go(current - 1);
    }

    public void first() {
        go(0);
    }

    public void last() {
        go(pages - 1);
    }

    /** Goes to the given zero-based page, clamped to the valid range. */
    public void go(int page) {
        this.page.set(Math.clamp(page, 0, pages - 1));
    }

    @Override
    public String toString() {
        return "Pager[" + (current + 1) + "/" + pages + "]";
    }
}
