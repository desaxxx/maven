package dev.dash.loom;

import dev.dash.itemstack.builder.TextFormat;
import net.kyori.adventure.sound.Sound;
import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.jspecify.annotations.Nullable;

import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.function.Supplier;

/**
 * A click on a button. Navigation methods ({@link #open}, {@link #back}, {@link #close}) are
 * applied on the next tick, as Bukkit requires. Handlers run on the player's thread: the main
 * thread on Paper, the player's region thread on Folia.
 */
public final class Click {

    private final View view;
    private final InventoryClickEvent event;
    private final int slot;
    private final @Nullable Button button;

    /** Sound picked by the handler; {@code decided} tells "silent" apart from "not picked". */
    private @Nullable Sound chosen;
    private boolean decided;
    private boolean finished;

    Click(View view, InventoryClickEvent event, int slot, @Nullable Button button) {
        this.view = view;
        this.event = event;
        this.slot = slot;
        this.button = button;
    }

    public Player player() {
        return view.player();
    }

    /**
     * The clicked slot: a menu slot, or a slot of the player's inventory when
     * {@link #inPlayerInventory()} is true.
     */
    public int slot() {
        return slot;
    }

    /** True for clicks reported by {@link Ui#onInventoryClick}. */
    public boolean inPlayerInventory() {
        return event.getRawSlot() >= event.getView().getTopInventory().getSize();
    }

    /** The item in the clicked slot, or null if it is empty. */
    public @Nullable ItemStack item() {
        ItemStack item = event.getCurrentItem();
        return item == null || item.isEmpty() ? null : item;
    }

    public ClickType type() {
        return event.getClick();
    }

    public boolean isLeft() {
        return event.isLeftClick();
    }

    public boolean isRight() {
        return event.isRightClick();
    }

    public boolean isShift() {
        return event.isShiftClick();
    }

    /** The raw event. Menu clicks are always cancelled; player inventory clicks may not be. */
    public InventoryClickEvent event() {
        return event;
    }

    /**
     * Opens another menu and remembers this one, so the new menu can go {@link #back()}.
     *
     * @return completes with whether the new menu was shown, like {@link Menu#open(Player)}
     */
    public CompletableFuture<Boolean> open(Menu menu) {
        CompletableFuture<Boolean> opened = new CompletableFuture<>();
        Loom.later(player(), () -> opened.complete(view.navigateTo(menu)), () -> opened.complete(false));
        return opened;
    }

    /**
     * Returns to the menu that opened this one, with its state intact. Closes the menu if
     * there is nowhere to go back to.
     */
    public void back() {
        Loom.later(player(), view::back);
    }

    public boolean canGoBack() {
        return view.previous() != null;
    }

    public void close() {
        Loom.later(player(), () -> {
            if(View.of(player()) == view) {
                player().closeInventory();
            }
        });
    }

    /** True while the menu of this click is still the one the player is looking at. */
    public boolean isOpen() {
        return View.of(player()) == view;
    }

    // ---------------------------------------------------------------- async work

    /**
     * Runs slow work (database, HTTP, another plugin's async API) off the server threads. Until it
     * finishes the menu is busy: buttons ignore clicks, input slots are locked and
     * {@link Ui#busy()} is true, so a purchase cannot run twice.
     *
     * <pre>{@code
     * c -> c.async(() -> economy.withdraw(id, 100))
     *       .then(ok -> { if(ok) give(c.player()); else c.deny("<red>Not enough money"); })
     *       .fail(error -> c.deny("<red>Something went wrong"));
     * }</pre>
     *
     * <p>Do not touch the Bukkit API inside {@code work}. Take what the work needs from input
     * slots <b>before</b> starting it ({@code input.set(null)}) and give it back in
     * {@code fail}: the player can close the menu while the work runs, which hands input items
     * back.</p>
     */
    public <T extends @Nullable Object> ClickTask<T> async(Supplier<T> work) {
        Objects.requireNonNull(work, "work");
        return start(() -> Loom.supplyAsync(work));
    }

    /** Like {@link #async}, for APIs that already return a future. */
    public <T extends @Nullable Object> ClickTask<T> await(Supplier<? extends CompletionStage<T>> work) {
        Objects.requireNonNull(work, "work");
        return start(work);
    }

    private <T extends @Nullable Object> ClickTask<T> start(Supplier<? extends CompletionStage<T>> work) {
        if(!Loom.owns(player())) {
            throw new IllegalStateException("Click.async must be called on the player's thread "
                    + "(the main thread on Paper, the player's region thread on Folia)");
        }
        CompletionStage<T> stage;
        try {
            stage = Objects.requireNonNull(work.get(), "work returned null");
        } catch(RuntimeException e) {
            stage = CompletableFuture.failedFuture(e);
        }
        return new ClickTask<>(view, stage);
    }

    // ---------------------------------------------------------------- feedback

    /**
     * Plays this sound for this click instead of the button's or the menu's. Inside the handler
     * the sound plays once the handler returns; later (e.g. from an async result) right away.
     */
    public void sound(Sound sound) {
        choose(Objects.requireNonNull(sound, "sound"));
    }

    /** No sound for this click. */
    public void silent() {
        choose(SoundRules.SILENT);
    }

    /**
     * Tells the player the click did not work: plays the deny sound ({@link Menu#denySound},
     * {@link Loom#denySound()}) instead of the normal one.
     */
    public void deny() {
        choose(view.menu().resolvedDenySound());
    }

    /**
     * Like {@link #deny()}, and shows the message in the action bar. Accepts MiniMessage, legacy
     * codes and placeholders.
     */
    public void deny(String message) {
        deny();
        Component text = TextFormat.parse(Loom.placeholders().parse(player(), message));
        if(text != null) {
            player().sendActionBar(text);
        }
    }

    private void choose(Sound sound) {
        if(finished) {
            play(sound);
        } else {
            chosen = sound;
            decided = true;
        }
    }

    /** Called once the handler returned: plays the picked sound or the configured one. */
    void finish() {
        finished = true;
        if(decided) {
            play(chosen);
        } else if(button != null && button.handler() != null) {
            Sound sound = button.sounds().resolve(this);
            if(sound == null) {
                sound = view.menu().sounds().resolve(this);
            }
            play(sound != null ? sound : Loom.defaultSound());
        }
    }

    private void play(@Nullable Sound sound) {
        if(sound != null && sound != SoundRules.SILENT) {
            player().playSound(sound, Sound.Emitter.self());
        }
    }

    /** Redraws the menu even if no signal changed. */
    public void refresh() {
        view.invalidate("click.refresh()");
    }
}
