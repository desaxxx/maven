package dev.dash.loom;

import net.kyori.adventure.sound.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.jspecify.annotations.Nullable;

import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.function.Predicate;

/**
 * An immutable, reusable menu definition. Every {@link #open(Player)} creates a fresh view with
 * its own state, so one {@code Menu} can safely be stored in a static field and shown to many
 * players at the same time.
 *
 * <p>The setters ({@link #cooldown}, {@link #name}...) return a new {@code Menu}; keep the one
 * they return.</p>
 */
public final class Menu {

    private final Consumer<Ui> renderer;
    private final int cooldown;
    private final boolean lockPlayerInventory;
    private final @Nullable String name;
    private final boolean debug;
    private final SoundRules sounds;
    private final @Nullable Sound denySound;
    /** Raised by {@link Loom#closeAll(Menu)}: views opened before can never be shown again. */
    private final AtomicInteger generation = new AtomicInteger();
    /** The first render warms up (class loading, JIT), so it is not measured. */
    private final AtomicBoolean warmedUp = new AtomicBoolean();
    private final AtomicBoolean warnedSlow = new AtomicBoolean();

    private Menu(Consumer<Ui> renderer, int cooldown, boolean lockPlayerInventory, @Nullable String name,
                 boolean debug, SoundRules sounds, @Nullable Sound denySound) {
        this.renderer = renderer;
        this.cooldown = cooldown;
        this.lockPlayerInventory = lockPlayerInventory;
        this.name = name;
        this.debug = debug;
        this.sounds = sounds;
        this.denySound = denySound;
    }

    /**
     * Creates a menu from a render function. The function runs again on every change, so it
     * must be fast and only describe the menu; see {@link Ui}.
     */
    public static Menu of(Consumer<Ui> renderer) {
        return new Menu(Objects.requireNonNull(renderer, "renderer"), 0, false, null, false, SoundRules.NONE, null);
    }

    /** Minimum ticks between two handled clicks of the same viewer. Default: 0. */
    public Menu cooldown(int ticks) {
        if(ticks < 0) {
            throw new IllegalArgumentException("cooldown must be >= 0");
        }
        return new Menu(renderer, ticks, lockPlayerInventory, name, debug, sounds, denySound);
    }

    /** Blocks every interaction with the player's own inventory while this menu is open. */
    public Menu lockPlayerInventory(boolean lock) {
        return new Menu(renderer, cooldown, lock, name, debug, sounds, denySound);
    }

    /** A name for log messages, e.g. {@code "shop"}. */
    public Menu name(String name) {
        return new Menu(renderer, cooldown, lockPlayerInventory, Objects.requireNonNull(name, "name"), debug, sounds, denySound);
    }

    /** Logs every render and every ignored click of this menu. See {@link Loom#debug(boolean)}. */
    public Menu debug(boolean debug) {
        return new Menu(renderer, cooldown, lockPlayerInventory, name, debug, sounds, denySound);
    }

    /**
     * Sound of every button of this menu (with a handler) when no rule below matches and the
     * button has no sound of its own. Falls back to {@link Loom#defaultSound()}.
     */
    public Menu sound(Sound sound) {
        return new Menu(renderer, cooldown, lockPlayerInventory, name, debug, sounds.fallback(sound), denySound);
    }

    /** Sound of this menu's buttons for one exact click type; see {@link Button#sound(ClickType, Sound)}. */
    public Menu sound(ClickType type, Sound sound) {
        return new Menu(renderer, cooldown, lockPlayerInventory, name, debug, sounds.when(type, sound), denySound);
    }

    /** Sound of this menu's buttons for clicks matching the condition, e.g. {@code Click::isShift}. */
    public Menu sound(Predicate<Click> when, Sound sound) {
        return new Menu(renderer, cooldown, lockPlayerInventory, name, debug, sounds.when(when, sound), denySound);
    }

    /** No button sounds in this menu, even if {@link Loom#defaultSound(Sound)} is set. */
    public Menu silent() {
        return new Menu(renderer, cooldown, lockPlayerInventory, name, debug, sounds.fallback(SoundRules.SILENT), denySound);
    }

    /** Sound of {@link Click#deny()} in this menu. Default: {@link Loom#denySound()}. */
    public Menu denySound(Sound sound) {
        return new Menu(renderer, cooldown, lockPlayerInventory, name, debug, sounds, Objects.requireNonNull(sound, "sound"));
    }

    /**
     * Opens the menu. Safe to call from any thread and from inside click or close handlers:
     * the open is moved to the player's thread on the next tick when it would not be safe right
     * now.
     *
     * @return completes on the player's thread with {@code true} once the menu is shown, or
     * {@code false} if it could not be: the player went offline, the first render failed, or
     * another plugin cancelled the {@code InventoryOpenEvent}. If the player left before the
     * open could run (Folia), it completes with {@code false} on another thread. Ignore it if
     * you do not care.
     */
    public CompletableFuture<Boolean> open(Player player) {
        Objects.requireNonNull(player, "player");
        if(Loom.shuttingDown) {
            return CompletableFuture.completedFuture(false); // nothing can be scheduled anymore
        }
        Loom.plugin(); // fail fast if Loom cannot be installed
        CompletableFuture<Boolean> opened = new CompletableFuture<>();
        Loom.sync(player, () -> opened.complete(new View(this, player, null).show()), () -> opened.complete(false));
        return opened;
    }

    @Override
    public String toString() {
        return name != null ? "Menu[" + name + "]" : "Menu";
    }

    Consumer<Ui> renderer() {
        return renderer;
    }

    int cooldown() {
        return cooldown;
    }

    boolean lockPlayerInventory() {
        return lockPlayerInventory;
    }

    /** The name for log messages. */
    String displayName() {
        return name != null ? name : "unnamed menu";
    }

    SoundRules sounds() {
        return sounds;
    }

    Sound resolvedDenySound() {
        return denySound != null ? denySound : Loom.denySound();
    }

    boolean isDebug() {
        return debug || Loom.debug();
    }

    /**
     * Whether a render that took this long should be reported: not the menu's very first render,
     * and only once per menu.
     */
    boolean reportSlowRender(double millis, double threshold) {
        boolean first = !warmedUp.getAndSet(true);
        return !first && threshold > 0 && millis > threshold && !warnedSlow.getAndSet(true);
    }

    int generation() {
        return generation.get();
    }

    void retireViews() {
        generation.incrementAndGet();
    }
}
