package dev.dash.loom;

/** Called when a viewer clicks a button. Runs on the player's thread (the main thread on Paper). */
@FunctionalInterface
public interface ClickHandler {

    void onClick(Click click);
}
