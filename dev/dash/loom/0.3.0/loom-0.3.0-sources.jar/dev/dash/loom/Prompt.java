package dev.dash.loom;

import dev.dash.itemstack.builder.TextFormat;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.MenuType;
import org.bukkit.inventory.view.AnvilView;
import org.jspecify.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

/**
 * Asks the player for a line of text with an anvil.
 *
 * <pre>{@code
 * Prompt.create().title("<gold>New name").text(current).open(player, name -> rename(player, name));
 * }</pre>
 *
 * <p>The player types into the anvil and clicks the result slot to submit. If a Loom menu was
 * open, it comes back afterwards with its state, so the callback can simply set a signal:</p>
 *
 * <pre>{@code
 * Signal<String> name = ui.state("Steve");
 * ui.put(4, Loom.item(Material.NAME_TAG, name.get()),
 *        click -> Prompt.create().text(name.get()).open(click.player(), name::set));
 * }</pre>
 *
 * <p>Prompts are immutable and reusable. They do not depend on menus: opening one with no menu
 * open works the same, there is just nothing to return to.</p>
 *
 * <p>Built on Paper's {@link MenuType} API, which Paper still marks as experimental.</p>
 */
public final class Prompt {

    /** Open prompts by player. A player's entry is only changed on that player's thread. */
    private static final Map<UUID, Session> SESSIONS = new ConcurrentHashMap<>();

    /**
     * Return target of the prompt whose callback is running on this thread. A prompt opened from
     * that callback inherits it, so chained prompts still return to the original menu.
     */
    private static final ThreadLocal<@Nullable View> handoff = new ThreadLocal<>();

    /** Creates and opens an empty anvil. Replaced in tests, where Paper's MenuType API is missing. */
    static final AnvilOpener PAPER_OPENER = (player, title) -> {
        AnvilView view = MenuType.ANVIL.builder()
                .title(title)
                .checkReachable(false)
                .build(player);
        player.openInventory(view);
        return view;
    };
    static AnvilOpener opener = PAPER_OPENER;

    @FunctionalInterface
    interface AnvilOpener {
        InventoryView open(Player player, @Nullable Component title);
    }

    private final @Nullable Component title;
    private final String text;
    private final Material icon;
    private final boolean returnToPrevious;

    private Prompt(@Nullable Component title, String text, Material icon, boolean returnToPrevious) {
        this.title = title;
        this.text = text;
        this.icon = icon;
        this.returnToPrevious = returnToPrevious;
    }

    public static Prompt create() {
        return new Prompt(null, "", Material.PAPER, true);
    }

    /** Anvil title. Accepts MiniMessage or legacy text. Default: the vanilla anvil title. */
    public Prompt title(String title) {
        return title(Objects.requireNonNullElse(TextFormat.parse(title), Component.empty()));
    }

    public Prompt title(Component title) {
        return new Prompt(Objects.requireNonNull(title, "title"), text, icon, returnToPrevious);
    }

    /** Text already in the field when the anvil opens. Default: empty. */
    public Prompt text(String text) {
        return new Prompt(title, Objects.requireNonNull(text, "text"), icon, returnToPrevious);
    }

    /** Item shown in the anvil. Default: paper. */
    public Prompt icon(Material icon) {
        if(!icon.isItem() || icon.isAir()) {
            throw new IllegalArgumentException(icon + " is not an item");
        }
        return new Prompt(title, text, icon, returnToPrevious);
    }

    /** Whether the Loom menu open before the prompt comes back afterwards. Default: true. */
    public Prompt returnToPrevious(boolean returnToPrevious) {
        return new Prompt(title, text, icon, returnToPrevious);
    }

    /** Opens the prompt. {@code onSubmit} receives the text as typed; validate it yourself. */
    public void open(Player player, Consumer<String> onSubmit) {
        open(player, onSubmit, () -> { });
    }

    /**
     * Opens the prompt.
     *
     * @param onSubmit receives the text when the player clicks the result slot
     * @param onCancel runs when the player closes the anvil without submitting
     */
    public void open(Player player, Consumer<String> onSubmit, Runnable onCancel) {
        Objects.requireNonNull(player, "player");
        Objects.requireNonNull(onSubmit, "onSubmit");
        Objects.requireNonNull(onCancel, "onCancel");
        if(Loom.shuttingDown) {
            return;
        }
        Loom.plugin();
        Loom.sync(player, () -> start(player, onSubmit, onCancel));
    }

    private void start(Player player, Consumer<String> onSubmit, Runnable onCancel) {
        if(!player.isOnline()) {
            return;
        }
        View previous = null;
        if(returnToPrevious) {
            previous = View.of(player);
            View inherited = handoff.get();
            if(previous == null && inherited != null && inherited.player() == player) {
                previous = inherited;
            }
        }

        Session replaced = SESSIONS.get(player.getUniqueId());
        if(replaced != null) {
            // a prompt opened from another prompt returns to where the first one would have
            if(previous == null && returnToPrevious) {
                previous = replaced.previous;
            }
            replaced.abandon();
        }

        InventoryView[] opened = new InventoryView[1];
        Runnable open = () -> opened[0] = opener.open(player, title);
        if(previous != null) {
            previous.replaceWith(open);
        } else {
            open.run();
        }
        InventoryView view = opened[0];
        Session session = new Session(this, player, view, previous, onSubmit, onCancel);
        if(!session.isOpen()) {
            return; // another plugin cancelled the open
        }

        // register first: placing the item fires PrepareAnvilEvent, which fills the result slot
        SESSIONS.put(player.getUniqueId(), session);
        view.getTopInventory().setItem(0, item(text));
        if(view instanceof AnvilView anvil) {
            anvil.setRepairCost(0);
        }
    }

    ItemStack item(String text) {
        ItemStack item = new ItemStack(icon);
        item.editMeta(meta -> meta.customName(Component.text(text).decoration(TextDecoration.ITALIC, false)));
        return item;
    }

    // ---------------------------------------------------------------- session lookup

    static @Nullable Session session(InventoryView view) {
        Player player = view.getPlayer() instanceof Player p ? p : null;
        if(player == null) {
            return null;
        }
        Session session = SESSIONS.get(player.getUniqueId());
        return session != null && session.matches(view) ? session : null;
    }

    /** True if the player is looking at a prompt right now. */
    static boolean isOpen(Player player) {
        Session session = SESSIONS.get(player.getUniqueId());
        return session != null && session.isOpen();
    }

    /** Closes the player's prompt without callbacks if it would return to the menu. */
    static boolean abandonIfLeadsTo(Player player, Menu menu) {
        Session session = SESSIONS.get(player.getUniqueId());
        if(session == null || session.previous == null || !session.previous.leadsTo(menu)) {
            return false;
        }
        session.abandon();
        return true;
    }

    static int sessions() {
        return SESSIONS.size();
    }

    /** Players with an open prompt. Safe from any thread. */
    static List<Player> sessionPlayers() {
        List<Player> players = new ArrayList<>();
        for(Session session : SESSIONS.values()) {
            players.add(session.player);
        }
        return players;
    }

    static boolean hasSession(Player player) {
        return SESSIONS.containsKey(player.getUniqueId());
    }

    /** Closes the player's prompt without callbacks. Used when Loom is uninstalled; player's thread only. */
    static void abandon(Player player) {
        Session session = SESSIONS.get(player.getUniqueId());
        if(session != null) {
            session.abandon();
        }
    }

    /** Forgets every prompt, after Loom closed the ones it could when uninstalled. */
    static void forgetAll() {
        SESSIONS.clear();
    }

    static final class Session {

        private final Prompt prompt;
        private final Player player;
        private final InventoryView view;
        private final @Nullable View previous;
        private final Consumer<String> onSubmit;
        private final Runnable onCancel;
        private String text;
        private boolean finished;

        private Session(Prompt prompt, Player player, InventoryView view, @Nullable View previous,
                        Consumer<String> onSubmit, Runnable onCancel) {
            this.prompt = prompt;
            this.player = player;
            this.view = view;
            this.previous = previous;
            this.onSubmit = onSubmit;
            this.onCancel = onCancel;
            this.text = prompt.text;
        }

        boolean matches(InventoryView other) {
            return other == view || other.getTopInventory().equals(view.getTopInventory());
        }

        boolean isOpen() {
            return matches(player.getOpenInventory());
        }

        /** Called on every keystroke: remembers the text and shows it on a free result item. */
        void typed(AnvilView anvil, Consumer<ItemStack> setResult) {
            String typed = anvil.getRenameText();
            if(typed != null) {
                text = typed;
            }
            setResult.accept(prompt.item(text));
            anvil.setRepairCost(0);
        }

        void submit() {
            if(finished) {
                return;
            }
            finished = true;
            String submitted = text;
            // the player submitted, so the callback also runs if they leave before the next tick
            Loom.later(player, () -> {
                if(isOpen()) {
                    player.closeInventory();
                }
                runCallback(() -> onSubmit.accept(submitted), "submit");
            }, () -> invoke(() -> onSubmit.accept(submitted), "submit"));
        }

        void closed(InventoryCloseEvent event) {
            SESSIONS.remove(player.getUniqueId(), this);
            view.getTopInventory().clear(); // the input item must never reach the player
            if(finished) {
                return;
            }
            finished = true;
            if(Loom.shuttingDown || event.getReason() == InventoryCloseEvent.Reason.DISCONNECT
                    || Loom.isLeaving(player)) {
                Loom.releaseParked(player); // the menu behind the prompt will not come back
                return;
            }
            Loom.later(player, () -> runCallback(onCancel, "cancel"), () -> invoke(onCancel, "cancel"));
        }

        private void runCallback(Runnable callback, String name) {
            View outer = handoff.get();
            handoff.set(previous);
            try {
                invoke(callback, name);
            } finally {
                if(outer == null) {
                    handoff.remove();
                } else {
                    handoff.set(outer);
                }
            }
            returnIfIdle();
            Loom.releaseParkedIfAway(player);
        }

        private void invoke(Runnable callback, String name) {
            try {
                callback.run();
            } catch(RuntimeException e) {
                Loom.log("Loom prompt " + name + " handler failed for " + player.getName(), e);
            }
        }

        /** Closes without callbacks and without returning. */
        void abandon() {
            finished = true;
            SESSIONS.remove(player.getUniqueId(), this);
            view.getTopInventory().clear();
            if(isOpen()) {
                player.closeInventory();
            }
        }

        private void returnIfIdle() {
            // only if the callbacks did not open something else
            if(previous != null && player.isOnline() && !Loom.isLeaving(player) && View.isIdle(player)) {
                previous.show();
            }
        }
    }
}
