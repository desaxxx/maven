package dev.dash.loom;

import org.bukkit.Bukkit;
import org.jspecify.annotations.Nullable;

import java.util.Objects;
import java.util.concurrent.CompletionException;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ExecutionException;
import java.util.function.Consumer;

/**
 * Work started by {@link Click#async} or {@link Click#await}. While it runs, the menu is busy
 * ({@link Ui#busy()}): its buttons ignore clicks and its input slots are locked.
 *
 * <p>{@link #then} and {@link #fail} run on the player's thread (the main thread on Paper, the
 * player's region thread on Folia), also when the player closed the menu in the meantime: if the
 * work took money, the item must still be given. They do not run if the player left the server;
 * that is logged.</p>
 */
public final class ClickTask<T extends @Nullable Object> {

    private final View view;
    private @Nullable Consumer<? super T> onSuccess;
    private @Nullable Consumer<Throwable> onFailure;
    private boolean done;
    private @Nullable T value;
    private @Nullable Throwable error;

    ClickTask(View view, CompletionStage<T> work) {
        this.view = view;
        view.beginBusy();
        work.whenComplete((result, failure) -> {
            try {
                Loom.later(view.player(), () -> complete(result, failure), () -> dropped(unwrap(failure)));
            } catch(RuntimeException e) {
                // the plugin is being disabled: nothing can be scheduled anymore
                Bukkit.getLogger().warning("Loom click task finished after its plugin was disabled; result dropped");
            }
        });
    }

    /** The player left before the result could be delivered. */
    private void dropped(@Nullable Throwable failure) {
        Loom.warn("Loom click task of " + view.menu().displayName() + " finished after "
                + view.player().getName() + " left; its then/fail callbacks were not run"
                + (failure != null ? " (it failed: " + failure + ")" : ""));
    }

    /** Runs with the result on the player's thread. */
    public ClickTask<T> then(Consumer<? super T> onSuccess) {
        this.onSuccess = Objects.requireNonNull(onSuccess, "onSuccess");
        if(done && error == null) {
            run(() -> onSuccess.accept(value), "then");
        }
        return this;
    }

    /** Runs on the player's thread if the work threw. Without it, the error is logged. */
    public ClickTask<T> fail(Consumer<Throwable> onFailure) {
        this.onFailure = Objects.requireNonNull(onFailure, "onFailure");
        if(done && error != null) {
            Throwable failure = error;
            run(() -> onFailure.accept(failure), "fail");
        }
        return this;
    }

    private void complete(@Nullable T result, @Nullable Throwable failure) {
        view.batch(() -> deliver(result, failure));
    }

    private void deliver(@Nullable T result, @Nullable Throwable failure) {
        done = true;
        value = result;
        error = unwrap(failure);
        view.endBusy();
        if(!view.player().isOnline()) {
            dropped(error);
            return;
        }
        if(error == null) {
            Consumer<? super T> success = onSuccess;
            if(success != null) {
                run(() -> success.accept(result), "then");
            }
        } else {
            Consumer<Throwable> failed = onFailure;
            Throwable cause = error;
            if(failed != null) {
                run(() -> failed.accept(cause), "fail");
            } else {
                Loom.log("Loom click task failed in " + view.menu().displayName() + " for " + view.player().getName(), cause);
            }
        }
    }

    private void run(Runnable callback, String name) {
        try {
            callback.run();
        } catch(RuntimeException e) {
            Loom.log("Loom click task " + name + " callback failed for " + view.player().getName(), e);
        }
    }

    private static @Nullable Throwable unwrap(@Nullable Throwable failure) {
        while((failure instanceof CompletionException || failure instanceof ExecutionException) && failure.getCause() != null) {
            failure = failure.getCause();
        }
        return failure;
    }
}
