package dev.dash.loom;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.jspecify.annotations.Nullable;

import java.util.Objects;
import java.util.concurrent.CompletableFuture;

/**
 * A yes / no question.
 *
 * <pre>{@code
 * ui.put(8, DELETE_ICON, click -> Confirm.create()
 *         .title("<red>Delete this home?")
 *         .open(click.player(), () -> homes.delete(home)));
 * }</pre>
 *
 * <p>Whatever the answer, the menu that was open before comes back with its state, and then
 * the callback runs. Closing the question (escape) counts as "no". A callback that opens
 * another menu or a {@link Prompt} simply replaces the returned menu, and back navigation from
 * there skips the question.</p>
 *
 * <p>Confirms are immutable and reusable.</p>
 */
public final class Confirm {

    private static final ItemStack FILLER = Loom.filler(Material.GRAY_STAINED_GLASS_PANE);

    private final String title;
    private final ItemStack yes;
    private final ItemStack no;
    private final @Nullable ItemStack info;
    private final boolean returnToPrevious;

    private Confirm(String title, ItemStack yes, ItemStack no, @Nullable ItemStack info, boolean returnToPrevious) {
        this.title = title;
        this.yes = yes;
        this.no = no;
        this.info = info;
        this.returnToPrevious = returnToPrevious;
    }

    public static Confirm create() {
        return new Confirm("Are you sure?",
                Loom.item(Material.LIME_CONCRETE, "<green>Yes"),
                Loom.item(Material.RED_CONCRETE, "<red>No"),
                null, true);
    }

    /** The question, shown as the title. Accepts MiniMessage, legacy codes and placeholders. */
    public Confirm title(String title) {
        return new Confirm(Objects.requireNonNull(title, "title"), yes, no, info, returnToPrevious);
    }

    public Confirm yes(ItemStack icon) {
        return new Confirm(title, Objects.requireNonNull(icon, "icon"), no, info, returnToPrevious);
    }

    public Confirm no(ItemStack icon) {
        return new Confirm(title, yes, Objects.requireNonNull(icon, "icon"), info, returnToPrevious);
    }

    /** An item between the two buttons, e.g. what is about to be deleted. */
    public Confirm info(ItemStack icon) {
        return new Confirm(title, yes, no, Objects.requireNonNull(icon, "icon"), returnToPrevious);
    }

    /** Whether the Loom menu open before the question comes back afterwards. Default: true. */
    public Confirm returnToPrevious(boolean returnToPrevious) {
        return new Confirm(title, yes, no, info, returnToPrevious);
    }

    public CompletableFuture<Boolean> open(Player player, Runnable onYes) {
        return open(player, onYes, () -> { });
    }

    /**
     * Asks the question.
     *
     * @return completes with whether the question was shown, like {@link Menu#open(Player)}
     */
    public CompletableFuture<Boolean> open(Player player, Runnable onYes, Runnable onNo) {
        Objects.requireNonNull(player, "player");
        Objects.requireNonNull(onYes, "onYes");
        Objects.requireNonNull(onNo, "onNo");
        if(Loom.shuttingDown) {
            return CompletableFuture.completedFuture(false);
        }
        Loom.plugin();
        CompletableFuture<Boolean> opened = new CompletableFuture<>();
        Loom.sync(player, () -> opened.complete(start(player, onYes, onNo)), () -> opened.complete(false));
        return opened;
    }

    private boolean start(Player player, Runnable onYes, Runnable onNo) {
        View previous = returnToPrevious ? View.of(player) : null;
        Question question = new Question(player, previous, onYes, onNo);
        View view = new View(Menu.of(question::render).name("confirm"), player, previous);
        question.view = view;
        if(previous == null) {
            return view.show();
        }
        boolean[] shown = {false};
        previous.replaceWith(() -> shown[0] = view.show());
        return shown[0];
    }

    private final class Question {

        private final Player player;
        private final @Nullable View previous;
        private final Runnable onYes;
        private final Runnable onNo;
        private @Nullable View view;
        private boolean answered;

        Question(Player player, @Nullable View previous, Runnable onYes, Runnable onNo) {
            this.player = player;
            this.previous = previous;
            this.onYes = onYes;
            this.onNo = onNo;
        }

        void render(Ui ui) {
            ui.title(title);
            ui.rows(3);
            ui.background(FILLER);
            ui.put(11, yes, click -> answer(onYes));
            ui.put(15, no, click -> answer(onNo));
            if(info != null) {
                ui.put(13, info);
            }
            ui.onClose(close -> {
                if(close.reason() == CloseReason.PLAYER) {
                    answer(onNo);
                }
            });
        }

        /**
         * Returns to the previous menu first, then runs the callback, on the next tick. The
         * answer was given, so the callback also runs if the player leaves before that tick.
         */
        private void answer(Runnable callback) {
            if(answered) {
                return;
            }
            answered = true;
            Loom.later(player, () -> {
                if(view != null && View.of(player) == view) {
                    if(previous != null) {
                        view.replaceWith(previous::show);
                    } else {
                        player.closeInventory();
                    }
                } else if(previous != null && player.isOnline() && !Loom.isLeaving(player) && View.isIdle(player)) {
                    previous.show(); // closed with escape
                }
                run(callback);
            }, () -> run(callback));
        }

        private void run(Runnable callback) {
            try {
                callback.run();
            } catch(RuntimeException e) {
                Loom.log("Loom confirm handler failed for " + player.getName(), e);
            }
        }
    }
}
