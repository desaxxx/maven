package dev.dash.loom;

import com.tcoded.folialib.FoliaLib;
import com.tcoded.folialib.enums.EntityTaskResult;
import com.tcoded.folialib.impl.PlatformScheduler;
import com.tcoded.folialib.util.FoliaLibOptions;
import com.tcoded.folialib.wrapper.task.WrappedTask;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.jspecify.annotations.Nullable;

import java.util.concurrent.Executor;

/**
 * Loom's only contact with the server scheduler, through FoliaLib.
 *
 * <p>Threading model: everything a view does runs on its player's thread. On Paper that is the
 * main thread; on Folia it is the thread of the region the player is in, and tasks follow the
 * player when they move to another region.</p>
 */
final class LoomScheduler {

    private final FoliaLib folia;
    private final PlatformScheduler scheduler;
    /** Folia has no single tick counter, so Loom counts global region ticks itself. */
    private final @Nullable WrappedTask clock;
    private volatile long tick;

    LoomScheduler(Plugin plugin) {
        FoliaLibOptions options = new FoliaLibOptions();
        // Paper: run player tasks like Bukkit's scheduler did, also for dead or offline players
        options.disableIsValidOnNonFolia();
        folia = new FoliaLib(plugin, options);
        scheduler = folia.getScheduler();
        clock = folia.isFolia() ? scheduler.runTimer(this::advance, 1, 1) : null;
    }

    @SuppressWarnings("NonAtomicOperationOnVolatileField") // only the global region thread writes
    private void advance() {
        tick++;
    }

    boolean isFolia() {
        return folia.isFolia();
    }

    /** Current tick; only differences between two values are meaningful. */
    long currentTick() {
        return clock != null ? tick : Bukkit.getCurrentTick();
    }

    /** True if the current thread may touch the player (the main thread on Paper). */
    boolean owns(Player player) {
        return scheduler.isOwnedByCurrentRegion(player);
    }

    /**
     * Runs the task on the player's thread on the next tick. If the player is gone before it can
     * run (Folia only; Paper always runs it), {@code retired} runs instead, on any thread.
     */
    void run(Player player, Runnable task, @Nullable Runnable retired) {
        Runnable fallback = retired != null ? retired : () -> { };
        scheduler.runAtEntityWithFallback(player, ignored -> task.run(), fallback).thenAccept(result -> {
            if(result == EntityTaskResult.SCHEDULER_RETIRED) {
                fallback.run(); // the player was already gone: FoliaLib does not call the fallback
            }
        });
    }

    /** Runs the task on the player's thread every {@code period} ticks, until cancelled. */
    WrappedTask timer(Player player, Runnable task, long period) {
        return scheduler.runAtEntityTimer(player, task, period, period);
    }

    /** Runs tasks off the server threads. */
    Executor async() {
        return task -> scheduler.runAsync(ignored -> task.run());
    }

    void shutdown() {
        if(clock != null) {
            clock.cancel();
        }
    }
}
