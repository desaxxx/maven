package dev.dash.loom;

/** Why a menu stopped being shown. */
public enum CloseReason {
    /** The player closed it (escape / inventory key). */
    PLAYER,
    /** Another menu or inventory replaced it. */
    NAVIGATE,
    /** The player left the server. */
    DISCONNECT,
    /** The plugin that owns Loom is being disabled (server stop or reload). */
    SHUTDOWN,
    /** A plugin, death, teleport or the server closed it. */
    PLUGIN
}
