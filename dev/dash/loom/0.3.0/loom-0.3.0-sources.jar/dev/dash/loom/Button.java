package dev.dash.loom;

import net.kyori.adventure.sound.Sound;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.ItemStack;
import org.jspecify.annotations.Nullable;

import java.util.Objects;
import java.util.function.Predicate;

/**
 * An icon and what happens when it is clicked. Buttons are plain values; they are created again
 * on every render, so there is nothing to update or remove. The {@code sound} methods return a
 * new button.
 */
public final class Button {

    private final ItemStack icon;
    private final @Nullable ClickHandler handler;
    private final SoundRules sounds;

    public Button(ItemStack icon, @Nullable ClickHandler handler) {
        this(icon, handler, SoundRules.NONE);
    }

    private Button(ItemStack icon, @Nullable ClickHandler handler, SoundRules sounds) {
        this.icon = Objects.requireNonNull(icon, "icon");
        this.handler = handler;
        this.sounds = sounds;
    }

    public static Button of(ItemStack icon) {
        return new Button(icon, null);
    }

    public static Button of(ItemStack icon, ClickHandler handler) {
        return new Button(icon, handler);
    }

    public ItemStack icon() {
        return icon;
    }

    public @Nullable ClickHandler handler() {
        return handler;
    }

    /**
     * Sound of this button when no rule below matches. Overrides the menu's sounds. Only played
     * for buttons with a handler.
     */
    public Button sound(Sound sound) {
        return new Button(icon, handler, sounds.fallback(sound));
    }

    /**
     * Sound for one exact click type, e.g. {@code ClickType.RIGHT}. {@code SHIFT_RIGHT} is a
     * different type; use {@link #sound(Predicate, Sound)} with {@code Click::isRight} to match
     * both. Rules are checked in the order they were added.
     */
    public Button sound(ClickType type, Sound sound) {
        return new Button(icon, handler, sounds.when(type, sound));
    }

    /** Sound for clicks matching the condition, e.g. {@code Click::isShift}. */
    public Button sound(Predicate<Click> when, Sound sound) {
        return new Button(icon, handler, sounds.when(when, sound));
    }

    /** No sound for this button, even if the menu has one. */
    public Button silent() {
        return new Button(icon, handler, sounds.fallback(SoundRules.SILENT));
    }

    SoundRules sounds() {
        return sounds;
    }

    @Override
    public boolean equals(Object other) {
        return other instanceof Button button && icon.equals(button.icon) && Objects.equals(handler, button.handler)
                && sounds == button.sounds;
    }

    @Override
    public int hashCode() {
        return Objects.hash(icon, handler);
    }

    @Override
    public String toString() {
        return "Button[" + icon.getType() + (handler != null ? ", clickable" : "") + "]";
    }
}
