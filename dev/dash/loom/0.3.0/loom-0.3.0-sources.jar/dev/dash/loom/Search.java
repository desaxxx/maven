package dev.dash.loom;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.jspecify.annotations.Nullable;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.function.BiPredicate;
import java.util.function.Function;
import java.util.regex.Pattern;

/**
 * A search box returned by {@link Ui#search()}. The query is view state: it survives
 * {@link Click#back()}, and changing it redraws the menu and sends every pager and scroller of
 * the menu back to the start.
 *
 * <pre>{@code
 * Search search = ui.search();
 * List<Warp> shown = search.filter(warps, Warp::name);
 * ui.put('s', search.button(Material.COMPASS));   // left click: type a query, right click: clear
 * ui.paginate('x', shown, w -> Button.of(w.icon()));
 * }</pre>
 */
public final class Search {

    private static final Pattern LEGACY_CODE = Pattern.compile("[§&][0-9a-fk-orA-FK-ORxX]");
    private static final Pattern TAG = Pattern.compile("<[^<>]*>");
    private static final Pattern WHITESPACE = Pattern.compile("\\s+");
    private static final Pattern MARKS = Pattern.compile("\\p{M}+");
    private static final Prompt PROMPT = Prompt.create().title("Search").icon(Material.NAME_TAG);

    private final View view;
    private final Signal<String> query;
    private final Cache cache;

    /**
     * What the last {@link #filter(List, Function)} saw, so a render with the same list and query
     * neither normalizes the texts again nor filters again.
     */
    static final class Cache {
        private @Nullable List<?> snapshot;
        private @Nullable Class<?> textFunction;
        private String @Nullable [] normalized;
        private @Nullable String query;
        private @Nullable List<?> result;
    }

    Search(View view, Signal<String> query, Cache cache) {
        this.view = view;
        this.query = query;
        this.cache = cache;
    }

    /** The query, trimmed; empty when there is none. Read in a render, it is watched. */
    public String query() {
        return query.get();
    }

    public boolean isActive() {
        return !query().isEmpty();
    }

    /** Sets the query. A different query sends pagers and scrollers back to the start. */
    public void set(String query) {
        String trimmed = Objects.requireNonNull(query, "query").strip();
        if(trimmed.equals(this.query.peek())) {
            return;
        }
        this.query.set(trimmed);
        view.resetPositions();
    }

    public void clear() {
        set("");
    }

    /**
     * The items whose text contains every word of the query, in their original order; all of
     * them when there is no query. Case, accents and formatting codes are ignored, and dotted and
     * dotless i match each other: "kirsehir" finds "Kırşehir".
     *
     * <p>The prepared texts and the result are kept between renders while the list (compared
     * with {@code equals}) and the query stay the same, so redraws for other reasons, such as
     * scrolling, cost almost nothing. The returned list must not be modified.</p>
     */
    @SuppressWarnings("unchecked")
    public <T extends @Nullable Object> List<T> filter(List<T> items, Function<? super T, String> text) {
        Objects.requireNonNull(text, "text");
        String current = query();
        String[] words = words(current);
        if(words.length == 0) {
            return items;
        }
        boolean sameList = cache.textFunction == text.getClass() && items.equals(cache.snapshot);
        if(sameList && current.equals(cache.query) && cache.result != null) {
            return (List<T>) cache.result;
        }
        if(!sameList) {
            String[] prepared = new String[items.size()];
            for(int i = 0; i < prepared.length; i++) {
                prepared[i] = normalize(text.apply(items.get(i)));
            }
            cache.snapshot = new ArrayList<>(items);
            cache.textFunction = text.getClass();
            cache.normalized = prepared;
        }
        String[] prepared = Objects.requireNonNull(cache.normalized);
        List<T> matching = new ArrayList<>();
        for(int i = 0; i < prepared.length; i++) {
            boolean all = true;
            for(String word : words) {
                if(!prepared[i].contains(word)) {
                    all = false;
                    break;
                }
            }
            if(all) {
                matching.add(items.get(i));
            }
        }
        List<T> result = Collections.unmodifiableList(matching);
        cache.query = current;
        cache.result = result;
        return result;
    }

    /** The items the predicate accepts for the query; all of them when there is no query. */
    public <T extends @Nullable Object> List<T> filter(List<T> items, BiPredicate<? super T, String> matches) {
        Objects.requireNonNull(matches, "matches");
        String current = query();
        if(current.isEmpty()) {
            return items;
        }
        List<T> matching = new ArrayList<>();
        for(T item : items) {
            if(matches.test(item, current)) {
                matching.add(item);
            }
        }
        return matching;
    }

    /**
     * A ready-made search button: left click opens a {@link Prompt} for the query, right click
     * clears it. Its lore shows the query, and it glows while a query is set.
     */
    public Button button(Material icon) {
        ItemStack item = Loom.item(icon, "<yellow>Search");
        String current = query();
        List<Component> lore = new ArrayList<>();
        lore.add(current.isEmpty()
                ? line("No filter", NamedTextColor.GRAY)
                : line("Query: ", NamedTextColor.GRAY).append(Component.text(current, NamedTextColor.WHITE)));
        lore.add(Component.empty());
        lore.add(line("Left click: search", NamedTextColor.GRAY));
        if(!current.isEmpty()) {
            lore.add(line("Right click: clear", NamedTextColor.GRAY));
        }
        item.editMeta(meta -> meta.lore(lore));
        return button(item, PROMPT);
    }

    /**
     * Like {@link #button(Material)} with your own icon (it glows while a query is set) and
     * prompt, e.g. for another language.
     */
    public Button button(ItemStack icon, Prompt prompt) {
        Objects.requireNonNull(prompt, "prompt");
        ItemStack shown = icon.clone();
        if(isActive()) {
            shown.editMeta(meta -> meta.setEnchantmentGlintOverride(true));
        }
        return Button.of(shown, click -> {
            if(click.isRight()) {
                clear();
            } else {
                prompt.text(query.peek()).open(click.player(), this::set);
            }
        });
    }

    private static Component line(String text, NamedTextColor color) {
        return Component.text(text, color).decoration(TextDecoration.ITALIC, false);
    }

    private static String[] words(String text) {
        String normalized = normalize(text).strip();
        return normalized.isEmpty() ? new String[0] : WHITESPACE.split(normalized);
    }

    static String normalize(@Nullable String text) {
        if(text == null) {
            return "";
        }
        String plain = TAG.matcher(LEGACY_CODE.matcher(text).replaceAll("")).replaceAll("");
        // dotless and dotted i are separate letters, not accents: fold them by hand
        plain = plain.replace('İ', 'i').replace('I', 'i').replace('ı', 'i');
        plain = MARKS.matcher(Normalizer.normalize(plain, Normalizer.Form.NFD)).replaceAll("");
        return plain.toLowerCase(Locale.ROOT);
    }
}
