package dev.dash.loom;

import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryCloseEvent;

/**
 * Details of a closed menu, passed to {@link Ui#onClose}.
 *
 * <p>On {@link CloseReason#SHUTDOWN} the plugin is being disabled: save synchronously and do
 * not schedule tasks or open menus.</p>
 *
 * @param player the viewer
 * @param menu   the menu that was closed
 * @param reason why it was closed
 * @param event  the raw Bukkit event
 */
public record Close(Player player, Menu menu, CloseReason reason, InventoryCloseEvent event) {
}
