package dev.dash.loom;

import org.jspecify.annotations.Nullable;

import java.util.NoSuchElementException;
import java.util.concurrent.CompletionStage;
import java.util.function.Supplier;

/**
 * Data loaded off the server threads for a menu, created by {@link Ui#load} or {@link Ui#await}.
 * The menu redraws by itself when the data arrives, so the render function just asks:
 *
 * <pre>{@code
 * Async<Stats> stats = ui.load("stats", () -> database.stats(ui.player().getUniqueId()));
 * if(stats.isReady()) {
 *     ui.put(13, Loom.item(Material.BOOK, "Kills: " + stats.get().kills()));
 * } else if(stats.isFailed()) {
 *     ui.put(13, Loom.item(Material.BARRIER, "<red>Could not load"));
 * } else {
 *     ui.put(13, Loom.item(Material.CLOCK, "<gray>Loading..."));
 * }
 * }</pre>
 *
 * <p>Loading starts once per view, the first time the render asks for it, and the result is
 * kept while the view lives (also across {@link Click#back()}). Use {@link #reload()} to fetch
 * again.</p>
 */
public final class Async<T extends @Nullable Object> {

    private enum Status { LOADING, READY, FAILED }

    private record Result<T>(Status status, @Nullable T value, @Nullable Throwable error) {
    }

    private final String name;
    private final Supplier<? extends CompletionStage<T>> source;
    private final Signal<Result<T>> result;
    private int generation;

    Async(String name, Supplier<? extends CompletionStage<T>> source) {
        this.name = name;
        this.source = source;
        this.result = Signal.of("load:" + name, new Result<>(Status.LOADING, null, null));
    }

    void start() {
        int run;
        synchronized(this) {
            run = ++generation;
        }
        result.set(new Result<>(Status.LOADING, null, null));
        CompletionStage<T> stage;
        try {
            stage = source.get();
        } catch(RuntimeException e) {
            fail(run, e);
            return;
        }
        stage.whenComplete((value, error) -> {
            if(error != null) {
                fail(run, error);
            } else {
                complete(run, new Result<>(Status.READY, value, null));
            }
        });
    }

    private void fail(int run, Throwable error) {
        Loom.log("Loom could not load '" + name + "'", error);
        complete(run, new Result<>(Status.FAILED, null, error));
    }

    private void complete(int run, Result<T> outcome) {
        synchronized(this) {
            if(run != generation) {
                return; // a newer reload is running
            }
        }
        // Signals are thread safe and the redraw happens on the player's thread. A source that is
        // already done completes inside the render that started it; that is fine, as nothing
        // watches this signal until the render reads it afterwards.
        result.set(outcome);
    }

    public boolean isLoading() {
        return result.get().status() == Status.LOADING;
    }

    public boolean isReady() {
        return result.get().status() == Status.READY;
    }

    public boolean isFailed() {
        return result.get().status() == Status.FAILED;
    }

    /**
     * The loaded value.
     *
     * @throws NoSuchElementException if it is not {@link #isReady() ready}
     */
    public T get() {
        Result<T> current = result.get();
        if(current.status() != Status.READY) {
            throw new NoSuchElementException("'" + name + "' is " + current.status().name().toLowerCase());
        }
        return current.value();
    }

    /** The loaded value, or the fallback while loading or after a failure. */
    public T orElse(T fallback) {
        Result<T> current = result.get();
        return current.status() == Status.READY ? current.value() : fallback;
    }

    /** Why loading failed, or null. */
    public @Nullable Throwable error() {
        return result.get().error();
    }

    /** Loads again; the menu shows the loading state until the new value arrives. */
    public void reload() {
        start();
    }

    @Override
    public String toString() {
        return "Async[" + name + ": " + result.peek().status() + "]";
    }
}
