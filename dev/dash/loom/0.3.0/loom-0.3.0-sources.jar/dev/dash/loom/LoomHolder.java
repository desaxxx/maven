package dev.dash.loom;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jspecify.annotations.Nullable;

/** Marks an inventory as a Loom menu. One holder per created inventory. */
final class LoomHolder implements InventoryHolder {

    private final View view;
    private @Nullable Inventory inventory;

    LoomHolder(View view) {
        this.view = view;
    }

    View view() {
        return view;
    }

    void inventory(Inventory inventory) {
        this.inventory = inventory;
    }

    /** False when the view has since replaced this inventory (rows changed, reopened). */
    boolean isCurrent() {
        return inventory != null && view.inventory() == inventory;
    }

    @Override
    public Inventory getInventory() {
        if(inventory == null) {
            throw new IllegalStateException("inventory not created yet");
        }
        return inventory;
    }
}
