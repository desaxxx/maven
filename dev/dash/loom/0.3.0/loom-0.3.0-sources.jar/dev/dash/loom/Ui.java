package dev.dash.loom;

import dev.dash.itemstack.builder.TextFormat;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.jspecify.annotations.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.TreeMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

/**
 * The canvas a render function draws on. A new {@code Ui} is handed to the render function on
 * every redraw; describe the whole menu each time and Loom updates only what changed.
 *
 * <p><b>The render function runs again on every change</b> (each signal update, each
 * {@link #every} tick), possibly many times a second. Keep it fast and free of side effects:
 * no database or file access, no network, no changing signals. Load slow data with
 * {@link #load} or {@link #await}, and do work in click handlers.</p>
 *
 * <p>Slots are zero-based. When neither {@link #rows(int)} nor {@link #layout(String...)} is
 * given, the menu is just tall enough for the highest slot used.</p>
 */
public final class Ui {

    private static final int COLUMNS = 9;
    private static final int MAX_ROWS = 6;
    /** Key prefix of pager and scroller positions; a new search query resets them. */
    static final String POSITION_PREFIX = "loom:position:";

    private final View view;
    private final @Nullable Button[] buttons = new Button[COLUMNS * MAX_ROWS];
    private final Map<Integer, Predicate<ItemStack>> inputs = new LinkedHashMap<>();
    private Component title = Component.empty();
    private int rows;
    private String @Nullable [] layout;
    private int highestSlot = -1;
    private @Nullable ItemStack background;
    private @Nullable Consumer<Close> onClose;
    private @Nullable ClickHandler onInventoryClick;
    private int refresh;
    private int stateIndex;

    Ui(View view) {
        this.view = view;
    }

    /** The player this menu is drawn for. */
    public Player player() {
        return view.player();
    }

    // ---------------------------------------------------------------- shape

    /**
     * Sets the title. Placeholders are resolved for the viewer (see {@link #text}), then
     * MiniMessage ({@code <gold>}) or legacy ({@code &6}) formatting is applied.
     */
    public Ui title(String title) {
        Component parsed = TextFormat.parse(text(title));
        this.title = parsed == null ? Component.empty() : parsed;
        return this;
    }

    // ---------------------------------------------------------------- text

    /**
     * Resolves placeholders for the viewer, e.g. {@code %player_name%} with PlaceholderAPI.
     * Uses {@link Loom#placeholders()}. Formatting codes are left as they are.
     */
    public String text(String text) {
        return Loom.placeholders().parse(player(), text);
    }

    /**
     * Like {@link Loom#item}, with placeholders in the name and lore resolved for the viewer.
     *
     * <pre>{@code
     * ui.put(4, ui.item(Material.PLAYER_HEAD, "<gold>%player_name%", "<gray>Balance: %vault_eco_balance%"));
     * }</pre>
     */
    public ItemStack item(Material material, String name, String... lore) {
        String[] resolved = new String[lore.length];
        for(int i = 0; i < lore.length; i++) {
            resolved[i] = text(lore[i]);
        }
        return Loom.item(material, text(name), resolved);
    }

    public Ui title(Component title) {
        this.title = Objects.requireNonNull(title, "title");
        return this;
    }

    /**
     * Fixes the height (1-6). Changing it between renders reopens the inventory, keeping the
     * state.
     */
    public Ui rows(int rows) {
        if(rows < 1 || rows > MAX_ROWS) {
            throw new IllegalArgumentException("rows must be between 1 and 6, got " + rows);
        }
        this.rows = rows;
        return this;
    }

    /**
     * Draws the menu as text, one string per row. Every character is a key you can use with
     * {@link #put(char, ItemStack, ClickHandler)} and {@link #slots(char)}. Short lines are
     * padded with spaces. Sets the height unless {@link #rows(int)} was called.
     *
     * <pre>{@code
     * ui.layout(
     *     "#########",
     *     "# a b c #",
     *     "#<  i  >#");
     * }</pre>
     */
    public Ui layout(String... lines) {
        if(lines.length < 1 || lines.length > MAX_ROWS) {
            throw new IllegalArgumentException("layout must have 1-6 lines, got " + lines.length);
        }
        String[] padded = new String[lines.length];
        for(int i = 0; i < lines.length; i++) {
            String line = Objects.requireNonNull(lines[i], "layout line");
            if(line.length() > COLUMNS) {
                throw new IllegalArgumentException("layout line " + i + " is longer than 9: \"" + line + "\"");
            }
            padded[i] = line + " ".repeat(COLUMNS - line.length());
        }
        this.layout = padded;
        return this;
    }

    /** Zero-based slot of a row and column. */
    public int slot(int row, int column) {
        if(row < 0 || row >= MAX_ROWS || column < 0 || column >= COLUMNS) {
            throw new IllegalArgumentException("no slot at row " + row + ", column " + column);
        }
        return row * COLUMNS + column;
    }

    /**
     * Slots marked with the key in the layout, in reading order.
     *
     * @throws IllegalStateException if no layout was set
     * @throws IllegalArgumentException if the key does not appear in the layout
     */
    public List<Integer> slots(char key) {
        if(layout == null) {
            throw new IllegalStateException("call layout(...) before using key '" + key + "'");
        }
        List<Integer> slots = new ArrayList<>();
        for(int row = 0; row < layout.length; row++) {
            for(int column = 0; column < COLUMNS; column++) {
                if(layout[row].charAt(column) == key) {
                    slots.add(row * COLUMNS + column);
                }
            }
        }
        if(slots.isEmpty()) {
            throw new IllegalArgumentException("key '" + key + "' is not in the layout");
        }
        return slots;
    }

    // ---------------------------------------------------------------- content

    public Ui put(int slot, Button button) {
        checkSlot(slot);
        if(inputs.containsKey(slot)) {
            throw new IllegalArgumentException("slot " + slot + " is already an input");
        }
        buttons[slot] = Objects.requireNonNull(button, "button");
        highestSlot = Math.max(highestSlot, slot);
        return this;
    }

    /** Puts a decoration that does nothing when clicked. */
    public Ui put(int slot, ItemStack icon) {
        return put(slot, Button.of(icon));
    }

    public Ui put(int slot, ItemStack icon, ClickHandler onClick) {
        return put(slot, Button.of(icon, onClick));
    }

    /** Puts the button on every slot marked with the key. */
    public Ui put(char key, Button button) {
        for(int slot : slots(key)) {
            put(slot, button);
        }
        return this;
    }

    public Ui put(char key, ItemStack icon) {
        return put(key, Button.of(icon));
    }

    public Ui put(char key, ItemStack icon, ClickHandler onClick) {
        return put(key, Button.of(icon, onClick));
    }

    // ---------------------------------------------------------------- input slots

    /**
     * Makes a slot where the player can put and take items, and returns its content.
     *
     * <pre>{@code
     * Signal<ItemStack> offer = ui.input(13, item -> item.getType() == Material.DIAMOND);
     * ItemStack diamonds = offer.get();
     * ui.put(15, Loom.item(Material.EMERALD, "Sell " + (diamonds == null ? 0 : diamonds.getAmount())),
     *        click -> { pay(click.player(), offer.peek()); offer.set(null); });
     * }</pre>
     *
     * <ul>
     *     <li>Reading the signal in the render redraws the menu whenever the player changes the
     *     slot; it updates one tick after the click.</li>
     *     <li>{@code set(null)} consumes the item, {@code set(stack)} puts one there. Treat the
     *     returned stack as read-only and set a new one instead of changing it.</li>
     *     <li>Whatever is still in an input when the menu closes (for any reason, also when
     *     navigating away) goes back to the player, or drops at their feet if they are full.
     *     Items only live in memory while the menu is open: a server crash loses them.</li>
     *     <li>Shift-clicking an accepted item in the player's inventory moves it into the inputs,
     *     unless {@link Menu#lockPlayerInventory(boolean)} is on.</li>
     * </ul>
     *
     * @param accepts which items the slot takes; rejected items cannot be placed
     */
    public Signal<@Nullable ItemStack> input(int slot, Predicate<ItemStack> accepts) {
        checkSlot(slot);
        if(buttons[slot] != null || inputs.containsKey(slot)) {
            throw new IllegalArgumentException("slot " + slot + " is already used");
        }
        inputs.put(slot, Objects.requireNonNull(accepts, "accepts"));
        highestSlot = Math.max(highestSlot, slot);
        Signal<@Nullable ItemStack> content = view.input(slot);
        // always watched: whoever changes it, the inventory slot must follow right away
        content.get();
        return content;
    }

    /** An input slot that takes any item. */
    public Signal<@Nullable ItemStack> input(int slot) {
        return input(slot, item -> true);
    }

    /** Input slots on every slot marked with the key, in reading order. */
    public List<Signal<@Nullable ItemStack>> input(char key, Predicate<ItemStack> accepts) {
        List<Signal<@Nullable ItemStack>> signals = new ArrayList<>();
        for(int slot : slots(key)) {
            signals.add(input(slot, accepts));
        }
        return signals;
    }

    public List<Signal<@Nullable ItemStack>> input(char key) {
        return input(key, item -> true);
    }

    // ---------------------------------------------------------------- async data

    /**
     * Runs the loader on an async thread, once per view, and redraws when it finishes. See
     * {@link Async}. Do not touch the Bukkit API inside the loader.
     *
     * @param key identifies this data within the view
     */
    public <T extends @Nullable Object> Async<T> load(String key, Supplier<T> loader) {
        Objects.requireNonNull(loader, "loader");
        return await(key, () -> Loom.supplyAsync(loader));
    }

    /**
     * Like {@link #load}, for APIs that already return a future (database drivers, HTTP
     * clients, other plugins).
     */
    public <T extends @Nullable Object> Async<T> await(String key, Supplier<? extends CompletionStage<T>> future) {
        Objects.requireNonNull(key, "key");
        Objects.requireNonNull(future, "future");
        boolean[] created = {false};
        Async<T> async = view.async(key, () -> {
            created[0] = true;
            return new Async<>(key, future);
        });
        if(created[0]) {
            async.start();
        }
        return async;
    }

    // ---------------------------------------------------------------- background

    /** Fills every slot that has no button and is not an input. */
    public Ui background(ItemStack icon) {
        this.background = Objects.requireNonNull(icon, "icon");
        return this;
    }

    /**
     * Spreads the items over the slots marked with the key, one page at a time. Navigation
     * buttons are up to you, using the returned {@link Pager}:
     *
     * <pre>{@code
     * Pager pager = ui.paginate('x', warps, warp -> Button.of(warp.icon(), c -> warp.teleport(c.player())));
     * if(pager.hasNext()) ui.put('>', NEXT_ICON, c -> pager.next());
     * }</pre>
     */
    public <T extends @Nullable Object> Pager paginate(char key, List<T> items, Function<T, Button> renderer) {
        return paginate("key:" + key, slots(key), items, renderer);
    }

    /**
     * Same as {@link #paginate(char, List, Function)} with explicit slots. The id keeps the page
     * of different pagers apart.
     */
    public <T extends @Nullable Object> Pager paginate(String id, List<Integer> slots, List<T> items,
                                                       Function<T, Button> renderer) {
        if(slots.isEmpty()) {
            throw new IllegalArgumentException("paginate needs at least one slot");
        }
        int perPage = slots.size();
        int pages = Math.max(1, (items.size() + perPage - 1) / perPage);
        Signal<Integer> page = state(POSITION_PREFIX + "page:" + id, 0);
        int current = Math.clamp(page.get(), 0, pages - 1);
        for(int i = 0; i < perPage; i++) {
            int index = current * perPage + i;
            if(index >= items.size()) {
                break;
            }
            put(slots.get(i), renderer.apply(items.get(index)));
        }
        return new Pager(page, pages, current);
    }

    /**
     * Shows the items in the slots marked with the key, a row at a time: a list that scrolls
     * instead of turning pages. The slots must form a rectangle, whose width is the number of
     * items per row. Scroll buttons are up to you, using the returned {@link Scroller}:
     *
     * <pre>{@code
     * ui.layout(
     *     "xxxxxxx ^",
     *     "xxxxxxx  ",
     *     "xxxxxxx v");
     * Scroller s = ui.scroll('x', items, item -> Button.of(item.icon()));
     * if(s.canUp())   ui.put('^', UP,   c -> s.up());
     * if(s.canDown()) ui.put('v', DOWN, c -> s.down());
     * }</pre>
     */
    public <T extends @Nullable Object> Scroller scroll(char key, List<T> items, Function<T, Button> renderer) {
        return scroll("key:" + key, slots(key), items, renderer);
    }

    /**
     * Same as {@link #scroll(char, List, Function)} with explicit slots, which must form a
     * rectangle. The id keeps the position of different scrollers apart.
     */
    public <T extends @Nullable Object> Scroller scroll(String id, List<Integer> slots, List<T> items,
                                                        Function<T, Button> renderer) {
        if(slots.isEmpty()) {
            throw new IllegalArgumentException("scroll needs at least one slot");
        }
        int top = Integer.MAX_VALUE, left = Integer.MAX_VALUE, bottom = -1, right = -1;
        for(int slot : slots) {
            checkSlot(slot);
            top = Math.min(top, slot / COLUMNS);
            bottom = Math.max(bottom, slot / COLUMNS);
            left = Math.min(left, slot % COLUMNS);
            right = Math.max(right, slot % COLUMNS);
        }
        int width = right - left + 1;
        int height = bottom - top + 1;
        if(width * height != slots.size() || slots.stream().distinct().count() != slots.size()) {
            throw new IllegalArgumentException("scroll slots must form a rectangle, got " + slots);
        }
        int totalRows = (items.size() + width - 1) / width;
        int maxRow = Math.max(0, totalRows - height);
        Signal<Integer> row = state(POSITION_PREFIX + "scroll:" + id, 0);
        int current = Math.clamp(row.get(), 0, maxRow);
        for(int r = 0; r < height; r++) {
            for(int c = 0; c < width; c++) {
                int index = (current + r) * width + c;
                if(index >= items.size()) {
                    break;
                }
                put(slot(top + r, left + c), renderer.apply(items.get(index)));
            }
        }
        return new Scroller(row, current, maxRow, height);
    }

    /** A search box for this view; see {@link Search}. */
    public Search search() {
        return search("default");
    }

    /** A separate search box when the menu has more than one. */
    public Search search(String id) {
        return search(id, "");
    }

    /**
     * A search box that starts with a query, e.g. from a command argument ({@code /warps spawn}).
     * The initial query only applies when the view is first rendered.
     */
    public Search search(String id, String initialQuery) {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(initialQuery, "initialQuery");
        return new Search(view, state("loom:search:" + id, initialQuery.strip()), view.searchCache(id));
    }

    // ---------------------------------------------------------------- state

    /**
     * State private to this viewer, kept across redraws. Matched by call order, like hooks:
     * call {@code state} unconditionally and in the same order on every render, or use
     * {@link #state(String, Object)}.
     */
    public <T extends @Nullable Object> Signal<T> state(T initial) {
        return view.state(stateIndex++, initial);
    }

    /** State private to this viewer, identified by a key instead of call order. */
    public <T extends @Nullable Object> Signal<T> state(String key, T initial) {
        return view.state(key, initial);
    }

    // ---------------------------------------------------------------- time

    /** Redraws the menu every {@code ticks} ticks, for clocks, cooldowns and live data. */
    public Ui every(int ticks) {
        if(ticks < 1) {
            throw new IllegalArgumentException("ticks must be >= 1");
        }
        refresh = refresh == 0 ? ticks : Math.min(refresh, ticks);
        return this;
    }

    /** Ticks since this view was first opened. */
    public long age() {
        return view.age();
    }

    /**
     * Animation helper: returns the frame to show now and schedules the redraws.
     *
     * <pre>{@code
     * ui.put(4, ui.cycle(10, RED_GLASS, ORANGE_GLASS, YELLOW_GLASS));
     * }</pre>
     */
    @SafeVarargs
    public final <T> T cycle(int ticksPerFrame, T... frames) {
        if(frames.length == 0) {
            throw new IllegalArgumentException("cycle needs at least one frame");
        }
        every(ticksPerFrame);
        return frames[(int) ((age() / ticksPerFrame) % frames.length)];
    }

    // ---------------------------------------------------------------- lifecycle

    /** Called once when this view stops being shown. */
    public Ui onClose(Consumer<Close> onClose) {
        this.onClose = Objects.requireNonNull(onClose, "onClose");
        return this;
    }

    /**
     * Called when the viewer clicks a slot of their own inventory while this menu is open, e.g.
     * "click an item in your inventory to sell it". {@link Click#slot()} is the slot in the
     * player's inventory and {@link Click#item()} the clicked item.
     *
     * <p>Whether the click itself moves items is decided by Loom's safety rules and
     * {@link Menu#lockPlayerInventory(boolean)}; cancel {@link Click#event()} to block it.</p>
     */
    public Ui onInventoryClick(ClickHandler onClick) {
        this.onInventoryClick = Objects.requireNonNull(onClick, "onClick");
        return this;
    }

    /**
     * True while a {@link Click#async} task of this menu runs. The menu redraws when it changes,
     * e.g. to show a "processing..." icon.
     */
    public boolean busy() {
        return view.busySignal().get();
    }

    /** True if a {@link Click#back()} would return to a previous menu. */
    public boolean canGoBack() {
        return view.previous() != null;
    }

    // ---------------------------------------------------------------- internal

    Frame finish() {
        int height = rows > 0 ? rows
                : layout != null ? layout.length
                : Math.max(1, highestSlot / COLUMNS + 1);
        if(layout != null && layout.length > height) {
            throw new IllegalArgumentException("layout has " + layout.length + " lines but the menu has " + height + " rows");
        }
        int size = height * COLUMNS;
        if(highestSlot >= size) {
            throw new IllegalArgumentException("slot " + highestSlot + " is outside of a " + height + "-row menu");
        }
        Button[] frameButtons = Arrays.copyOf(buttons, size);
        if(background != null) {
            Button filler = Button.of(background);
            for(int i = 0; i < size; i++) {
                if(frameButtons[i] == null && !inputs.containsKey(i)) {
                    frameButtons[i] = filler;
                }
            }
        }
        // sorted: shift-click fills inputs in slot order
        return new Frame(height, title, frameButtons, Collections.unmodifiableMap(new TreeMap<>(inputs)), onClose, onInventoryClick,
                refresh, stateIndex);
    }

    private void checkSlot(int slot) {
        if(slot < 0 || slot >= buttons.length) {
            throw new IllegalArgumentException("slot must be between 0 and 53, got " + slot);
        }
    }

    record Frame(int rows, Component title, @Nullable Button[] buttons, Map<Integer, Predicate<ItemStack>> inputs,
                 @Nullable Consumer<Close> onClose, @Nullable ClickHandler onInventoryClick, int refresh,
                 int stateCalls) {
    }
}
