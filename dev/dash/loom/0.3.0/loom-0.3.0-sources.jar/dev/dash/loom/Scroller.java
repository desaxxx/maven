package dev.dash.loom;

/**
 * Scroll control returned by {@link Ui#scroll}. The position is the first visible row of the
 * list; it is view state, so changing it redraws the menu and it survives {@link Click#back()}.
 */
public final class Scroller {

    private final Signal<Integer> row;
    private final int current;
    private final int maxRow;
    private final int visibleRows;

    Scroller(Signal<Integer> row, int current, int maxRow, int visibleRows) {
        this.row = row;
        this.current = current;
        this.maxRow = maxRow;
        this.visibleRows = visibleRows;
    }

    /** Zero-based index of the first visible row of the list. */
    public int row() {
        return current;
    }

    /** The highest value {@link #row()} can have; 0 if everything fits. */
    public int maxRow() {
        return maxRow;
    }

    /** How many rows of the list are shown at once. */
    public int visibleRows() {
        return visibleRows;
    }

    public boolean canUp() {
        return current > 0;
    }

    public boolean canDown() {
        return current < maxRow;
    }

    /** One row up. */
    public void up() {
        go(current - 1);
    }

    /** One row down. */
    public void down() {
        go(current + 1);
    }

    /** Up by the number of visible rows. */
    public void pageUp() {
        go(current - visibleRows);
    }

    /** Down by the number of visible rows. */
    public void pageDown() {
        go(current + visibleRows);
    }

    public void top() {
        go(0);
    }

    public void bottom() {
        go(maxRow);
    }

    /** Makes the given zero-based row the first visible one, clamped to the valid range. */
    public void go(int row) {
        this.row.set(Math.clamp(row, 0, maxRow));
    }

    @Override
    public String toString() {
        return "Scroller[" + current + "/" + maxRow + "]";
    }
}
