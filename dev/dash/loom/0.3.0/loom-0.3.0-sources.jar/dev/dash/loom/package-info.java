/**
 * Loom: reactive chest menus.
 *
 * <p>A menu is a render function. It describes what the menu looks like right now, and Loom
 * redraws it whenever a {@link dev.dash.loom.Signal} it read changes.</p>
 *
 * <pre>{@code
 * Loom.open(player, ui -> {
 *     Signal<Integer> clicks = ui.state(0);
 *     ui.title("<gold>Clicker");
 *     ui.put(13, Loom.item(Material.EMERALD, "<green>Clicks: " + clicks.get()),
 *            click -> clicks.update(n -> n + 1));
 * });
 * }</pre>
 */
@NullMarked
package dev.dash.loom;

import org.jspecify.annotations.NullMarked;
