package dev.yoshi.xconfig;

import java.util.function.Function;

/**
 * Converts between the raw YAML value and a custom Java type.
 *
 * <p>Built-in adapters (registered automatically by the library):
 * <ul>
 *   <li>{@code java.time.Duration} — "1h30m", "500ms", "2d" format</li>
 *   <li>{@code java.util.regex.Pattern} — raw regex text</li>
 *   <li>{@code net.kyori.adventure.text.format.TextColor} — "#RRGGBB"</li>
 *   <li>{@code net.kyori.adventure.text.Component} — MiniMessage markup (e.g. "{@code <green>Hello}")</li>
 * </ul>
 *
 * <p><b>Threads:</b> an adapter can be called from several threads at once:
 * {@link XConfig#update()} runs it on the caller's thread, and
 * {@link XConfig#find(ConfigKey)} (and {@link XConfig#get(ConfigKey)} for keys
 * not registered with the builder) runs it on the reader's thread, which on
 * Folia can be any region thread. Adapters must therefore be thread-safe
 * (stateless, or immutable state) and must not touch worlds, entities or
 * players. The built-in adapters meet both rules.
 */
public interface TypeAdapter<T> {

    /**
     * Converts the raw YAML value into the target type.
     *
     * @param raw  the YAML value (String, Integer, List, Map, ...)
     * @param path key path, used for error messages
     * @return the resolved value
     * @throws ConfigException if the value cannot be converted
     */
    T deserialize(Object raw, String path);

    /**
     * Produces the YAML representation of a value that is written to the file.
     */
    Object serialize(T value);

    /**
     * Creates an adapter from two lambdas.
     *
     * <pre>{@code
     * TypeAdapter<UUID> uuid = TypeAdapter.of(
     *         raw -> UUID.fromString(String.valueOf(raw)),
     *         UUID::toString);
     * }</pre>
     */
    static <T> TypeAdapter<T> of(Function<Object, T> deserializer, Function<T, Object> serializer) {
        return new TypeAdapter<>() {
            @Override
            public T deserialize(Object raw, String path) {
                return deserializer.apply(raw);
            }

            @Override
            public Object serialize(T value) {
                return serializer.apply(value);
            }
        };
    }
}
