package dev.yoshi.xconfig;

/**
 * Exception type thrown when a configuration value cannot be loaded or resolved.
 *
 * <p>When the failure belongs to a specific value, {@link #path()} carries the
 * YAML path it occurred at (e.g. {@code database.port}, {@code worlds[2]} or
 * {@code warps.spawn}), so callers can react programmatically instead of
 * parsing the message.
 */
public class ConfigException extends RuntimeException {

    private final String path;

    public ConfigException(String message) {
        this(message, (String) null);
    }

    public ConfigException(String message, Throwable cause) {
        this(message, null, cause);
    }

    /**
     * @param message human-readable failure description
     * @param path    YAML path the failure belongs to, or {@code null}
     */
    public ConfigException(String message, String path) {
        super(message);
        this.path = path;
    }

    /**
     * @param message human-readable failure description
     * @param path    YAML path the failure belongs to, or {@code null}
     * @param cause   underlying cause
     */
    public ConfigException(String message, String path, Throwable cause) {
        super(message, cause);
        this.path = path;
    }

    /** YAML path the failure belongs to, or {@code null} for file-level failures. */
    public String path() {
        return path;
    }
}
