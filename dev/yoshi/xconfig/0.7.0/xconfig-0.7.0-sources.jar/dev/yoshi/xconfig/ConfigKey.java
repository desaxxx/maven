package dev.yoshi.xconfig;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Predicate;

import dev.yoshi.xconfig.internal.ConfigPaths;
import dev.yoshi.xconfig.internal.Immutables;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;

/**
 * Immutable holder for all metadata of a configuration key:
 * path, type, default value, comments and an (optional) custom adapter.
 *
 * <p>Keys are typically declared as {@code public static final} fields in a
 * "key holder" class and picked up by {@link XConfigBuilder#keys(Class...)}:
 *
 * <pre>{@code
 * public final class Keys {
 *     public static final ConfigKey<String> HOST = ConfigKey.builder("database.host", String.class)
 *             .comment("Database address")
 *             .inlineComment("localhost or remote IP")
 *             .defaultValue("localhost")
 *             .build();
 *
 *     public static final ConfigKey<Duration> TIMEOUT = ConfigKey.builder("database.timeout", Duration.class)
 *             .comment("Connection timeout", "Format: 30s, 5m, 1h")
 *             .defaultValue(Duration.ofSeconds(10))
 *             .build();
 * }
 * }</pre>
 *
 * @param <T> the value type this key represents
 */
public final class ConfigKey<T> {

    private final String path;
    private final TypeToken<T> type;
    private final T defaultValue;
    private final TypeAdapter<T> adapter;
    private final ElementMapping<?> elementMapping;
    private final List<String> comments;
    private final String inlineComment;
    private final Predicate<T> validator;
    private final String validationMessage;
    private final List<String> aliases;
    private final Boolean strict;

    @SuppressWarnings("unchecked")
    private ConfigKey(Builder<T> builder) {
        this.path = builder.path;
        this.type = builder.type;
        // Collection defaults are copied deeply and unmodifiably: the default is
        // handed out by get(), so a caller mutating it must not corrupt it.
        this.defaultValue = (T) Immutables.deepCopy(builder.defaultValue);
        this.adapter = builder.adapter;
        this.elementMapping = builder.elementMapping;
        this.comments = Collections.unmodifiableList(new ArrayList<>(builder.comments));
        this.inlineComment = builder.inlineComment;
        this.validator = builder.validator;
        this.validationMessage = builder.validationMessage;
        this.aliases = List.copyOf(builder.aliases);
        this.strict = builder.strict;
    }

    /**
     * Key builder for raw (non-generic) types.
     */
    public static <T> Builder<T> builder(String path, Class<T> type) {
        return builder(path, TypeToken.of(type));
    }

    /**
     * Key builder for generic types.
     *
     * <pre>{@code
     * ConfigKey.builder("worlds", new TypeToken<List<String>>() {})
     * }</pre>
     */
    public static <T> Builder<T> builder(String path, TypeToken<T> type) {
        Objects.requireNonNull(path, "path must not be null");
        Objects.requireNonNull(type, "type must not be null");
        return new Builder<>(ConfigPaths.requireValid(path, "path"), type);
    }

    /**
     * Convenience builder for MiniMessage keys: the default value is given as
     * markup (e.g. {@code "<green>Hello"}) and parsed into a {@link Component}.
     * Deserialization itself is handled by the built-in global adapter.
     *
     * <pre>{@code
     * ConfigKey<Component> welcome = ConfigKey.miniMessage("messages.welcome", "<green>Hi <name>")
     *         .comment("Shown on join")
     *         .build();
     * }</pre>
     */
    public static Builder<Component> miniMessage(String path, String defaultMarkup) {
        Objects.requireNonNull(defaultMarkup, "defaultMarkup must not be null");
        return ConfigKey.<Component>builder(path, Component.class)
                .defaultValue(MiniMessage.miniMessage().deserialize(defaultMarkup));
    }

    /**
     * Convenience builder for {@code List<Component>} keys: every default entry
     * is MiniMessage markup and parsed into a {@link Component}.
     *
     * <pre>{@code
     * ConfigKey<List<Component>> motd = ConfigKey.miniMessageList("motd", "<red>Line 1", "<blue>Line 2")
     *         .build();
     * }</pre>
     */
    public static Builder<List<Component>> miniMessageList(String path, String... defaultMarkup) {
        List<Component> defaults = new ArrayList<>(defaultMarkup.length);
        for (String markup : defaultMarkup) {
            Objects.requireNonNull(markup, "defaultMarkup entries must not be null");
            defaults.add(MiniMessage.miniMessage().deserialize(markup));
        }
        return ConfigKey.<List<Component>>builder(path, new TypeToken<>() {})
                .defaultValue(List.copyOf(defaults));
    }

    /**
     * Convenience builder for "element map" keys: a YAML section whose children
     * are same-typed, user-manageable elements, read into a
     * {@code Map<String, E>} of Java objects through the element adapter. Users
     * may delete or add elements freely; every entry (known or not) resolves
     * through the same adapter.
     *
     * <p>Default completion is section-wide: the defaults are written only
     * while the whole section is absent from the file. Individually deleted
     * elements therefore stay deleted, and missing fields inside a kept element
     * fall back to whatever the element adapter substitutes. Deleting the whole
     * section restores all default elements.
     *
     * <pre>{@code
     * public static final ConfigKey<Map<String, Warp>> WARPS =
     *         ConfigKey.elementMap("warps", Warp.class, Warp.ADAPTER)
     *                 .comment("Warps")
     *                 .defaultValue(defaultWarps())
     *                 .build();
     *
     * Warp spawn = config.get(WARPS).get("spawn"); // null when the user deleted it
     * }</pre>
     */
    public static <E> Builder<Map<String, E>> elementMap(String path, Class<E> elementType,
                                                         TypeAdapter<E> elementAdapter) {
        Objects.requireNonNull(path, "path must not be null");
        Objects.requireNonNull(elementType, "elementType must not be null");
        Objects.requireNonNull(elementAdapter, "elementAdapter must not be null");
        ConfigPaths.requireValid(path, "path");
        return new Builder<>(path, TypeToken.mapOf(elementType), new ElementMapping<>(elementType, elementAdapter));
    }

    /**
     * Same as {@link #elementMap(String, Class, TypeAdapter)} for list-shaped
     * sections: a YAML array whose entries resolve through the element adapter
     * into {@code List<E>}.
     */
    public static <E> Builder<List<E>> elementList(String path, Class<E> elementType,
                                                   TypeAdapter<E> elementAdapter) {
        Objects.requireNonNull(path, "path must not be null");
        Objects.requireNonNull(elementType, "elementType must not be null");
        Objects.requireNonNull(elementAdapter, "elementAdapter must not be null");
        ConfigPaths.requireValid(path, "path");
        return new Builder<>(path, TypeToken.listOf(elementType), new ElementMapping<>(elementType, elementAdapter));
    }

    /**
     * Binds an element type to its adapter for {@link #elementMap} and
     * {@link #elementList} keys. The adapter applies to every element of the
     * section/array, overriding any globally registered adapter for the type.
     *
     * @param <E> the element type
     */
    public record ElementMapping<E>(Class<E> type, TypeAdapter<E> adapter) {
    }

    /** Full path in the YAML file (dot-separated section path). */
    public String path() {
        return path;
    }

    /** Type token of the key's value. */
    public TypeToken<T> type() {
        return type;
    }

    /**
     * Value used when the file has none or the value cannot be resolved (may be null).
     * {@code List}/{@code Set}/{@code Map} defaults are stored as unmodifiable deep copies.
     */
    public T defaultValue() {
        return defaultValue;
    }

    /** Key-specific adapter overriding any globally registered one, or null. */
    public TypeAdapter<T> adapter() {
        return adapter;
    }

    /** Element mapping of an {@link #elementMap}/{@link #elementList} key, or null. */
    public ElementMapping<?> elementMapping() {
        return elementMapping;
    }

    /**
     * Comment lines written above the key (rendered with a leading "#").
     * Per Bukkit's comment contract, a {@code null} entry renders as an empty
     * line and an empty string renders as a bare "#" line.
     */
    public List<String> comments() {
        return comments;
    }

    /** Comment written at the end of the value line, or null. */
    public String inlineComment() {
        return inlineComment;
    }

    /** Validator predicate every value must pass, or null when unset. */
    public Predicate<T> validator() {
        return validator;
    }

    /** Tests a value against this key's validator; always passes when no validator is set. */
    public boolean isValid(T value) {
        return validator == null || validator.test(value);
    }

    /** Human-readable failure message for a value rejected by the validator. */
    public String validationMessage(T value) {
        if (validationMessage != null) {
            return "'" + value + "' failed validation at '" + path + "': " + validationMessage;
        }
        return "'" + value + "' failed validation at '" + path + "'";
    }

    /**
     * Legacy paths this key used to live at. When a legacy path is found in the
     * file during a reload, its value is moved to {@link #path()} and the legacy
     * entry is removed. Old comments are not carried over — the key's own
     * comments are written instead, and a backup of the original file is taken
     * before any modification.
     */
    public List<String> aliases() {
        return aliases;
    }

    /**
     * Key-level strict mode override: {@code TRUE}/{@code FALSE} when set with
     * {@link Builder#strict(boolean)}, or null to follow the configuration's
     * own setting ({@link XConfigBuilder#strict()}).
     */
    public Boolean strict() {
        return strict;
    }

    /** Effective strict mode for this key: its own override, else the configuration's setting. */
    public boolean isStrict(boolean configStrict) {
        return strict != null ? strict : configStrict;
    }

    @Override
    public String toString() {
        return "ConfigKey['" + path + "' : " + type + "]";
    }

    /**
     * Fluent key builder; the chain must be closed with {@link #build()}.
     */
    public static final class Builder<T> {

        private final String path;
        private final TypeToken<T> type;
        private final List<String> comments = new ArrayList<>();
        private final List<String> aliases = new ArrayList<>();
        private final ElementMapping<?> elementMapping;
        private T defaultValue;
        private TypeAdapter<T> adapter;
        private String inlineComment;
        private Predicate<T> validator;
        private String validationMessage;
        private Boolean strict;

        private Builder(String path, TypeToken<T> type) {
            this(path, type, null);
        }

        private Builder(String path, TypeToken<T> type, ElementMapping<?> elementMapping) {
            this.path = path;
            this.type = type;
            this.elementMapping = elementMapping;
        }

        /** Default value used when the file contains none. */
        public Builder<T> defaultValue(T value) {
            this.defaultValue = value;
            return this;
        }

        /** Type adapter specific to this key (instead of the global registry). */
        public Builder<T> adapter(TypeAdapter<T> adapter) {
            this.adapter = Objects.requireNonNull(adapter, "adapter must not be null");
            return this;
        }

        /**
         * Comment lines written above the key; multiple calls accumulate and
         * keep their call order. An empty string renders as a bare "#" line.
         * Use {@link #blankLine()} for empty lines.
         */
        public Builder<T> comment(String... lines) {
            comments.addAll(Arrays.asList(lines));
            return this;
        }

        /**
         * Writes an empty line above this key when the file is generated;
         * multiple calls stack, and the line is emitted at the position the
         * call appears in the chain. Typically combined with comments to group
         * sections visually:
         *
         * <pre>{@code
         * ConfigKey.builder("worlds", ...)
         *         .blankLine()
         *         .comment("Etkin dünyalar")
         *         .build();
         * }</pre>
         */
        public Builder<T> blankLine() {
            comments.add(null);
            return this;
        }

        /** Single comment written at the end of the value line. */
        public Builder<T> inlineComment(String line) {
            this.inlineComment = Objects.requireNonNull(line, "inlineComment must not be null");
            return this;
        }

        /**
         * Adds a validator that every value — including the default — must pass.
         * A file value failing validation behaves like an unresolvable one:
         * strict mode throws, otherwise the default is used with a warning.
         */
        public Builder<T> validate(Predicate<T> validator) {
            return validate(validator, null);
        }

        /** Same as {@link #validate(Predicate)} with a custom failure message. */
        public Builder<T> validate(Predicate<T> validator, String failureMessage) {
            this.validator = Objects.requireNonNull(validator, "validator must not be null");
            this.validationMessage = failureMessage;
            return this;
        }

        /**
         * Declares a legacy path this key used to live at; the value is
         * auto-migrated on load/update. Multiple calls accumulate (one per
         * historical rename).
         */
        public Builder<T> alias(String oldPath) {
            Objects.requireNonNull(oldPath, "oldPath must not be null");
            ConfigPaths.requireValid(oldPath, "alias");
            if (oldPath.equals(path)) {
                throw new IllegalArgumentException("alias must differ from the key path: " + oldPath);
            }
            aliases.add(oldPath);
            return this;
        }

        /** Shorthand for {@link #strict(boolean) strict(true)}. */
        public Builder<T> strict() {
            return strict(true);
        }

        /**
         * Overrides the configuration's strict mode for this key only.
         * {@code true}: an unresolvable or invalid value throws
         * {@link ConfigException}, even in a lenient configuration.
         * {@code false}: the value falls back leniently (default with a warning;
         * broken elements of an element map/list are skipped), even in a strict
         * configuration. Unset keys follow {@link XConfigBuilder#strict()}.
         */
        public Builder<T> strict(boolean strict) {
            this.strict = strict;
            return this;
        }

        public ConfigKey<T> build() {
            ConfigKey<T> key = new ConfigKey<>(this);
            if (defaultValue != null && !key.isValid(defaultValue)) {
                // A default that fails its own validator is a programming error; fail fast.
                throw new ConfigException(
                        "ConfigKey '" + path + "' has a default value that fails validation: " + defaultValue
                                + (validationMessage != null ? " (" + validationMessage + ")" : ""));
            }
            return key;
        }
    }
}
