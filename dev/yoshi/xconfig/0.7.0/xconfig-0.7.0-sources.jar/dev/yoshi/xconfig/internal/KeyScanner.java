package dev.yoshi.xconfig.internal;

import dev.yoshi.xconfig.ConfigKey;
import dev.yoshi.xconfig.ConfigSection;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;

/**
 * Collects the {@code static} {@link ConfigKey} and {@link ConfigSection}
 * fields of a class via reflection. Field order may vary between JVM
 * implementations; use {@link dev.yoshi.xconfig.XConfigBuilder#keys(ConfigKey...)}
 * if the file order must be guaranteed.
 */
public final class KeyScanner {

    private KeyScanner() {
    }

    public static List<ConfigKey<?>> scan(Class<?> holder) {
        List<ConfigKey<?>> keys = new ArrayList<>();
        for (Field field : holder.getDeclaredFields()) {
            if (!Modifier.isStatic(field.getModifiers())) {
                continue;
            }
            if (!ConfigKey.class.isAssignableFrom(field.getType())) {
                continue;
            }
            if (!field.trySetAccessible()) {
                continue;
            }
            try {
                if (field.get(null) instanceof ConfigKey<?> key) {
                    keys.add(key);
                }
            } catch (IllegalAccessException ignored) {
                // Inaccessible fields are skipped.
            }
        }
        return keys;
    }

    /** Same as {@link #scan(Class)} for {@code static} {@link ConfigSection} fields. */
    public static List<ConfigSection> scanSections(Class<?> holder) {
        List<ConfigSection> sections = new ArrayList<>();
        for (Field field : holder.getDeclaredFields()) {
            if (!Modifier.isStatic(field.getModifiers())) {
                continue;
            }
            if (!ConfigSection.class.isAssignableFrom(field.getType())) {
                continue;
            }
            if (!field.trySetAccessible()) {
                continue;
            }
            try {
                if (field.get(null) instanceof ConfigSection section) {
                    sections.add(section);
                }
            } catch (IllegalAccessException ignored) {
                // Inaccessible fields are skipped.
            }
        }
        return sections;
    }
}
