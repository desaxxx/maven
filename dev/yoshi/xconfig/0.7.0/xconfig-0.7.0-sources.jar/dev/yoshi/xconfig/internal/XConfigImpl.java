package dev.yoshi.xconfig.internal;

import dev.yoshi.xconfig.ConfigException;
import dev.yoshi.xconfig.ConfigKey;
import dev.yoshi.xconfig.ConfigSection;
import dev.yoshi.xconfig.TypeAdapter;
import dev.yoshi.xconfig.WritableXConfig;
import dev.yoshi.xconfig.XConfig;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AccessDeniedException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.logging.Logger;

/**
 * {@link XConfig} implementation. Every {@link #update()} builds a new snapshot
 * and atomically publishes it through a {@code volatile} field; concurrent
 * {@link #get(ConfigKey)} calls always read one consistent snapshot.
 *
 * <p>Reload pipeline: load file → take migration backup → run version
 * migrations → move key aliases → complete missing keys → save → resolve.
 * Reloads are serialized (one at a time) and saves are atomic: the new
 * content is written to a temporary sibling file and moved over the original,
 * so a crash mid-write never leaves a truncated configuration behind.
 *
 * <p>{@link #set(ConfigKey, Object)} runs the same pipeline under the same
 * lock, with the value written in after the alias moves; it is refused unless
 * the configuration was built writable.
 */
public final class XConfigImpl implements WritableXConfig {

    /** Mask for "null value", since ConcurrentHashMap cannot hold nulls. */
    private static final Object NULL = new Object();

    /** Reserved root key managed by the library when a version is declared. */
    public static final String CONFIG_VERSION_PATH = "config-version";
    private static final String CONFIG_VERSION_COMMENT = "Configuration version - do not edit.";

    private record Snapshot(YamlConfiguration yaml, ConcurrentHashMap<ConfigKey<?>, Object> values) {
    }

    private final Path file;
    private final List<ConfigKey<?>> declaredKeys;
    private final List<ConfigSection> declaredSections;
    private final Map<Class<?>, TypeAdapter<?>> adapters;
    private final boolean strict;
    private final boolean completeMissing;
    private final Integer declaredVersion;
    private final List<MigrationStep> migrationSteps;
    private final Logger logger;

    private volatile Snapshot snapshot;

    private final boolean writable;

    /** Serializes reloads and sets: two concurrent update()/set() calls must not both rewrite the file. */
    private final Object reloadLock = new Object();

    public XConfigImpl(Path file, List<ConfigKey<?>> declaredKeys, List<ConfigSection> declaredSections,
                       Map<Class<?>, TypeAdapter<?>> adapters, boolean strict, boolean completeMissing,
                       Integer declaredVersion, List<MigrationStep> migrationSteps, Logger logger,
                       boolean writable) {
        this.file = file;
        this.declaredKeys = declaredKeys;
        this.declaredSections = declaredSections;
        this.adapters = adapters;
        this.strict = strict;
        this.completeMissing = completeMissing;
        this.declaredVersion = declaredVersion;
        this.migrationSteps = migrationSteps;
        this.logger = logger;
        this.writable = writable;
        if (!migrationSteps.isEmpty() && declaredVersion == null) {
            logger.warning("[xconfig] migration steps were declared without version(...); they are skipped. "
                    + "Declare the current schema version to enable migrations.");
        }
        synchronized (reloadLock) {
            this.snapshot = reload(null);
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T> T get(ConfigKey<T> key) {
        Snapshot current = snapshot;
        Object value = current.values().get(key);
        if (value == NULL) {
            return null;
        }
        if (value != null) {
            return (T) value;
        }
        // The key may not be registered with the builder; resolve it from the
        // file on the fly and cache it.
        if (!current.yaml().contains(key.path())) {
            return key.defaultValue();
        }
        Object masked = mask(resolveOrLog(key, current.yaml().get(key.path())), key);
        Object cached = current.values().putIfAbsent(key, masked);
        return (T) unmask(cached != null ? cached : masked);
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T> Optional<T> find(ConfigKey<T> key) {
        Snapshot current = snapshot;
        if (!current.yaml().contains(key.path())) {
            return Optional.empty();
        }
        Object raw = current.yaml().get(key.path());
        if (raw == null) {
            return Optional.empty(); // an empty "key:" value counts as absent
        }
        try {
            return Optional.ofNullable((T) resolveChecked(key, raw));
        } catch (RuntimeException exception) {
            if (key.isStrict(strict)) {
                throw asConfigException(key, exception);
            }
            // A present-but-unresolvable value is reported as absent, never as the default.
            logger.warning(() -> "[xconfig] Failed to resolve value at path: " + key.path() + ", treating it as absent. "
                    + exception.getMessage());
            return Optional.empty();
        }
    }

    @Override
    public void update() {
        synchronized (reloadLock) {
            this.snapshot = reload(null);
        }
    }

    @Override
    public <T> void set(ConfigKey<T> key, T value) {
        Objects.requireNonNull(key, "key must not be null");
        if (!writable) {
            throw new UnsupportedOperationException(
                    "This configuration is read-only; create it with XConfigBuilder.buildWritable() to set values");
        }
        // Only registered keys passed build()'s conflict checks; an unregistered one
        // could overwrite another key's section or the reserved config-version path.
        if (!isRegistered(key)) {
            throw new IllegalArgumentException("Key is not registered with this configuration: " + key.path()
                    + " (register it with XConfigBuilder.keys(...) to set it)");
        }
        if (value == null) {
            throw new ConfigException("Cannot set a null value at path: " + key.path(), key.path());
        }
        if (!key.isValid(value)) {
            throw validationFailure(key, value);
        }
        Object serialized;
        try {
            serialized = serialize(key, value, adapters);
        } catch (RuntimeException exception) {
            throw new ConfigException("Failed to serialize value for path: " + key.path(), key.path(), exception);
        }
        synchronized (reloadLock) {
            this.snapshot = reload(new PendingSet(key, serialized));
        }
    }

    private boolean isRegistered(ConfigKey<?> key) {
        for (ConfigKey<?> declared : declaredKeys) {
            if (declared == key) {
                return true;
            }
        }
        return false;
    }

    /** A value written by set(...): the key and its YAML-writable form. */
    private record PendingSet(ConfigKey<?> key, Object serialized) {
    }

    @Override
    public Path file() {
        return file;
    }

    @Override
    public List<ConfigKey<?>> keys() {
        return declaredKeys;
    }

    /** @param pendingSet value to write in, or {@code null} for a plain reload */
    private Snapshot reload(PendingSet pendingSet) {
        YamlConfiguration yaml = new YamlConfiguration();
        boolean fileExists = Files.exists(file);
        // Saving is refused while Bukkit has dropped values (see DroppedValues):
        // writing the loaded configuration back would erase them from the file.
        boolean saveBlocked = false;
        if (fileExists) {
            String content;
            try {
                // Read once and parse that text, so the dropped-value check sees exactly what Bukkit loaded.
                // new String(bytes) replaces malformed UTF-8 like Bukkit's load(File) does (Files.readString would throw).
                content = new String(Files.readAllBytes(file), StandardCharsets.UTF_8);
                yaml.loadFromString(content);
            } catch (IOException | InvalidConfigurationException exception) {
                throw new ConfigException("Failed to read configuration file: " + file, exception);
            }
            saveBlocked = checkDroppedValues(content, yaml);
            if (saveBlocked && pendingSet != null) {
                // Saving the value would erase the dropped one; nothing is written or published.
                throw new ConfigException("Cannot set the value at path: " + pendingSet.key().path() + ": "
                        + file.getFileName() + " holds a value Bukkit could not load (see the warning above),"
                        + " and saving now would erase it", pendingSet.key().path());
            }
        }

        // With completion disabled an absent file is never created or written to;
        // there is also nothing to migrate, so everything is skipped. An explicit
        // set(...) still creates it, holding only the set value.
        if (!fileExists && !completeMissing && pendingSet == null) {
            return new Snapshot(yaml, new ConcurrentHashMap<>());
        }

        if (!fileExists) {
            try {
                Path parent = file.toAbsolutePath().getParent();
                if (parent != null) {
                    Files.createDirectories(parent);
                }
            } catch (IOException exception) {
                throw new ConfigException("Failed to create configuration directory: " + file, exception);
            }
        }

        int fileVersion = fileExists ? yaml.getInt(CONFIG_VERSION_PATH, 0) : 0;
        // A brand-new file is generated at the current schema directly: there is
        // nothing to migrate, so steps (notably run(...) hooks) must not touch it.
        // The config-version key is written by the completion step below.
        boolean versionJump = fileExists && declaredVersion != null && fileVersion < declaredVersion;
        if (fileExists && declaredVersion != null && fileVersion > declaredVersion) {
            logger.warning(() -> "[xconfig] " + file.getFileName() + " has config-version " + fileVersion
                    + " but this build only knows version " + declaredVersion
                    + " (plugin downgrade?). The file is loaded as is; newer settings may be ignored.");
        }
        boolean aliasPending = fileExists && aliasesPending(yaml);

        // One raw byte-copy of the original file before anything destructive
        // (migrations and alias moves both drop old entries/comments).
        if ((versionJump || aliasPending) && !saveBlocked) {
            createMigrationBackup(versionJump);
        }

        boolean dirty = false;

        if (versionJump) {
            // Chain steps in ascending order: a v1 file migrating to v3 runs the
            // v2 step first, then the v3 step.
            List<MigrationStep> applicable = migrationSteps.stream()
                    .filter(step -> step.toVersion() > fileVersion)
                    .sorted(Comparator.comparingInt(MigrationStep::toVersion))
                    .toList();
            for (MigrationStep step : applicable) {
                for (Consumer<YamlConfiguration> operation : step.ops()) {
                    operation.accept(yaml);
                }
            }
            yaml.set(CONFIG_VERSION_PATH, declaredVersion);
            yaml.setComments(CONFIG_VERSION_PATH, List.of(CONFIG_VERSION_COMMENT));
            dirty = true;
        }

        if (fileExists) {
            // Move legacy key paths to their current location. The key's own
            // comments replace the old ones (the backup keeps the originals).
            for (ConfigKey<?> key : declaredKeys) {
                for (String alias : key.aliases()) {
                    if (!yaml.contains(alias)) {
                        continue;
                    }
                    if (!yaml.contains(key.path())) {
                        yaml.set(key.path(), yaml.get(alias));
                        if (!key.comments().isEmpty()) {
                            yaml.setComments(key.path(), key.comments());
                        }
                        if (key.inlineComment() != null) {
                            yaml.setInlineComments(key.path(), List.of(key.inlineComment()));
                        }
                    }
                    MigrationImpl.removeEntry(yaml, alias);
                    dirty = true;
                }
            }
        }

        if (pendingSet != null) {
            ConfigKey<?> key = pendingSet.key();
            boolean wasPresent = yaml.contains(key.path());
            // Setting an existing path keeps its comments; a new path gets the key's own.
            yaml.set(key.path(), pendingSet.serialized());
            if (!wasPresent) {
                if (!key.comments().isEmpty()) {
                    yaml.setComments(key.path(), key.comments());
                }
                if (key.inlineComment() != null) {
                    yaml.setInlineComments(key.path(), List.of(key.inlineComment()));
                }
            }
            dirty = true;
        }

        if (completeMissing) {
            if (declaredVersion != null && !yaml.contains(CONFIG_VERSION_PATH)) {
                yaml.set(CONFIG_VERSION_PATH, declaredVersion);
                yaml.setComments(CONFIG_VERSION_PATH, List.of(CONFIG_VERSION_COMMENT));
                dirty = true;
            }

            // Complete missing keys with their default values and comments.
            for (ConfigKey<?> key : declaredKeys) {
                if (key.defaultValue() == null || yaml.contains(key.path())) {
                    continue;
                }
                Object serialized = serialize(key, key.defaultValue(), adapters);
                yaml.set(key.path(), serialized);
                if (!key.comments().isEmpty()) {
                    yaml.setComments(key.path(), key.comments());
                }
                if (key.inlineComment() != null) {
                    yaml.setInlineComments(key.path(), List.of(key.inlineComment()));
                }
                dirty = true;
            }

            // Section comments: written when the section exists and carries no
            // comments yet, so fresh files and files generated before the
            // declaration existed get the layout; a section holding the user's
            // own comments is never touched.
            for (ConfigSection section : declaredSections) {
                if (!yaml.isConfigurationSection(section.path())) {
                    if (!section.comments().isEmpty() || section.inlineComment() != null) {
                        logger.warning(() -> "[xconfig] Section '" + section.path()
                                + "' was not found in the file (no child keys?); its comments were skipped.");
                    }
                    continue;
                }
                if (!section.comments().isEmpty() && yaml.getComments(section.path()).isEmpty()) {
                    yaml.setComments(section.path(), section.comments());
                    dirty = true;
                }
                if (section.inlineComment() != null && yaml.getInlineComments(section.path()).isEmpty()) {
                    yaml.setInlineComments(section.path(), List.of(section.inlineComment()));
                    dirty = true;
                }
            }
        }

        // A blocked save still applies migrations, alias moves and defaults in
        // memory: values are served as usual, and the untouched file is migrated
        // and completed by the first reload that loads cleanly.
        if (dirty && !saveBlocked) {
            saveAtomically(yaml.saveToString());
        }

        ConcurrentHashMap<ConfigKey<?>, Object> values = new ConcurrentHashMap<>();
        for (ConfigKey<?> key : declaredKeys) {
            if (!yaml.contains(key.path())) {
                continue;
            }
            Object raw = yaml.get(key.path());
            Object resolved = raw == null ? null : resolveOrLog(key, raw);
            values.put(key, mask(resolved, key));
        }
        return new Snapshot(yaml, values);
    }

    /**
     * Writes the content to {@code <file>.tmp} and moves it over the original.
     * Falls back to a plain replacing move where the file system has no atomic
     * rename; the temporary file is removed if anything fails.
     *
     * <p>On Windows the replace is refused ({@link AccessDeniedException}) while
     * another process (antivirus, indexer, an editor) has the file open; that is
     * usually momentary, so it is retried a few times with a short back-off
     * before giving up. The original file is untouched by a refused replace.
     */
    private void saveAtomically(String content) {
        Path temp = file.resolveSibling(file.getFileName() + ".tmp");
        try {
            Files.writeString(temp, content, StandardCharsets.UTF_8);
            replaceWithRetry(temp);
        } catch (IOException exception) {
            try {
                Files.deleteIfExists(temp);
            } catch (IOException ignored) {
                // Best effort; the original file is untouched either way.
            }
            throw new ConfigException("Failed to write configuration file: " + file, exception);
        }
    }

    /**
     * Reports values Bukkit dropped while loading (a {@code ==:} object that
     * failed to deserialize, e.g. a Location in a world that is not loaded).
     * They are treated as absent; in strict mode (config or the owning key)
     * the reload fails instead.
     *
     * @return true if saving must be skipped for this reload
     */
    private boolean checkDroppedValues(String content, YamlConfiguration yaml) {
        List<String> dropped;
        try {
            dropped = DroppedValues.find(content, yaml);
        } catch (RuntimeException exception) {
            // Cannot tell what was dropped: keep the file untouched to be safe.
            logger.warning(() -> "[xconfig] Could not check " + file.getFileName() + " for values Bukkit failed to load ("
                    + exception + "); the file is not saved during this reload.");
            return true;
        }
        if (dropped.isEmpty()) {
            return false;
        }
        for (String path : dropped) {
            if (isStrictFor(path)) {
                throw new ConfigException("Bukkit could not load the value at path: " + path
                        + " (see the error logged above, e.g. a Location in a world that is not loaded)", path);
            }
        }
        logger.warning(() -> "[xconfig] " + file.getFileName() + ": Bukkit could not load the value(s) at " + dropped
                + " (see the error logged above, e.g. a Location in a world that is not loaded). They are treated as"
                + " absent, and the file is not saved during this reload so they are not lost; fix the cause and reload.");
        return true;
    }

    /** Strictness of the key a dropped path belongs to; the config's setting for paths no key owns. */
    private boolean isStrictFor(String path) {
        for (ConfigKey<?> key : declaredKeys) {
            String keyPath = key.path();
            if (path.equals(keyPath) || path.startsWith(keyPath + ".") || path.startsWith(keyPath + "[")) {
                return key.isStrict(strict);
            }
        }
        return strict;
    }

    /** Attempts for a replace refused with AccessDeniedException; back-off 25, 50, 100, 200 ms (375 ms in all). */
    static final int REPLACE_ATTEMPTS = 5;

    private void replaceWithRetry(Path temp) throws IOException {
        long backoffMillis = 25;
        for (int attempt = 1; ; attempt++) {
            try {
                try {
                    Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
                } catch (AtomicMoveNotSupportedException unsupported) {
                    Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING);
                }
                if (attempt > 1) {
                    int attempts = attempt;
                    logger.info(() -> "[xconfig] " + file.getFileName() + " was locked by another process; saved on attempt "
                            + attempts + ".");
                }
                return;
            } catch (AccessDeniedException denied) {
                if (attempt >= REPLACE_ATTEMPTS) {
                    throw denied;
                }
                try {
                    Thread.sleep(backoffMillis);
                } catch (InterruptedException interrupted) {
                    Thread.currentThread().interrupt();
                    throw denied;
                }
                backoffMillis *= 2;
            }
        }
    }

    /** True when at least one key alias is present in the file. */
    private boolean aliasesPending(YamlConfiguration yaml) {
        for (ConfigKey<?> key : declaredKeys) {
            for (String alias : key.aliases()) {
                if (yaml.contains(alias)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Copies the raw file bytes next to the original. A version transition
     * backs up to {@code <file>.before-migration-v<target>}; a plain alias
     * move (no version jump) to {@code <file>.before-alias-move}. An existing
     * backup of the same transition is replaced.
     */
    private void createMigrationBackup(boolean versionJump) {
        if (!Files.exists(file)) {
            return;
        }
        String suffix = versionJump
                ? ".before-migration-v" + declaredVersion
                : ".before-alias-move";
        Path backup = file.resolveSibling(file.getFileName() + suffix);
        try {
            Files.copy(file, backup, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException exception) {
            throw new ConfigException("Failed to create migration backup: " + backup, exception);
        }
    }

    /** Serializes a value of the key, preferring the key-specific adapter over the global registry. */
    @SuppressWarnings("unchecked")
    private static Object serialize(ConfigKey<?> key, Object value, Map<Class<?>, TypeAdapter<?>> adapters) {
        if (key.adapter() != null) {
            return ((TypeAdapter<Object>) key.adapter()).serialize(value);
        }
        if (key.elementMapping() != null) {
            // Element map/list value: elements go through the key's element adapter.
            return ValueWriter.write(value, ValueResolver.withElementAdapter(adapters, key.elementMapping()));
        }
        return ValueWriter.write(value, adapters);
    }

    private static Object mask(Object value, ConfigKey<?> key) {
        if (value != null) {
            return value;
        }
        return key.defaultValue() != null ? key.defaultValue() : NULL;
    }

    private static Object unmask(Object value) {
        return value == NULL ? null : value;
    }

    private Object resolveOrLog(ConfigKey<?> key, Object raw) {
        if (raw == null) {
            return null;
        }
        try {
            return resolveChecked(key, raw);
        } catch (RuntimeException exception) {
            if (key.isStrict(strict)) {
                throw asConfigException(key, exception);
            }
            logger.warning(() -> "[xconfig] Failed to resolve value at path: " + key.path() + ", using default. "
                    + exception.getMessage());
            return key.defaultValue();
        }
    }

    /** Resolves a raw value and applies the key's validator; throws on failure. */
    private Object resolveChecked(ConfigKey<?> key, Object raw) {
        // Outside strict mode (the key's override, else the configuration's) a broken
        // element of an element map/list is logged and skipped instead of
        // discarding the whole value.
        Object resolved = ValueResolver.resolve(key, adapters, raw, key.isStrict(strict) ? null : (elementPath, exception) ->
                logger.warning(() -> "[xconfig] Failed to resolve element at path: " + elementPath
                        + ", skipping it. " + exception.getMessage()));
        if (resolved != null && !isValid(key, resolved)) {
            throw validationFailure(key, resolved);
        }
        return resolved;
    }

    /** Wraps a resolution failure, making sure the result carries a path. */
    private ConfigException asConfigException(ConfigKey<?> key, RuntimeException exception) {
        if (exception instanceof ConfigException configException) {
            return configException.path() != null
                    ? configException
                    : new ConfigException(configException.getMessage(), key.path(), configException);
        }
        return new ConfigException("Failed to resolve value at path: " + key.path(), key.path(), exception);
    }

    /** Applies a key's validator without fighting the wildcard capture. */
    @SuppressWarnings("unchecked")
    private static boolean isValid(ConfigKey<?> key, Object value) {
        return ((ConfigKey<Object>) key).isValid(value);
    }

    @SuppressWarnings("unchecked")
    private static ConfigException validationFailure(ConfigKey<?> key, Object value) {
        return new ConfigException(((ConfigKey<Object>) key).validationMessage(value), key.path());
    }
}
