package dev.yoshi.xconfig.internal;

import dev.yoshi.xconfig.ConfigException;
import dev.yoshi.xconfig.ConfigKey;
import dev.yoshi.xconfig.TypeAdapter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
import org.bukkit.configuration.serialization.ConfigurationSerialization;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.BiConsumer;

/**
 * Converts a raw YAML value into the target Java type described by a key's
 * type information.
 *
 * <p>Every {@code List}/{@code Set}/{@code Map} produced here is unmodifiable:
 * resolved values live in the shared snapshot cache, so callers must not be
 * able to mutate them.
 */
public final class ValueResolver {

    private ValueResolver() {
    }

    /** Resolves a key's own value; the key-specific adapter takes precedence over everything. */
    public static Object resolve(ConfigKey<?> key, Map<Class<?>, TypeAdapter<?>> adapters, Object raw) {
        return resolve(key, adapters, raw, null);
    }

    /**
     * Resolves a key's own value. For element map/list keys a non-null
     * {@code elementErrors} handler makes resolution lenient per element: an
     * element that fails to resolve is reported to the handler (with its own
     * path, e.g. {@code warps.market}) and skipped, so one broken entry does not
     * discard the whole map/list. With a null handler any failure propagates.
     */
    public static Object resolve(ConfigKey<?> key, Map<Class<?>, TypeAdapter<?>> adapters, Object raw,
                                 BiConsumer<String, RuntimeException> elementErrors) {
        if (raw == null) {
            return null;
        }
        if (key.adapter() != null) {
            return Immutables.deepCopy(key.adapter().deserialize(plain(raw), key.path()));
        }
        if (key.elementMapping() != null) {
            // Element map/list key: the structure (Map/List) is resolved generically,
            // the key's element adapter applies to every element.
            Map<Class<?>, TypeAdapter<?>> merged = withElementAdapter(adapters, key.elementMapping());
            if (elementErrors != null) {
                Object lenient = resolveElementsLeniently(key, raw, merged, elementErrors);
                if (lenient != null) {
                    return lenient;
                }
            }
            return resolve(key.type().type(), raw, merged, key.path());
        }
        return resolve(key.type().type(), raw, adapters, key.path());
    }

    /**
     * Resolves each element of an element map/list on its own, skipping (and
     * reporting) the ones that fail. Returns null when the raw value does not
     * have the key's structure, leaving the error to the regular resolution.
     */
    private static Object resolveElementsLeniently(ConfigKey<?> key, Object raw,
                                                   Map<Class<?>, TypeAdapter<?>> adapters,
                                                   BiConsumer<String, RuntimeException> elementErrors) {
        if (raw instanceof ConfigurationSection section) {
            raw = section.getValues(false);
        }
        Class<?> target = rawClass(key.type().type());
        Class<?> elementType = key.elementMapping().type();
        if (raw instanceof Map<?, ?> map && target == Map.class) {
            Map<Object, Object> out = new LinkedHashMap<>();
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                String name = String.valueOf(entry.getKey());
                String elementPath = key.path() + "." + name;
                try {
                    out.put(name, resolve(elementType, entry.getValue(), adapters, elementPath));
                } catch (RuntimeException exception) {
                    elementErrors.accept(elementPath, exception);
                }
            }
            return Collections.unmodifiableMap(out);
        }
        if (raw instanceof List<?> list && target == List.class) {
            List<Object> out = new ArrayList<>(list.size());
            for (int i = 0; i < list.size(); i++) {
                String elementPath = key.path() + "[" + i + "]";
                try {
                    out.add(resolve(elementType, list.get(i), adapters, elementPath));
                } catch (RuntimeException exception) {
                    elementErrors.accept(elementPath, exception);
                }
            }
            return Collections.unmodifiableList(out);
        }
        return null;
    }

    /**
     * Registry view with a key's element adapter added on top; on a type
     * collision the element adapter wins, matching the key-specific-over-global rule.
     */
    public static Map<Class<?>, TypeAdapter<?>> withElementAdapter(Map<Class<?>, TypeAdapter<?>> adapters,
                                                                   ConfigKey.ElementMapping<?> element) {
        Map<Class<?>, TypeAdapter<?>> merged = new LinkedHashMap<>(adapters);
        merged.put(element.type(), element.adapter());
        return merged;
    }

    /**
     * Finds the adapter for a declared target type: an exact registration
     * first, otherwise the first registration (in registration order) for a
     * supertype of the target. Mirrors {@link ValueWriter}, which matches
     * values by assignability, so a type that can be written can also be read.
     */
    public static TypeAdapter<?> adapterFor(Class<?> target, Map<Class<?>, TypeAdapter<?>> adapters) {
        TypeAdapter<?> exact = adapters.get(target);
        if (exact != null) {
            return exact;
        }
        for (Map.Entry<Class<?>, TypeAdapter<?>> entry : adapters.entrySet()) {
            if (entry.getKey() != Object.class && entry.getKey().isAssignableFrom(target)) {
                return entry.getValue();
            }
        }
        return null;
    }

    /** Resolves a raw value against a type expression; recursive for list/map elements. */
    @SuppressWarnings("unchecked")
    public static Object resolve(Type type, Object raw, Map<Class<?>, TypeAdapter<?>> adapters, String path) {
        if (raw == null) {
            return null;
        }
        // Bukkit hands out nested sections as ConfigurationSection, not as a Map.
        if (raw instanceof ConfigurationSection section) {
            raw = section.getValues(false);
        }
        Class<?> target = rawClass(type);

        // 1) Adapter registry (active at every level, including list elements).
        if (target != null) {
            TypeAdapter<?> adapter = adapterFor(target, adapters);
            if (adapter != null) {
                Object value = adapter.deserialize(plain(raw), path);
                if (value != null && !boxed(target).isInstance(value)) {
                    throw new ConfigException("Adapter for " + target.getSimpleName() + " returned an incompatible "
                            + value.getClass().getSimpleName() + " at path: " + path, path);
                }
                return Immutables.deepCopy(value);
            }
        }

        // 2) Enum constants (case-insensitive).
        if (target != null && target.isEnum()) {
            String name = String.valueOf(raw).trim();
            for (Object constant : target.getEnumConstants()) {
                if (((Enum<?>) constant).name().equalsIgnoreCase(name)) {
                    return constant;
                }
            }
            throw new ConfigException(
                    "Unknown enum value '" + raw + "' (" + target.getSimpleName() + ") at path: " + path, path);
        }

        // 3) Bukkit ConfigurationSerializable (ItemStack, Location, ...) written by hand as a Map.
        if (target != null
                && ConfigurationSerializable.class.isAssignableFrom(target)
                && raw instanceof Map<?, ?> serializableMap) {
            return ConfigurationSerialization.deserializeObject((Map<String, Object>) plain(serializableMap));
        }

        // 4) List<E> and Set<E> — both are represented as YAML arrays.
        if (raw instanceof List<?> list && (target == List.class || target == Set.class)) {
            Type elementType = type instanceof ParameterizedType parameterized
                    ? parameterized.getActualTypeArguments()[0]
                    : Object.class;
            if (target == Set.class) {
                Set<Object> out = new LinkedHashSet<>();
                for (int i = 0; i < list.size(); i++) {
                    out.add(resolve(elementType, list.get(i), adapters, path + "[" + i + "]"));
                }
                return Collections.unmodifiableSet(out);
            }
            List<Object> out = new ArrayList<>(list.size());
            for (int i = 0; i < list.size(); i++) {
                out.add(resolve(elementType, list.get(i), adapters, path + "[" + i + "]"));
            }
            return Collections.unmodifiableList(out);
        }

        // 5) Map<K, V> — YAML keys are always text, so K is treated as String.
        if (raw instanceof Map<?, ?> map && target == Map.class) {
            Type valueType = type instanceof ParameterizedType parameterized
                    ? parameterized.getActualTypeArguments()[1]
                    : Object.class;
            Map<Object, Object> out = new LinkedHashMap<>();
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                String name = String.valueOf(entry.getKey());
                out.put(name, resolve(valueType, entry.getValue(), adapters, path + "." + name));
            }
            return Collections.unmodifiableMap(out);
        }

        // 6) Untyped reads (Object targets, e.g. Map<String, Object> values):
        //    nested sections become plain maps (never Bukkit's ConfigurationSection)
        //    and every collection is an unmodifiable copy, never the snapshot's own
        //    mutable YAML structure.
        if (target == Object.class) {
            return Immutables.deepCopy(plain(raw));
        }

        // 7) Number/boolean/text coercion (YAML may parse "5" as an Integer while the target is String, and vice versa).
        Object coerced = coerce(target, raw, path);
        if (coerced != NOT_COERCIBLE) {
            return coerced;
        }

        // 8) The value is already an instance of the target (a ConfigurationSerializable
        //    already deserialized by Bukkit also lands here).
        if (target != null && target.isInstance(raw)) {
            return Immutables.deepCopy(raw);
        }

        throw new ConfigException("Value '" + raw + "' could not be converted to "
                + (target != null ? target.getSimpleName() : type.getTypeName()) + " at path: " + path, path);
    }

    /**
     * Expands Bukkit's {@link ConfigurationSection}s (also when nested inside
     * maps or lists) into plain {@code Map}s, so adapters and callers only ever
     * see plain YAML structures.
     */
    private static Object plain(Object raw) {
        if (raw instanceof ConfigurationSection section) {
            raw = section.getValues(false);
        }
        if (raw instanceof Map<?, ?> map) {
            Map<Object, Object> out = new LinkedHashMap<>();
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                out.put(String.valueOf(entry.getKey()), plain(entry.getValue()));
            }
            return out;
        }
        if (raw instanceof List<?> list) {
            List<Object> out = new ArrayList<>(list.size());
            for (Object element : list) {
                out.add(plain(element));
            }
            return out;
        }
        return raw;
    }

    private static final Object NOT_COERCIBLE = new Object();

    private static Object coerce(Class<?> target, Object raw, String path) {
        if (target == String.class && (raw instanceof String || raw instanceof Number || raw instanceof Boolean)) {
            return raw.toString();
        }
        if (raw instanceof Number number) {
            if (target == Double.class || target == double.class) return number.doubleValue();
            if (target == Float.class || target == float.class) return number.floatValue();
            if (target == Integer.class || target == int.class) {
                return (int) exactIntegral(number, Integer.MIN_VALUE, Integer.MAX_VALUE, "Integer", path);
            }
            if (target == Long.class || target == long.class) {
                return exactIntegral(number, Long.MIN_VALUE, Long.MAX_VALUE, "Long", path);
            }
            if (target == Short.class || target == short.class) {
                return (short) exactIntegral(number, Short.MIN_VALUE, Short.MAX_VALUE, "Short", path);
            }
            if (target == Byte.class || target == byte.class) {
                return (byte) exactIntegral(number, Byte.MIN_VALUE, Byte.MAX_VALUE, "Byte", path);
            }
        }
        if (raw instanceof Boolean bool && (target == Boolean.class || target == boolean.class)) {
            return bool;
        }
        return NOT_COERCIBLE;
    }

    /**
     * Converts a number to an integral target without silent loss: a
     * fractional value ({@code 3.7}) or one outside the target's range
     * ({@code 5000000000} for an int) is rejected instead of being truncated
     * or wrapped around. Whole decimals such as {@code 3.0} are accepted.
     */
    private static long exactIntegral(Number number, long min, long max, String typeName, String path) {
        if (number instanceof Double d && (d.isNaN() || d.isInfinite())
                || number instanceof Float f && (f.isNaN() || f.isInfinite())) {
            throw new ConfigException("Value '" + number + "' is not a valid " + typeName + " at path: " + path, path);
        }
        BigDecimal decimal = new BigDecimal(number.toString());
        if (decimal.stripTrailingZeros().scale() > 0) {
            throw new ConfigException("Value '" + number + "' is not a whole number (expected "
                    + typeName + ") at path: " + path, path);
        }
        if (decimal.compareTo(BigDecimal.valueOf(min)) < 0 || decimal.compareTo(BigDecimal.valueOf(max)) > 0) {
            throw new ConfigException("Value '" + number + "' is out of range for " + typeName
                    + " (" + min + ".." + max + ") at path: " + path, path);
        }
        return decimal.longValueExact();
    }

    /** Wrapper class for primitives, so {@code isInstance} checks work for {@code int.class} too. */
    private static Class<?> boxed(Class<?> type) {
        if (!type.isPrimitive()) {
            return type;
        }
        if (type == int.class) return Integer.class;
        if (type == long.class) return Long.class;
        if (type == double.class) return Double.class;
        if (type == float.class) return Float.class;
        if (type == boolean.class) return Boolean.class;
        if (type == short.class) return Short.class;
        if (type == byte.class) return Byte.class;
        if (type == char.class) return Character.class;
        return Void.class;
    }

    private static Class<?> rawClass(Type type) {
        if (type instanceof Class<?> clazz) {
            return clazz;
        }
        if (type instanceof ParameterizedType parameterized) {
            return (Class<?>) parameterized.getRawType();
        }
        return null;
    }
}
