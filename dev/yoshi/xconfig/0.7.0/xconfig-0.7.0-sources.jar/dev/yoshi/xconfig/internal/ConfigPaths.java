package dev.yoshi.xconfig.internal;

import dev.yoshi.xconfig.ConfigKey;
import dev.yoshi.xconfig.ConfigSection;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Path syntax checks and registration-time conflict detection.
 */
public final class ConfigPaths {

    private ConfigPaths() {
    }

    /**
     * Validates a dot-separated YAML path: not blank, no leading/trailing dot,
     * no empty segment ({@code ".."}).
     *
     * @throws IllegalArgumentException if the path is malformed
     */
    public static String requireValid(String path, String what) {
        if (path.isBlank()) {
            throw new IllegalArgumentException(what + " must not be blank");
        }
        if (path.startsWith(".") || path.endsWith(".") || path.contains("..")) {
            throw new IllegalArgumentException(
                    what + " must not start/end with '.' or contain an empty segment ('..'): " + path);
        }
        return path;
    }

    /**
     * Drops repeated registrations of the very same key instance (e.g. a
     * holder class passed to {@code keys(...)} twice), keeping the first.
     */
    public static <T> List<T> distinctByIdentity(List<T> items) {
        Set<T> seen = Collections.newSetFromMap(new IdentityHashMap<>());
        List<T> out = new ArrayList<>(items.size());
        for (T item : items) {
            if (seen.add(item)) {
                out.add(item);
            }
        }
        return out;
    }

    /**
     * Rejects registrations that would silently fight over the same file
     * location:
     * <ul>
     *   <li>two different keys with the same path,</li>
     *   <li>a scalar/list key whose path is the parent of another key
     *       ({@code a} vs {@code a.b}: {@code a} cannot be a value and a
     *       section at once),</li>
     *   <li>a key alias that is another key's path,</li>
     *   <li>a section declared at or below a scalar/list key,</li>
     *   <li>a key at the reserved {@code config-version} path when versioning is on.</li>
     * </ul>
     * Map-shaped keys (raw {@code Map} reads, element maps, custom adapters,
     * serializable objects) may legitimately cover a section that also has
     * typed child keys, so they never conflict with their children.
     *
     * @throws IllegalStateException describing the first conflict found
     */
    public static void checkConflicts(List<ConfigKey<?>> keys, List<ConfigSection> sections,
                                      String reservedPath) {
        Map<String, ConfigKey<?>> byPath = new HashMap<>();
        for (ConfigKey<?> key : keys) {
            ConfigKey<?> previous = byPath.putIfAbsent(key.path(), key);
            if (previous != null) {
                throw new IllegalStateException("Duplicate key path '" + key.path() + "': " + previous + " and " + key);
            }
            if (key.path().equals(reservedPath)) {
                throw new IllegalStateException("Key path '" + reservedPath
                        + "' is reserved for the library-managed config version: " + key);
            }
        }
        for (ConfigKey<?> key : keys) {
            String parent = parentOf(key.path());
            while (parent != null) {
                ConfigKey<?> owner = byPath.get(parent);
                if (owner != null && isLeafValue(owner)) {
                    throw new IllegalStateException("Key " + owner + " cannot hold a value because key " + key
                            + " needs '" + parent + "' to be a section");
                }
                parent = parentOf(parent);
            }
            for (String alias : key.aliases()) {
                ConfigKey<?> owner = byPath.get(alias);
                if (owner != null) {
                    throw new IllegalStateException("Alias '" + alias + "' of " + key
                            + " is the path of another registered key: " + owner);
                }
            }
        }
        for (ConfigSection section : sections) {
            String path = section.path();
            while (path != null) {
                ConfigKey<?> owner = byPath.get(path);
                if (owner != null && isLeafValue(owner)) {
                    throw new IllegalStateException(section + " conflicts with value key " + owner
                            + " (a section cannot live at or below a value)");
                }
                path = parentOf(path);
            }
        }
    }

    /**
     * True when the key's value can only be a scalar or an array in YAML, so
     * its path can never double as a section.
     */
    private static boolean isLeafValue(ConfigKey<?> key) {
        if (key.adapter() != null || key.elementMapping() != null) {
            return false;
        }
        Class<?> type = key.type().rawType();
        return type == String.class
                || type == Boolean.class
                || type == Character.class
                || Number.class.isAssignableFrom(type)
                || type.isEnum()
                || Collection.class.isAssignableFrom(type);
    }

    private static String parentOf(String path) {
        int dot = path.lastIndexOf('.');
        return dot < 0 ? null : path.substring(0, dot);
    }
}
