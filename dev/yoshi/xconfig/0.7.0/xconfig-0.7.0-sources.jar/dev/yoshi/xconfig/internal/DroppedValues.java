package dev.yoshi.xconfig.internal;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.serialization.ConfigurationSerialization;
import org.yaml.snakeyaml.LoaderOptions;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.SafeConstructor;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Finds values Bukkit silently dropped while loading the file.
 *
 * <p>When a {@code ConfigurationSerializable} written with the {@code ==:} type
 * key (ItemStack, Location, ...) fails to deserialize, for example a
 * {@code Location} whose world is not loaded, Bukkit's
 * {@code ConfigurationSerialization} logs the error and returns {@code null}.
 * {@code YamlConfiguration} then stores that {@code null} with
 * {@code set(path, null)}, which removes the path, or keeps a {@code null}
 * element inside a list. Either way the value is gone from the loaded
 * configuration and saving it would erase it from the file for good.
 *
 * <p>This class parses the same text a second time with plain SnakeYAML (no
 * Bukkit object construction) and reports every {@code ==:} object that exists
 * in the text but has no counterpart in the loaded configuration.
 */
final class DroppedValues {

    private DroppedValues() {
    }

    /**
     * Returns the paths of dropped values ({@code test.spawn}, {@code items[2]}),
     * in file order; empty when nothing was dropped.
     *
     * @throws RuntimeException if the text cannot be parsed by plain SnakeYAML
     */
    static List<String> find(String content, ConfigurationSection loaded) {
        Object raw = rawLoader().load(content);
        List<String> dropped = new ArrayList<>();
        if (raw instanceof Map<?, ?> map) {
            walkSection(map, loaded, "", dropped);
        }
        return dropped;
    }

    /** Same limits Bukkit's YamlConfiguration loads with, so any file Bukkit accepted parses here too. */
    private static Yaml rawLoader() {
        LoaderOptions options = new LoaderOptions();
        options.setMaxAliasesForCollections(Integer.MAX_VALUE);
        options.setCodePointLimit(Integer.MAX_VALUE);
        options.setNestingDepthLimit(100);
        return new Yaml(new SafeConstructor(options));
    }

    private static void walkSection(Map<?, ?> raw, ConfigurationSection loaded, String prefix, List<String> dropped) {
        for (Map.Entry<?, ?> entry : raw.entrySet()) {
            String key = String.valueOf(entry.getKey());
            String path = prefix.isEmpty() ? key : prefix + "." + key;
            Object loadedValue = loaded.get(key);
            walkValue(entry.getValue(), loadedValue, path, dropped);
        }
    }

    private static void walkValue(Object raw, Object loaded, String path, List<String> dropped) {
        if (raw instanceof Map<?, ?> map) {
            if (map.containsKey(ConfigurationSerialization.SERIALIZED_TYPE_KEY)) {
                if (loaded == null) {
                    dropped.add(path);
                }
                return; // a constructed object: its own fields are Bukkit's business
            }
            if (loaded instanceof ConfigurationSection section) {
                walkSection(map, section, path, dropped);
            } else if (loaded instanceof Map<?, ?> loadedMap) {
                // Plain maps nested in lists stay maps after loading.
                for (Map.Entry<?, ?> entry : map.entrySet()) {
                    String key = String.valueOf(entry.getKey());
                    walkValue(entry.getValue(), loadedMap.get(entry.getKey()), path + "." + key, dropped);
                }
            } else if (loaded == null && containsSerialized(map)) {
                dropped.add(path);
            }
            return;
        }
        if (raw instanceof List<?> list) {
            List<?> loadedList = loaded instanceof List<?> l ? l : null;
            for (int i = 0; i < list.size(); i++) {
                Object loadedElement = loadedList != null && i < loadedList.size() ? loadedList.get(i) : null;
                walkValue(list.get(i), loadedElement, path + "[" + i + "]", dropped);
            }
        }
    }

    private static boolean containsSerialized(Object raw) {
        if (raw instanceof Map<?, ?> map) {
            if (map.containsKey(ConfigurationSerialization.SERIALIZED_TYPE_KEY)) {
                return true;
            }
            return map.values().stream().anyMatch(DroppedValues::containsSerialized);
        }
        if (raw instanceof List<?> list) {
            return list.stream().anyMatch(DroppedValues::containsSerialized);
        }
        return false;
    }
}
