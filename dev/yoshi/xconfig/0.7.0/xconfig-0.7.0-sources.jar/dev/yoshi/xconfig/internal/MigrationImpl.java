package dev.yoshi.xconfig.internal;

import dev.yoshi.xconfig.Migration;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;

/**
 * Collects the operations of one migration step declared through
 * {@link dev.yoshi.xconfig.XConfigBuilder#migration(int, Consumer)}.
 */
public final class MigrationImpl implements Migration {

    private final List<Consumer<YamlConfiguration>> ops = new ArrayList<>();

    @Override
    public Migration move(String from, String to) {
        Objects.requireNonNull(from, "from must not be null");
        Objects.requireNonNull(to, "to must not be null");
        ops.add(yaml -> moveEntry(yaml, from, to));
        return this;
    }

    @Override
    public Migration remove(String path) {
        Objects.requireNonNull(path, "path must not be null");
        ops.add(yaml -> removeEntry(yaml, path));
        return this;
    }

    @Override
    public Migration run(Consumer<YamlConfiguration> raw) {
        Objects.requireNonNull(raw, "raw must not be null");
        ops.add(raw);
        return this;
    }

    public List<Consumer<YamlConfiguration>> ops() {
        return List.copyOf(ops);
    }

    /**
     * Moves an entry (value plus comments) to another path. The value is only
     * copied when the target is absent; the source is always removed.
     */
    public static void moveEntry(YamlConfiguration yaml, String from, String to) {
        if (!yaml.contains(from)) {
            return;
        }
        if (!yaml.contains(to)) {
            yaml.set(to, yaml.get(from));
            List<String> comments = yaml.getComments(from);
            if (!comments.isEmpty()) {
                yaml.setComments(to, comments);
            }
            List<String> inlineComments = yaml.getInlineComments(from);
            if (!inlineComments.isEmpty()) {
                yaml.setInlineComments(to, inlineComments);
            }
        }
        removeEntry(yaml, from);
    }

    /**
     * Removes an entry and prunes parent sections that became empty, so a moved
     * legacy path does not leave an orphaned {@code player: {}} stub behind.
     */
    public static void removeEntry(YamlConfiguration yaml, String path) {
        yaml.set(path, null);
        String parent = parentPath(path);
        while (parent != null) {
            ConfigurationSection section = yaml.getConfigurationSection(parent);
            if (section == null || !section.getKeys(false).isEmpty()) {
                break;
            }
            yaml.set(parent, null);
            parent = parentPath(parent);
        }
    }

    private static String parentPath(String path) {
        int dot = path.lastIndexOf('.');
        return dot < 0 ? null : path.substring(0, dot);
    }
}
