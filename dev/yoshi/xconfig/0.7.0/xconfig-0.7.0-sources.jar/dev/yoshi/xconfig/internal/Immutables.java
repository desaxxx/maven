package dev.yoshi.xconfig.internal;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Deep, order-preserving, null-tolerant unmodifiable copies of collection
 * values. Values served from the snapshot cache (and key defaults) go through
 * here so a caller mutating a returned {@code List}/{@code Set}/{@code Map}
 * gets an {@link UnsupportedOperationException} instead of silently
 * corrupting the cache for every other reader.
 *
 * <p>{@code List.copyOf}/{@code Map.copyOf} are not used: they reject
 * {@code null} elements (valid in YAML) and {@code Map.copyOf} loses the
 * file's key order.
 */
public final class Immutables {

    private Immutables() {
    }

    /**
     * Returns an unmodifiable deep copy of {@code value} when it is a
     * {@link List}, {@link Set} or {@link Map} (nested collections included);
     * any other value is returned as is.
     */
    public static Object deepCopy(Object value) {
        if (value instanceof List<?> list) {
            List<Object> out = new ArrayList<>(list.size());
            for (Object element : list) {
                out.add(deepCopy(element));
            }
            return Collections.unmodifiableList(out);
        }
        if (value instanceof Set<?> set) {
            Set<Object> out = new LinkedHashSet<>();
            for (Object element : set) {
                out.add(deepCopy(element));
            }
            return Collections.unmodifiableSet(out);
        }
        if (value instanceof Map<?, ?> map) {
            Map<Object, Object> out = new LinkedHashMap<>();
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                out.put(entry.getKey(), deepCopy(entry.getValue()));
            }
            return Collections.unmodifiableMap(out);
        }
        return value;
    }
}
