package dev.yoshi.xconfig.adapters;

import dev.yoshi.xconfig.ConfigException;
import dev.yoshi.xconfig.TypeAdapter;
import net.kyori.adventure.text.format.TextColor;

/**
 * Conversion between the {@code #RRGGBB} hexadecimal notation and the
 * Adventure {@link TextColor}.
 */
public final class TextColorAdapter implements TypeAdapter<TextColor> {

    public static final TextColorAdapter INSTANCE = new TextColorAdapter();

    private TextColorAdapter() {
    }

    @Override
    public TextColor deserialize(Object raw, String path) {
        String input = String.valueOf(raw).trim();
        TextColor color = TextColor.fromHexString(input);
        if (color == null) {
            throw new ConfigException("Invalid color '" + input + "' (expected format: #RRGGBB) at path: " + path, path);
        }
        return color;
    }

    @Override
    public Object serialize(TextColor value) {
        return value.asHexString();
    }
}
