package dev.yoshi.xconfig;

import java.util.Optional;

/**
 * Type-safe, read-only YAML configuration view.
 *
 * <p>Configurations are read-only by default: values change only through the
 * file and {@link #update()}. One created with {@link XConfigBuilder#buildWritable()}
 * is a {@link WritableXConfig} and can also write values with
 * {@link WritableXConfig#set(ConfigKey, Object)}. (A read-only configuration
 * still writes to its file when it completes missing keys or runs migrations;
 * see {@link XConfigBuilder#completeMissing(boolean)}.)
 *
 * <p>Values are re-read and resolved from the file only when {@link #update()}
 * is called; the result is then atomically published as a new snapshot, so
 * concurrent {@link #get(ConfigKey)} calls always observe one consistent
 * snapshot served from a cache.
 *
 * <pre>{@code
 * XConfig config = XConfig.builder(dataFolder.resolve("config.yml"))
 *         .keys(MyKeys.class)                      // scans static ConfigKey fields
 *         .logger(getLogger())
 *         .build();                                // creates the file with comments if missing
 *
 * String host = config.get(MyKeys.DATABASE_HOST);  // type-safe access
 * config.update();                                 // reload if the file changed
 * }</pre>
 *
 * <h2>Threads (Paper and Folia)</h2>
 *
 * <p>XConfig never schedules anything and never touches worlds, entities or
 * players, so it runs unchanged on Paper and Folia; no scheduler library is
 * needed. Every method may be called from any thread: the main thread on
 * Paper, any region thread or the global region thread on Folia, or an async
 * thread. {@link #get(ConfigKey)} and {@link #find(ConfigKey)} are lock-free;
 * {@link #update()} (and {@link WritableXConfig#set}) calls are serialized.
 *
 * <p>Whether a plugin using XConfig runs on Folia is decided by the plugin
 * itself ({@code folia-supported: true} in its {@code plugin.yml}); see
 * {@link #update()} and {@link TypeAdapter} for the notes that apply there.
 */
public interface XConfig {

    /**
     * Returns the current value of the key.
     *
     * <p>If the file contains no value or the value cannot be resolved, the key's
     * default value is used (unless strict mode is enabled, in which case a
     * {@link ConfigException} is thrown).
     *
     * <p>Collections are returned as unmodifiable copies, but other mutable
     * objects ({@code ItemStack}, {@code Location}, ...) are the snapshot's own
     * instance, shared with every caller and every thread. {@code clone()} them
     * before changing them or handing them to an API that may change them.
     *
     * @throws ConfigException if the value cannot be resolved in strict mode
     */
    <T> T get(ConfigKey<T> key);

    /**
     * Returns the value if the key is actually present and resolvable in the
     * file, an empty {@link Optional} otherwise. Never falls back to the
     * default value: a present-but-unresolvable value yields an empty
     * {@link Optional} (or throws in strict mode).
     *
     * @throws ConfigException if a present value cannot be resolved in strict mode
     */
    <T> Optional<T> find(ConfigKey<T> key);

    /**
     * Re-reads the file, completes missing keys (together with their comments)
     * and atomically refreshes the value cache.
     *
     * <p>Runs on the calling thread and blocks while it reads (and possibly
     * writes) the file. Readers on other threads keep seeing the previous
     * snapshot until the new one is complete. On Folia, a call from a region
     * thread holds up that region's tick for the duration of the reload; for
     * large files prefer the global region thread or an async thread.
     * Values that Bukkit deserializes ({@code ItemStack}, {@code Location}, other
     * {@code ConfigurationSerializable}s) are created during this call, on the
     * calling thread; calling it off the server threads when the file holds
     * such values has not been verified, so keep those reloads on a server thread.
     *
     * <p>If Bukkit fails to deserialize such a value (for example a
     * {@code Location} whose world is not loaded yet), it logs the error and
     * drops the value. The value is then treated as absent and, so it is not
     * erased from the file, the file is not saved during this call: missing
     * keys, migrations and alias moves apply in memory only and are written by
     * the first reload that loads cleanly. In strict mode (the configuration's
     * or the owning key's) a {@link ConfigException} is thrown instead.
     *
     * @throws ConfigException if the file cannot be read, or a value cannot be resolved in strict mode
     */
    void update();

    /** Path of the configuration file. */
    java.nio.file.Path file();

    /** Ordered, immutable list of keys registered with this configuration. */
    java.util.List<ConfigKey<?>> keys();

    /**
     * Starts a new configuration builder.
     *
     * @param file the configuration file (e.g. {@code dataFolder.resolve("config.yml")})
     */
    static XConfigBuilder builder(java.nio.file.Path file) {
        return new XConfigBuilder(file);
    }
}
