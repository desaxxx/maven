package dev.yoshi.xconfig.internal;

import dev.yoshi.xconfig.TypeAdapter;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Produces the YAML-writable representation of a default value (types Bukkit
 * cannot write itself are simplified through adapters/enums/generic conversion).
 */
public final class ValueWriter {

    private ValueWriter() {
    }

    public static Object write(Object value, Map<Class<?>, TypeAdapter<?>> adapters) {
        if (value == null) {
            return null;
        }
        // 1) Adapter registry: an exact registration for the runtime class wins;
        //    otherwise scanned by assignability (in registration order) so that an
        //    interface type (e.g. Component) matches its runtime implementations.
        //    ValueResolver.adapterFor applies the same exact-then-supertype rule
        //    on the read side.
        TypeAdapter<?> exact = adapters.get(value.getClass());
        if (exact != null) {
            return serializeUnchecked(exact, value);
        }
        for (Map.Entry<Class<?>, TypeAdapter<?>> entry : adapters.entrySet()) {
            if (entry.getKey().isInstance(value)) {
                return serializeUnchecked(entry.getValue(), value);
            }
        }
        // 2) Enum -> name.
        if (value instanceof Enum<?> constant) {
            return constant.name();
        }
        // 3) List<E>, element-wise.
        if (value instanceof List<?> list) {
            List<Object> out = new ArrayList<>(list.size());
            for (Object element : list) {
                out.add(write(element, adapters));
            }
            return out;
        }
        // 4) Set<E> -> array.
        if (value instanceof Set<?> set) {
            List<Object> out = new ArrayList<>(set.size());
            for (Object element : set) {
                out.add(write(element, adapters));
            }
            return out;
        }
        // 5) Map<K, V> -> keys become text.
        if (value instanceof Map<?, ?> map) {
            Map<Object, Object> out = new LinkedHashMap<>();
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                out.put(String.valueOf(entry.getKey()), write(entry.getValue(), adapters));
            }
            return out;
        }
        // 6) Primitives, String and ConfigurationSerializable are written as-is (Bukkit handles them).
        return value;
    }

    @SuppressWarnings("unchecked")
    private static Object serializeUnchecked(TypeAdapter<?> adapter, Object value) {
        return ((TypeAdapter<Object>) adapter).serialize(value);
    }
}
