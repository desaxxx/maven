package dev.yoshi.xconfig.adapters;

import dev.yoshi.xconfig.TypeAdapter;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;

/**
 * Conversion between MiniMessage markup (e.g. {@code <green>Hello}) and an
 * Adventure {@link Component}.
 *
 * <p>Parsing is lenient: unknown tags are kept as literal text instead of
 * failing, which keeps user-edited config files resilient. Serialization uses
 * {@link MiniMessage#serialize(Component)} so default values round-trip as
 * human-readable markup.
 */
public final class ComponentAdapter implements TypeAdapter<Component> {

    public static final ComponentAdapter INSTANCE = new ComponentAdapter();

    private static final MiniMessage MINI_MESSAGE = MiniMessage.miniMessage();

    private ComponentAdapter() {
    }

    @Override
    public Component deserialize(Object raw, String path) {
        return MINI_MESSAGE.deserialize(String.valueOf(raw));
    }

    @Override
    public Object serialize(Component value) {
        return MINI_MESSAGE.serialize(value);
    }
}
