package dev.yoshi.xconfig;

import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.WildcardType;

import java.util.List;
import java.util.Map;

/**
 * Minimal super type token used to carry generic types through runtime type
 * erasure. Implemented in-house (instead of Guava) to keep the library
 * dependency-free and easy to relocate.
 *
 * <p>Usage:
 * <pre>{@code
 * // Capture a generic type via an anonymous subclass:
 * ConfigKey<List<String>> key = ConfigKey.builder("worlds", new TypeToken<List<String>>() {})
 *         .comment("Enabled worlds")
 *         .defaultValue(List.of("world"))
 *         .build();
 *
 * // Shortcut for raw types:
 * ConfigKey<String> host = ConfigKey.builder("host", String.class).build();
 * }</pre>
 */
public abstract class TypeToken<T> {

    private final Type type;

    /**
     * This constructor may only be invoked through an anonymous subclass;
     * the generic type is captured from the superclass signature via reflection.
     */
    protected TypeToken() {
        Type superClass = getClass().getGenericSuperclass();
        if (!(superClass instanceof ParameterizedType parameterized) || parameterized.getRawType() != TypeToken.class) {
            throw new IllegalStateException(
                    "TypeToken must be subclassed anonymously, e.g. new TypeToken<List<String>>() {}.");
        }
        Type actual = parameterized.getActualTypeArguments()[0];
        if (actual instanceof WildcardType) {
            throw new IllegalStateException("TypeToken cannot contain a wildcard (?); provide a concrete type.");
        }
        this.type = actual;
    }

    private TypeToken(Type type) {
        this.type = type;
    }

    /**
     * Creates a token for a non-generic type.
     */
    public static <T> TypeToken<T> of(Class<T> type) {
        return new ClassToken<>(type);
    }

    /**
     * Creates a token for {@code Map<String, V>} built at runtime (the key type
     * is always {@code String}, matching YAML section keys). Used by
     * {@link ConfigKey#elementMap}; user-facing tokens stay anonymous subclasses.
     */
    static <V> TypeToken<Map<String, V>> mapOf(Class<V> valueType) {
        return new BuiltToken<>(new BuiltParameterizedType(Map.class, new Type[]{String.class, valueType}));
    }

    /**
     * Creates a token for {@code List<E>} built at runtime. Used by
     * {@link ConfigKey#elementList}.
     */
    static <E> TypeToken<List<E>> listOf(Class<E> elementType) {
        return new BuiltToken<>(new BuiltParameterizedType(List.class, new Type[]{elementType}));
    }

    /**
     * The exact carried type (e.g. {@code java.util.List<java.lang.String>}).
     */
    public final Type type() {
        return type;
    }

    /**
     * The raw class of the type (e.g. {@code List.class} for {@code List<String>}).
     */
    @SuppressWarnings("unchecked")
    public final Class<? super T> rawType() {
        return (Class<? super T>) raw(type);
    }

    private static Class<?> raw(Type type) {
        if (type instanceof Class<?> clazz) {
            return clazz;
        }
        if (type instanceof ParameterizedType parameterized) {
            return (Class<?>) parameterized.getRawType();
        }
        if (type instanceof GenericArrayType) {
            return Object[].class;
        }
        return Object.class;
    }

    @Override
    public final String toString() {
        return type.getTypeName();
    }

    private static final class ClassToken<T> extends TypeToken<T> {
        ClassToken(Class<T> rawType) {
            super(rawType);
        }
    }

    private static final class BuiltToken<T> extends TypeToken<T> {
        BuiltToken(Type type) {
            super(type);
        }
    }

    /** Minimal ParameterizedType implementation for runtime-built tokens. */
    private record BuiltParameterizedType(Class<?> rawType, Type[] arguments) implements ParameterizedType {

        BuiltParameterizedType {
            arguments = arguments.clone();
        }

        @Override
        public Type[] getActualTypeArguments() {
            return arguments.clone();
        }

        @Override
        public Type getRawType() {
            return rawType;
        }

        @Override
        public Type getOwnerType() {
            return null;
        }

        /** Canonical {@code raw<arg, arg>} form, as printed by the JDK's own implementations. */
        @Override
        public String getTypeName() {
            StringBuilder out = new StringBuilder(rawType.getTypeName()).append('<');
            for (int i = 0; i < arguments.length; i++) {
                if (i > 0) {
                    out.append(", ");
                }
                out.append(arguments[i].getTypeName());
            }
            return out.append('>').toString();
        }
    }
}
