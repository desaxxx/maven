package dev.yoshi.xconfig;

import dev.yoshi.xconfig.adapters.ComponentAdapter;
import dev.yoshi.xconfig.adapters.DurationAdapter;
import dev.yoshi.xconfig.adapters.PatternAdapter;
import dev.yoshi.xconfig.adapters.TextColorAdapter;
import dev.yoshi.xconfig.internal.ConfigPaths;
import dev.yoshi.xconfig.internal.KeyScanner;
import dev.yoshi.xconfig.internal.MigrationImpl;
import dev.yoshi.xconfig.internal.MigrationStep;
import dev.yoshi.xconfig.internal.XConfigImpl;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;

import java.nio.file.Path;
import java.time.Duration;
import java.util.Collections;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.logging.Logger;
import java.util.regex.Pattern;

/**
 * Builder for {@link XConfig}. Example:
 *
 * <pre>{@code
 * XConfig config = XConfig.builder(dataFolder.resolve("config.yml"))
 *         .keys(ConfigKeys.class)                     // scans static ConfigKey fields
 *         .keys(ExtraKeys.SOME_KEY)                   // individual keys work too
 *         .adapter(UUID.class, myUuidAdapter)         // global adapter registration
 *         .version(3)                                 // manages the config-version key
 *         .migration(2, m -> m.move("spawn.x", "spawn.point.x"))
 *         .strict()                                   // unresolved values throw
 *         .build();                                   // read-only; buildWritable() adds set(...)
 * }</pre>
 */
public final class XConfigBuilder {

    private final Path file;
    private final List<ConfigKey<?>> keys = new ArrayList<>();
    private final List<ConfigSection> sections = new ArrayList<>();
    private final Map<Class<?>, TypeAdapter<?>> adapters = new LinkedHashMap<>();
    private final List<MigrationStep> migrationSteps = new ArrayList<>();
    private boolean strict = false;
    private boolean completeMissing = true;
    private Integer declaredVersion = null;
    private Logger logger = Logger.getLogger("XConfig");

    XConfigBuilder(Path file) {
        this.file = Objects.requireNonNull(file, "file must not be null");
        // Built-in adapters: work without declaring an adapter on the key itself.
        adapters.put(Duration.class, DurationAdapter.INSTANCE);
        adapters.put(Pattern.class, PatternAdapter.INSTANCE);
        adapters.put(TextColor.class, TextColorAdapter.INSTANCE);
        adapters.put(Component.class, ComponentAdapter.INSTANCE);
    }

    /**
     * Scans and registers every {@code static} {@link ConfigKey} field of the given
     * classes (plus their {@code static} {@link ConfigSection} fields). Keys are
     * written to the file in this registration order.
     */
    public XConfigBuilder keys(Class<?>... holders) {
        Objects.requireNonNull(holders, "holders must not be null");
        for (Class<?> holder : holders) {
            keys.addAll(KeyScanner.scan(holder));
            sections.addAll(KeyScanner.scanSections(holder));
        }
        return this;
    }

    /** Registers keys individually. */
    public XConfigBuilder keys(ConfigKey<?>... keys) {
        this.keys.addAll(List.of(keys)); // List.of rejects null entries
        return this;
    }

    /** Registers comment-only section declarations individually. */
    public XConfigBuilder sections(ConfigSection... sections) {
        this.sections.addAll(List.of(sections));
        return this;
    }

    /**
     * Registers a global adapter for a type; it applies everywhere (including
     * list elements). A key-specific adapter takes precedence.
     */
    public <T> XConfigBuilder adapter(Class<T> type, TypeAdapter<T> adapter) {
        Objects.requireNonNull(type, "type must not be null");
        Objects.requireNonNull(adapter, "adapter must not be null");
        adapters.put(type, adapter);
        return this;
    }

    /**
     * Strict mode: an unresolvable value throws {@link ConfigException}
     * instead of silently falling back to the default.
     */
    public XConfigBuilder strict() {
        this.strict = true;
        return this;
    }

    /**
     * Whether missing keys (and a missing file) are auto-completed with their
     * defaults and comments when the configuration is built or updated
     * (default: {@code true}). When {@code false}, the file is never written to
     * for completion; missing values silently fall back to their defaults.
     * Explicitly declared transformations still run and save: migration steps
     * (see {@link #migration(int, Consumer)}) and {@link ConfigKey.Builder#alias(String)}
     * moves (both take a backup of the original file first).
     */
    public XConfigBuilder completeMissing(boolean complete) {
        this.completeMissing = complete;
        return this;
    }

    /**
     * Declares the current configuration schema version and enables management
     * of the reserved {@code config-version} root key. Must be at least {@code 1}.
     *
     * <p>When the file has no {@code config-version} (or a lower one), the
     * declared {@link #migration(int, Consumer)} steps run in ascending order
     * and a backup of the original file is taken first
     * ({@code <file>.before-migration-v<version>}).
     */
    public XConfigBuilder version(int version) {
        if (version < 1) {
            throw new IllegalArgumentException("version must be at least 1, got: " + version);
        }
        this.declaredVersion = version;
        return this;
    }

    /**
     * Declares operations that run when the file's stored version is lower than
     * {@code toVersion}. Steps with different versions chain (a v1 file migrated
     * to v3 runs the v2 step, then the v3 step). Requires {@link #version(int)}.
     *
     * <p>A backup of the original file is taken before the first modification.
     */
    public XConfigBuilder migration(int toVersion, Consumer<Migration> steps) {
        Objects.requireNonNull(steps, "steps must not be null");
        if (toVersion < 1) {
            throw new IllegalArgumentException("toVersion must be at least 1, got: " + toVersion);
        }
        MigrationImpl impl = new MigrationImpl();
        steps.accept(impl);
        migrationSteps.add(new MigrationStep(toVersion, impl.ops()));
        return this;
    }

    /** Logger used for warnings (e.g. {@code plugin.getLogger()}). */
    public XConfigBuilder logger(Logger logger) {
        this.logger = Objects.requireNonNull(logger, "logger must not be null");
        return this;
    }

    /**
     * Creates and loads the configuration. If the file is missing or keys are
     * missing, they are written to the file with their defaults and comments.
     *
     * <p>Registrations are checked first: the same key instance registered
     * twice is kept once, while two different keys sharing a path, a scalar
     * key whose path is the parent of another key ({@code a} vs {@code a.b}),
     * an alias pointing at another key's path, or a key at the reserved
     * {@code config-version} path (when {@link #version(int)} is set) are
     * rejected.
     *
     * @throws IllegalStateException if registered keys/sections conflict
     * @throws ConfigException if the file cannot be read, or a value cannot be resolved in strict mode
     */
    public XConfig build() {
        return create(false);
    }

    /**
     * Like {@link #build()}, but the configuration can also write values back
     * to the file through {@link WritableXConfig#set(ConfigKey, Object)}.
     * Configurations are read-only unless created with this method.
     *
     * @throws IllegalStateException if registered keys/sections conflict
     * @throws ConfigException if the file cannot be read, or a value cannot be resolved in strict mode
     */
    public WritableXConfig buildWritable() {
        return create(true);
    }

    private XConfigImpl create(boolean writable) {
        List<ConfigKey<?>> distinctKeys = ConfigPaths.distinctByIdentity(keys);
        List<ConfigSection> distinctSections = ConfigPaths.distinctByIdentity(sections);
        ConfigPaths.checkConflicts(distinctKeys, distinctSections,
                declaredVersion != null ? XConfigImpl.CONFIG_VERSION_PATH : null);
        // Insertion order is kept (unlike Map.copyOf): ValueWriter scans the
        // registry by assignability, so a value matching several registered
        // types must resolve deterministically — built-ins first, then user
        // registrations in declaration order.
        Map<Class<?>, TypeAdapter<?>> orderedAdapters = Collections.unmodifiableMap(new LinkedHashMap<>(adapters));
        return new XConfigImpl(file, List.copyOf(distinctKeys), List.copyOf(distinctSections), orderedAdapters, strict,
                completeMissing, declaredVersion, List.copyOf(migrationSteps), logger, writable);
    }
}
