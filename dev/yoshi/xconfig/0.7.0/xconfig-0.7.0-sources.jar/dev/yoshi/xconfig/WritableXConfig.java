package dev.yoshi.xconfig;

/**
 * An {@link XConfig} that can also write values back to its file, created with
 * {@link XConfigBuilder#buildWritable()}. A configuration created with
 * {@link XConfigBuilder#build()} stays read-only and has no {@link #set} method.
 *
 * <pre>{@code
 * WritableXConfig config = XConfig.builder(dataFolder.resolve("config.yml"))
 *         .keys(MyKeys.class)
 *         .buildWritable();
 *
 * config.set(MyKeys.COOLDOWN, Duration.ofSeconds(30)); // written to the file, comments kept
 * config.get(MyKeys.COOLDOWN);                         // PT30S
 * }</pre>
 */
public interface WritableXConfig extends XConfig {

    /**
     * Writes the value to the file and publishes a new snapshot, so
     * {@link #get(ConfigKey)} returns the new value as soon as this returns.
     *
     * <p>The file is re-read first (with its comments), so changes made to it
     * by hand since the last reload are kept. The value is converted the same
     * way defaults are (the key's adapter, else the element adapter of an
     * element map/list, else the adapters registered with the builder) and
     * saved atomically. The rest of the call follows the {@link #update()}
     * pipeline: migrations, alias moves and missing keys are applied and
     * written along with the value. A registered key whose path is not in the
     * file yet (a {@code null} default, {@code completeMissing(false)}, a line
     * deleted by hand) is written with its comments.
     *
     * <p>Only keys registered with the builder can be set: they passed the
     * conflict checks of {@link XConfigBuilder#build()}, so a write cannot
     * overwrite another key's section or the reserved {@code config-version}
     * path. ({@link #get(ConfigKey)} still reads unregistered keys.)
     *
     * <p>{@code set} and {@link #update()} calls are serialized: only one of
     * them reads or writes the file at a time. It may be called from any
     * thread; the thread notes of {@link #update()} apply.
     *
     * @throws IllegalArgumentException if the key is not registered with this configuration
     *         (the file is not touched)
     * @throws ConfigException if the value is {@code null} or fails the key's
     *         validator (the file is not touched), if the file holds a value
     *         Bukkit could not load (the file is not saved so that value is not
     *         erased), or if the file cannot be read or written
     */
    <T> void set(ConfigKey<T> key, T value);
}
