package dev.yoshi.xconfig;

import org.bukkit.configuration.file.YamlConfiguration;

import java.util.function.Consumer;

/**
 * Fluent operations for a single migration step, declared via
 * {@link XConfigBuilder#migration(int, Consumer)}:
 *
 * <pre>{@code
 * .migration(2, m -> m
 *         .move("spawn.x", "spawn.point.x")
 *         .remove("old-module.enabled")
 *         .run(yaml -> yaml.set("legacy.mode", null)))
 * }</pre>
 *
 * <p>Operations run against the loaded YAML before missing keys are completed.
 * A {@code move} transfers the value (and its comments) only when the target
 * path is absent; the source entry is always removed.
 */
public interface Migration {

    /**
     * Moves a value from {@code from} to {@code to}. If the target already
     * exists, the stale source entry is simply removed.
     */
    Migration move(String from, String to);

    /** Removes the entry at {@code path} (including its comments). */
    Migration remove(String path);

    /** Escape hatch for arbitrary transformations on the raw YAML. */
    Migration run(Consumer<YamlConfiguration> raw);
}
