package dev.yoshi.xconfig;

import dev.yoshi.xconfig.internal.ConfigPaths;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * Comment-only declaration for a YAML section: comments are written above the
 * section key itself (e.g. above {@code offline_revenue:}), not above its first
 * child. Sections hold no value — declaring one only controls the file layout.
 *
 * <p>Sections are typically declared as {@code public static final} fields in
 * the same "key holder" class as the {@link ConfigKey}s; {@link
 * XConfigBuilder#keys(Class...)} picks up both:
 *
 * <pre>{@code
 * public final class Keys {
 *     public static final ConfigSection OFFLINE_REVENUE_SECTION =
 *             ConfigSection.builder("offline_revenue")
 *                     .blankLine()
 *                     .comment("Offline revenue")
 *                     .build();
 *
 *     public static final ConfigKey<Boolean> OFFLINE_REVENUE_ENABLED =
 *             ConfigKey.builder("offline_revenue.enabled", Boolean.class)
 *                     .defaultValue(false)
 *                     .build();
 * }
 * }</pre>
 *
 * <p>Writing rules: section comments are written when the section exists and
 * currently has no comments (a fresh file, or a file generated before this
 * declaration existed). A section carrying the user's own comments is never
 * touched.
 */
public final class ConfigSection {

    private final String path;
    private final List<String> comments;
    private final String inlineComment;

    private ConfigSection(Builder builder) {
        this.path = builder.path;
        this.comments = Collections.unmodifiableList(new ArrayList<>(builder.comments));
        this.inlineComment = builder.inlineComment;
    }

    /** Section builder. */
    public static Builder builder(String path) {
        Objects.requireNonNull(path, "path must not be null");
        return new Builder(ConfigPaths.requireValid(path, "path"));
    }

    /** Full path of the section (dot-separated parent path). */
    public String path() {
        return path;
    }

    /**
     * Comment lines written above the section key. Per Bukkit's comment
     * contract, a {@code null} entry renders as an empty line and an empty
     * string renders as a bare "#" line.
     */
    public List<String> comments() {
        return comments;
    }

    /** Comment written at the end of the section line, or null. */
    public String inlineComment() {
        return inlineComment;
    }

    @Override
    public String toString() {
        return "ConfigSection['" + path + "']";
    }

    /** Fluent section builder; the chain must be closed with {@link #build()}. */
    public static final class Builder {

        private final String path;
        private final List<String> comments = new ArrayList<>();
        private String inlineComment;

        private Builder(String path) {
            this.path = path;
        }

        /**
         * Comment lines written above the section key; multiple calls
         * accumulate and keep their call order. An empty string renders as a
         * bare "#" line. Use {@link #blankLine()} for empty lines.
         */
        public Builder comment(String... lines) {
            comments.addAll(Arrays.asList(lines));
            return this;
        }

        /** Writes an empty line above the section key; multiple calls stack. */
        public Builder blankLine() {
            comments.add(null);
            return this;
        }

        /** Single comment written at the end of the section line. */
        public Builder inlineComment(String line) {
            this.inlineComment = Objects.requireNonNull(line, "inlineComment must not be null");
            return this;
        }

        public ConfigSection build() {
            return new ConfigSection(this);
        }
    }
}
