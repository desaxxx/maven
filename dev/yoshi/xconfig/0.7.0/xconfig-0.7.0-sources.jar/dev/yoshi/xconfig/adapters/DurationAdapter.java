package dev.yoshi.xconfig.adapters;

import dev.yoshi.xconfig.ConfigException;
import dev.yoshi.xconfig.TypeAdapter;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.Duration;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Conversion between a human-friendly duration format and {@link Duration}.
 *
 * <p>Deserialization sums the units: {@code "500ms"}, {@code "30s"}, {@code "10m"},
 * {@code "1h30m"}, {@code "2d12h"}; tokens may be separated by whitespace
 * ({@code "1h 30m"}). Supported units: {@code d, h, m, s, ms, us} (or {@code µs})
 * and {@code ns}. A leading {@code -} makes the duration negative. A bare number
 * ({@code 30}, {@code "30"} or {@code 1.5}) is read as seconds.
 *
 * <p>Serialization writes compactly from the largest unit:
 * {@code "1d2h3m4s500ms"}; zero duration becomes {@code "0s"} and negative
 * durations get a leading {@code -}.
 */
public final class DurationAdapter implements TypeAdapter<Duration> {

    public static final DurationAdapter INSTANCE = new DurationAdapter();

    private static final Pattern TOKEN = Pattern.compile("(\\d+)(ns|us|µs|ms|s|m|h|d)");
    private static final Pattern BARE_NUMBER = Pattern.compile("\\d+(\\.\\d+)?");
    private static final BigInteger NANOS_PER_SECOND = BigInteger.valueOf(1_000_000_000L);

    private DurationAdapter() {
    }

    @Override
    public Duration deserialize(Object raw, String path) {
        String input = String.valueOf(raw).trim().toLowerCase(Locale.ROOT);
        boolean negative = input.startsWith("-");
        String body = negative || input.startsWith("+") ? input.substring(1).trim() : input;
        if (body.isEmpty()) {
            throw parseError(input, path, null);
        }
        try {
            Duration total = BARE_NUMBER.matcher(body).matches() ? seconds(body, input, path) : sumTokens(body, input, path);
            return negative ? total.negated() : total;
        } catch (ArithmeticException | NumberFormatException exception) {
            throw new ConfigException("Duration value '" + input + "' is out of range at path: " + path,
                    path, exception);
        }
    }

    /** Bare number of seconds, fractions down to nanosecond precision ("1.5" → 1s500ms). */
    private static Duration seconds(String body, String input, String path) {
        BigDecimal nanos = new BigDecimal(body).movePointRight(9);
        if (nanos.stripTrailingZeros().scale() > 0) {
            throw parseError(input, path, null); // finer than a nanosecond
        }
        BigInteger[] split = nanos.toBigInteger().divideAndRemainder(NANOS_PER_SECOND);
        return Duration.ofSeconds(split[0].longValueExact(), split[1].longValueExact());
    }

    private static Duration sumTokens(String body, String input, String path) {
        Matcher matcher = TOKEN.matcher(body);
        Duration total = Duration.ZERO;
        int position = 0;
        boolean any = false;
        while (position < body.length()) {
            if (Character.isWhitespace(body.charAt(position))) {
                position++;
                continue;
            }
            matcher.region(position, body.length());
            if (!matcher.lookingAt()) {
                throw parseError(input, path, null);
            }
            long amount = Long.parseLong(matcher.group(1));
            total = total.plus(switch (matcher.group(2)) {
                case "ns" -> Duration.ofNanos(amount);
                case "us", "µs" -> Duration.ofNanos(Math.multiplyExact(amount, 1_000L));
                case "ms" -> Duration.ofMillis(amount);
                case "s" -> Duration.ofSeconds(amount);
                case "m" -> Duration.ofMinutes(amount);
                case "h" -> Duration.ofHours(amount);
                case "d" -> Duration.ofDays(amount);
                default -> throw new IllegalStateException("Unexpected duration unit: " + matcher.group(2));
            });
            position = matcher.end();
            any = true;
        }
        if (!any) {
            throw parseError(input, path, null);
        }
        return total;
    }

    @Override
    public Object serialize(Duration value) {
        if (value.isZero()) {
            return "0s";
        }
        if (value.isNegative()) {
            return "-" + serialize(value.negated());
        }
        long seconds = value.getSeconds();
        int nanos = value.getNano();

        StringBuilder result = new StringBuilder();
        append(result, seconds / 86_400L, "d");
        append(result, seconds % 86_400L / 3_600L, "h");
        append(result, seconds % 3_600L / 60L, "m");
        append(result, seconds % 60L, "s");
        append(result, nanos / 1_000_000, "ms");
        append(result, nanos / 1_000 % 1_000, "us");
        append(result, nanos % 1_000, "ns");
        return result.toString();
    }

    private static void append(StringBuilder out, long amount, String unit) {
        if (amount > 0) {
            out.append(amount).append(unit);
        }
    }

    private static ConfigException parseError(String input, String path, Throwable cause) {
        return new ConfigException(
                "Invalid duration value '" + input + "' (e.g.: 500ms, 30s, 5m, 1h30m, 2d) at path: " + path,
                path, cause);
    }
}
