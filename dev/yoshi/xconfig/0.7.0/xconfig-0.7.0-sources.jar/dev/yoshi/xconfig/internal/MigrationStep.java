package dev.yoshi.xconfig.internal;

import org.bukkit.configuration.file.YamlConfiguration;

import java.util.List;
import java.util.function.Consumer;

/**
 * One version-boundary migration step; applied when the file's stored
 * {@code config-version} is lower than {@link #toVersion()}.
 */
public record MigrationStep(int toVersion, List<Consumer<YamlConfiguration>> ops) {
}
