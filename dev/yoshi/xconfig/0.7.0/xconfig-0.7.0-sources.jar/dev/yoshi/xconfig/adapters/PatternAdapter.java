package dev.yoshi.xconfig.adapters;

import dev.yoshi.xconfig.ConfigException;
import dev.yoshi.xconfig.TypeAdapter;

import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * Resolves the raw YAML text as a compiled {@link Pattern} (regex).
 */
public final class PatternAdapter implements TypeAdapter<Pattern> {

    public static final PatternAdapter INSTANCE = new PatternAdapter();

    private PatternAdapter() {
    }

    @Override
    public Pattern deserialize(Object raw, String path) {
        String expression = String.valueOf(raw).trim();
        try {
            return Pattern.compile(expression);
        } catch (PatternSyntaxException exception) {
            throw new ConfigException("Invalid regex '" + expression + "' at path: " + path, path, exception);
        }
    }

    @Override
    public Object serialize(Pattern value) {
        return value.pattern();
    }
}
